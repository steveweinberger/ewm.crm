var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            'use strict';
            var DocType = Mscrm.AppCommon.Common.DocumentTemplateType;
            var TemplateSelectionScreen = (function () {
                /**
                 * Empty constructor.
                 */
                function TemplateSelectionScreen() {
                    this.onExcelButtonClicked = function () {
                        this._excelContainerStyle = this._applyStyles.TemplateScreenContainerStyleSelected();
                        if (!this._context.userSettings.isRTL) {
                            this._excelContainerStyle["marginRight"] = this._context.theming.measures.measure050;
                        }
                        else {
                            this._excelContainerStyle["marginLeft"] = this._context.theming.measures.measure050;
                            this._excelContainerStyle["marginRight"] = "0rem";
                        }
                        this._wordContainerStyle = this._applyStyles.TemplateScreenContainerStyle();
                        this.template_type = DocType.Excel;
                        this._context.utils.requestRender();
                        this._notifyOutputChanged();
                    };
                    this.onWordButtonClicked = function () {
                        this._excelContainerStyle = this._applyStyles.TemplateScreenExcelContainerStyle();
                        this._wordContainerStyle = this._applyStyles.TemplateScreenContainerStyleSelected();
                        this.template_type = DocType.Word;
                        this._context.utils.requestRender();
                        this._notifyOutputChanged();
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                TemplateSelectionScreen.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    this._applyStyles = new ExcelWordTemplate.TemplateSelectionScreenStyles(context);
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    this._excelContainerStyle = this._applyStyles.TemplateScreenExcelContainerStyle();
                    this._wordContainerStyle = this._applyStyles.TemplateScreenContainerStyle();
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                TemplateSelectionScreen.prototype.updateView = function (context) {
                    /*
                    TemplateSelectionScreenPageContainer
                    |----BodyContainer
                    |----ScreenLabel
                    |----SelectLabel
                        |----IconContainer
                    */
                    //Create label
                    var TemplateScreenLabel = context.factory.createElement("LABEL", {
                        id: "TemplateScreenLabel",
                        key: "TemplateScreenLabel",
                        style: this._applyStyles.TemplateScreenLabel()
                    }, this._context.resources.getString("TemplateSelectionScreenControl_DescriptionLabel"));
                    //Create label
                    var TitleLabel = context.factory.createElement("LABEL", {
                        id: "TitleLabel",
                        key: "TitleLabel",
                        style: this._applyStyles.TemplateScreenTitleLabel()
                    }, this._context.resources.getString("TemplateSelectionScreenControl_TemplateTypeLabel"));
                    var ExcelButton = context.factory.createElement("LABEL", {
                        key: "TemplateSelectionScreenExcelTemplate.Icon",
                        id: "TemplateSelectionScreenExcelTemplate.Icon",
                        style: this._applyStyles.TemplateScreenImageButton()
                    });
                    var ExcelLabel = context.factory.createElement("LABEL", {
                        id: "ExcelLabel",
                        key: "ExcelLabel",
                        style: this._applyStyles.TemplateScreenBottomLabel()
                    }, this._context.resources.getString("TemplateSelectionScreenControl_ExcelLabel"));
                    var ExcelButtonContainer = context.factory.createElement("BUTTON", {
                        key: "ExcelContainer", id: "ExcelContainer", style: this._excelContainerStyle, tabIndex: 0, onClick: this.onExcelButtonClicked.bind(this)
                    }, [ExcelButton, ExcelLabel]);
                    var WordButton = context.factory.createElement("LABEL", {
                        key: "TemplateSelectionScreenWordTemplate.Icon",
                        id: "TemplateSelectionScreenWordTemplate.Icon",
                        style: this._applyStyles.TemplateScreenImageButton()
                    });
                    var WordLabel = context.factory.createElement("LABEL", {
                        id: "WordLabel",
                        key: "WordLabel",
                        style: this._applyStyles.TemplateScreenBottomLabel()
                    }, this._context.resources.getString("TemplateSelectionScreenControl_WordLabel"));
                    var WordButtonContainer = context.factory.createElement("BUTTON", {
                        key: "WordContainer", id: "WordContainer", style: this._wordContainerStyle, tabIndex: 0, onClick: this.onWordButtonClicked.bind(this)
                    }, [WordButton, WordLabel]);
                    var IconContainer = context.factory.createElement("CONTAINER", {
                        key: "IconContainer", id: "IconContainer", style: this._applyStyles.TemplateScreenIconContainer()
                    }, [ExcelButtonContainer, WordButtonContainer]);
                    // Create Container
                    var TemplatePageContainer = context.factory.createElement("CONTAINER", {
                        id: "TemplatePageContainer",
                        key: "TemplatePageContainer",
                        style: this._applyStyles.TemplatePageContainer()
                    }, [TemplateScreenLabel, TitleLabel, IconContainer]);
                    return TemplatePageContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                TemplateSelectionScreen.prototype.getOutputs = function () {
                    var result = {
                        templateType: this.template_type.toString()
                    };
                    return result;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                TemplateSelectionScreen.prototype.destroy = function () {
                };
                return TemplateSelectionScreen;
            }());
            ExcelWordTemplate.TemplateSelectionScreen = TemplateSelectionScreen;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="TemplateSelectionScreen.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            var TemplateSelectionScreenStyles = (function (_super) {
                __extends(TemplateSelectionScreenStyles, _super);
                function TemplateSelectionScreenStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._templateScreenLabel = {};
                    _this._templateScreenTitleLabel = {};
                    _this._templateScreenBottomLabel = {};
                    _this._templateScreenIconContainer = {};
                    _this._templatePageContainer = {};
                    _this._templateScreenonExcelButtonClicked = {};
                    _this._templateScreenContainerStyle = {};
                    _this._templateScreenContainerStyleSelected = {};
                    _this._templateScreenExcelContainerStyle = {};
                    _this._templateScreenImageButton = {};
                    _this._context = context;
                    _this._templateScreenLabel = null;
                    _this._templateScreenTitleLabel = null;
                    _this._templateScreenImageButton = null;
                    _this._templateScreenBottomLabel = null;
                    _this._templateScreenIconContainer = null;
                    _this._templatePageContainer = null;
                    _this._templateScreenonExcelButtonClicked = null;
                    _this._templateScreenContainerStyle = null;
                    _this._templateScreenContainerStyleSelected = null;
                    _this._templateScreenExcelContainerStyle = null;
                    return _this;
                }
                TemplateSelectionScreenStyles.prototype.TemplateScreenContainerStyle = function () {
                    this._templateScreenContainerStyle = {};
                    this._templateScreenContainerStyle["flexDirection"] = "column";
                    this._templateScreenContainerStyle["justifyContent"] = "spaceBetween";
                    this._templateScreenContainerStyle["cursor"] = "pointer";
                    this._templateScreenContainerStyle["width"] = "140px";
                    this._templateScreenContainerStyle["height"] = "150px";
                    this._templateScreenContainerStyle["borderWidth"] = "0.1rem";
                    this._templateScreenContainerStyle["borderStyle"] = "solid";
                    this._templateScreenContainerStyle["borderColor"] = "#BFC5C6";
                    this._templateScreenContainerStyle["boxShadow"] = "1px 1px 2px 0px #BFC5C6";
                    this._templateScreenContainerStyle["alignItems"] = "center";
                    this._templateScreenContainerStyle["backgroundColor"] = this._context.theming.colors.basecolor.white;
                    return this._templateScreenContainerStyle;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenContainerStyleSelected = function () {
                    this._templateScreenContainerStyleSelected = {};
                    this._templateScreenContainerStyleSelected = this.TemplateScreenContainerStyle();
                    this._templateScreenContainerStyleSelected["boxShadow"] = "inset 1px 1px 4px 0px #BFC5C6";
                    this._templateScreenContainerStyleSelected["backgroundColor"] = this._context.theming.colors.basecolor.grey.grey1;
                    return this._templateScreenContainerStyleSelected;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenExcelContainerStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._templateScreenExcelContainerStyle)) {
                        this._templateScreenExcelContainerStyle = this.TemplateScreenContainerStyle();
                        if (!this._context.userSettings.isRTL) {
                            this._templateScreenExcelContainerStyle["marginRight"] = this._context.theming.measures.measure050;
                        }
                        else {
                            this._templateScreenExcelContainerStyle["marginLeft"] = this._context.theming.measures.measure050;
                            this._templateScreenExcelContainerStyle["marginRight"] = "0rem";
                        }
                    }
                    return this._templateScreenExcelContainerStyle;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._templateScreenLabel)) {
                        this._templateScreenLabel = {};
                        this._templateScreenLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._templateScreenLabel["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._templateScreenLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._templateScreenLabel["whiteSpace"] = "Normal";
                    }
                    return this._templateScreenLabel;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenTitleLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._templateScreenTitleLabel)) {
                        this._templateScreenTitleLabel = {};
                        this._templateScreenTitleLabel["marginTop"] = this._context.theming.measures.measure150;
                        this._templateScreenTitleLabel["marginBottom"] = this._context.theming.measures.measure075;
                        this._templateScreenTitleLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._templateScreenTitleLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._templateScreenTitleLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._templateScreenTitleLabel;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenImageButton = function () {
                    if (this._context.utils.isNullOrUndefined(this._templateScreenImageButton)) {
                        this._templateScreenImageButton = {};
                        this._templateScreenImageButton["alignSelf"] = "center";
                        this._templateScreenImageButton["marginTop"] = this._context.theming.measures.measure225;
                        this._templateScreenImageButton["marginBottom"] = this._context.theming.measures.measure150;
                    }
                    return this._templateScreenImageButton;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenBottomLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._templateScreenBottomLabel)) {
                        this._templateScreenBottomLabel = {};
                        this._templateScreenBottomLabel["alignSelf"] = "center";
                        this._templateScreenBottomLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._templateScreenBottomLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._templateScreenBottomLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._templateScreenBottomLabel;
                };
                TemplateSelectionScreenStyles.prototype.TemplateScreenIconContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._templateScreenIconContainer)) {
                        this._templateScreenIconContainer = {};
                        this._templateScreenIconContainer["display"] = "flex";
                    }
                    return this._templateScreenIconContainer;
                };
                TemplateSelectionScreenStyles.prototype.TemplatePageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._templatePageContainer)) {
                        this._templatePageContainer = {};
                        this._templatePageContainer["flexDirection"] = "column";
                    }
                    return this._templatePageContainer;
                };
                return TemplateSelectionScreenStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            ExcelWordTemplate.TemplateSelectionScreenStyles = TemplateSelectionScreenStyles;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=TemplateSelectionScreen.js.map