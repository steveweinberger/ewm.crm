var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SampleDataManagement;
        (function (SampleDataManagement) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            /// <summary>
            /// ImportStatus Reasons
            /// </summary>
            var ImportStatus;
            (function (ImportStatus) {
                /// <summary> Not Yet Imported </summary>
                ImportStatus[ImportStatus["NotImported"] = 0] = "NotImported";
                /// <summary> Import is in Progress </summary>
                ImportStatus[ImportStatus["InProgress"] = 1] = "InProgress";
                /// <summary> Import has Completed </summary>
                ImportStatus[ImportStatus["Completed"] = 2] = "Completed";
                /// <summary> Import has Failed </summary>
                ImportStatus[ImportStatus["Failed"] = 3] = "Failed";
            })(ImportStatus = SampleDataManagement.ImportStatus || (SampleDataManagement.ImportStatus = {}));
            var SampleDataManagementControl = (function () {
                /**
                 * Empty constructor.
                 */
                function SampleDataManagementControl() {
                    this._applyStyles = null;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                SampleDataManagementControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this.context = context;
                    var title = this.context.resources.getString(SampleDataManagement.ResourceKeys.AdvancedSettingsText) + " " + this.context.resources.getString(SampleDataManagement.ResourceKeys.SampleDataManagementText) + " - " + this.context.resources.getString(SampleDataManagement.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(this.context, title);
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.SAMPLEDATAMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "SampleDataManagementPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                    this._webApirequest = new SampleDataManagement.WebApiRequest(context);
                    this._sampledataProgressFlag = false;
                    this._unInstalledJsonData = null;
                    this._sampledataInstalledJson = null;
                    this.IsSampleDataInstalled();
                };
                /// <summary>
                /// Helper function, which determines if the CRM sample data has been installed
                /// It sets _importStatus, as completed, failed or in progress (States where sample data can be before being successfully installed)
                /// </summary>
                SampleDataManagementControl.prototype.getImportStatus = function () {
                    var that = this;
                    var uri = this.context.utils.createCrmUri(SampleDataManagement.SampleDataManagementStrings.CRMURI);
                    if (this._sampledataInstalledJson != null && this._sampledataInstalledJson.value.length > 0) {
                        if (this._sampledataInstalledJson.value[0].sampledataimportid != "00000000-0000-0000-0000-000000000000" || this._sampledataInstalledJson.value[0].sampledataimportid != null) {
                            var c = $.getJSON(uri + SampleDataManagement.SampleDataManagementStrings.SampleDataStatusCodeURI + this._sampledataInstalledJson.value[0].sampledataimportid)
                                .done(function (data) {
                                that._importSampleJsonData = data;
                                if (that._importSampleJsonData != null && that._importSampleJsonData.value.length > 0) {
                                    switch (that._importSampleJsonData.value[0].statuscode) {
                                        // 4 is the Import Status Code for Complete Import
                                        case 4:
                                            that._importStatus = ImportStatus.Completed;
                                            break;
                                        // 5 is the Import Status Code for the Failed Import
                                        case 5:
                                            that._importStatus = ImportStatus.Failed;
                                            break;
                                        // Rest (Submitted, Parsing, Transforming, Importing) are different stages of Inprogress Import hence putting them under same case.
                                        default: that._importStatus = ImportStatus.InProgress;
                                    }
                                }
                            })
                                .fail(function (data) {
                                SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.SAMPLEDATAMANAGEMENT, data);
                                console.log(data);
                            });
                        }
                        else {
                            this._importStatus = ImportStatus.NotImported;
                        }
                    }
                    else {
                        this._importStatus = ImportStatus.NotImported;
                    }
                    return this._importStatus;
                };
                /// <summary>
                /// Determines if the CRM sample data has been installed
                /// </summary>
                SampleDataManagementControl.prototype.IsSampleDataInstalled = function () {
                    //Query the org I'm connected to to get sample data import info
                    var that = this;
                    var uri = this.context.utils.createCrmUri(SampleDataManagement.SampleDataManagementStrings.CRMURI);
                    var c = $.getJSON(uri + SampleDataManagement.SampleDataManagementStrings.SampleDataImportIDURI)
                        .done(function (data) {
                        that._sampledataInstalledJson = data;
                        that.getImportStatus();
                        that.context.utils.requestRender();
                    })
                        .fail(function (data) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.SAMPLEDATAMANAGEMENT, data);
                        console.log(data);
                    });
                };
                /**
                 * Handler for the Remove button in the main Screen.
                 */
                SampleDataManagementControl.prototype.onRemoveButtonClicked = function () {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.SAMPLEDATAMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "RemoveSampleDataButton", SampleDataManagement.SampleDataManagementStrings.ButtonID, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Remove SampleData Button Clicked", false);
                    //Open a confirm dialog
                    var dialogOptions = {
                        height: 205,
                        width: 450
                    };
                    var confirmDialogStrings = {
                        title: this.context.resources.getString(SampleDataManagement.ResourceKeys.ConfirmDialogTitleText),
                        text: this.context.resources.getString(SampleDataManagement.ResourceKeys.ConfirmDialogText),
                        confirmButtonLabel: this.context.resources.getString(SampleDataManagement.ResourceKeys.RemoveButtonText)
                    };
                    var that = this;
                    this.context.navigation.openConfirmDialog(confirmDialogStrings, dialogOptions)
                        .then(function (result) {
                        if (result.confirmed) {
                            var uri = SampleDataManagement.SampleDataManagementStrings.UnInstallSampleDataURI;
                            that._webApirequest.RequestToCRM("POST", uri, true);
                            that._sampledataProgressFlag = true;
                            that.context.utils.requestRender();
                        }
                    });
                };
                /**
                * Handler for the Installed button in the main Screen.
                */
                SampleDataManagementControl.prototype.onInstallButtonClicked = function () {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.SAMPLEDATAMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "InstallSampleDataButton", SampleDataManagement.SampleDataManagementStrings.ButtonID, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Install SampleData Button Clicked", false);
                    //Open a confirm dialog
                    var dialogOptions = {
                        height: 205,
                        width: 450
                    };
                    var confirmDialogStrings = {
                        title: this.context.resources.getString(SampleDataManagement.ResourceKeys.ConfirmDialogTitleText),
                        text: this.context.resources.getString(SampleDataManagement.ResourceKeys.InstallDialogText),
                        confirmButtonLabel: this.context.resources.getString(SampleDataManagement.ResourceKeys.InstallDialogButtonText)
                    };
                    var that = this;
                    this.context.navigation.openConfirmDialog(confirmDialogStrings, dialogOptions)
                        .then(function (result) {
                        if (result.confirmed) {
                            var uri = SampleDataManagement.SampleDataManagementStrings.InstallSampleDataURI;
                            that._webApirequest.RequestToCRM("POST", uri, true);
                            that._sampledataProgressFlag = true;
                            that.context.utils.requestRender();
                        }
                    });
                };
                /**
                 * Rendering the Remove Button
                 */
                SampleDataManagementControl.prototype.createRemoveButtonContainer = function () {
                    var removeButton = this.context.factory.createElement("BUTTON", {
                        key: SampleDataManagement.SampleDataManagementStrings.ButtonID,
                        id: SampleDataManagement.SampleDataManagementStrings.ButtonID,
                        onClick: this.onRemoveButtonClicked.bind(this), style: this._applyStyles.FREPrimaryButton()
                    }, SampleDataManagement.SampleDataManagementStrings.RemovalButtonText);
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.RemoveDataButton,
                        key: SampleDataManagement.SampleDataManagementStrings.RemoveDataButton, style: this._applyStyles.RemoveButtonContainer()
                    }, removeButton);
                };
                /**
                 * Rendering the Center Container When the Sample Data is already installed with Icon, Two Labels and Button
                 */
                SampleDataManagementControl.prototype.createInstalledDataCenterContainer = function () {
                    var installCenterImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer, style: this._applyStyles.InstalledImageContainer()
                    }, []);
                    var installSampleLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.MiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.MiddleLabel, style: this._applyStyles.MiddleLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.DataInTrialAccountText));
                    var installWarningLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel, style: this._applyStyles.BottomMiddleLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.DataWarningText));
                    var installButtonControl = this.createRemoveButtonContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData,
                        key: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData, style: this._applyStyles.CenterContainer()
                    }, [installCenterImageContainer, installSampleLabel, installWarningLabel, installButtonControl]);
                };
                /**
                 * Rendering the Complete Center Container with Installed Label text
                 */
                SampleDataManagementControl.prototype.createBodyForInstalledData = function () {
                    var installBodyLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.Label,
                        key: SampleDataManagement.SampleDataManagementStrings.Label, style: this._applyStyles.TopSampleTextLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.InstalledSampleDataText));
                    var installTextContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.TextContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.TextContainer, style: this._applyStyles.InstalledDataTextContainer()
                    }, installBodyLabel);
                    var installCenterContainer = this.createInstalledDataCenterContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.BodyContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.BodyContainer, style: this._applyStyles.FRESectionContainer()
                    }, [installTextContainer, installCenterContainer]);
                };
                /**
                 * Rendering the Center Container When the Sample Data is just removed and Uninstallation is in progress with Icon and label
                 */
                SampleDataManagementControl.prototype.createUnInstallationInProgressCenterContainer = function () {
                    var centerImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer, style: this._applyStyles.InstalledImageContainer()
                    }, []);
                    var unInstallationProgressLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.MiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.MiddleLabel, style: this._applyStyles.MiddleLabel(),
                        accessibilityLive: "assertive"
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.UninstalledProgressText));
                    var ContinueLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel, style: this._applyStyles.BottomMiddleLabel(),
                        accessibilityLive: "assertive"
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.ContinueText));
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData,
                        key: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData, style: this._applyStyles.CenterContainer()
                    }, [centerImageContainer, unInstallationProgressLabel, ContinueLabel]);
                };
                /**
                 * Rendering the Full Body Container When unInstallation is in progress
                 */
                SampleDataManagementControl.prototype.createBodyForUninstallationProgressData = function () {
                    var bodyLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.Label,
                        key: SampleDataManagement.SampleDataManagementStrings.Label, style: this._applyStyles.TopSampleTextLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.InstalledSampleDataText));
                    var unInstallationProgressTextContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.TextContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.TextContainer, style: this._applyStyles.InstalledDataTextContainer()
                    }, bodyLabel);
                    var unInstallationProgressCenterContainer = this.createUnInstallationInProgressCenterContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.BodyContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.BodyContainer, style: this._applyStyles.FRESectionContainer()
                    }, [unInstallationProgressTextContainer, unInstallationProgressCenterContainer]);
                };
                /**
                 * Rendering the Center Container When the Sample Data is just installed and installation is in progress with Icon and label
                 */
                SampleDataManagementControl.prototype.createDataInstallationInProgressCenterContainer = function () {
                    var centerImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer, style: this._applyStyles.InstalledImageContainer()
                    }, []);
                    var installationProgressLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.MiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.MiddleLabel, style: this._applyStyles.MiddleLabel(),
                        accessibilityLive: "assertive"
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.InstalledProgressText));
                    var ContinueLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel, style: this._applyStyles.BottomMiddleLabel(),
                        accessibilityLive: "assertive"
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.ContinueText));
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData,
                        key: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData, style: this._applyStyles.CenterContainer()
                    }, [centerImageContainer, installationProgressLabel, ContinueLabel]);
                };
                /**
                 * Rendering the Full Body Container When unInstallation is in progress
                 */
                SampleDataManagementControl.prototype.createBodyForDataInstallationProgressData = function () {
                    var bodyLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.Label,
                        key: SampleDataManagement.SampleDataManagementStrings.Label, style: this._applyStyles.TopSampleTextLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.InstalledSampleDataText));
                    var installationProgressTextContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.TextContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.TextContainer, style: this._applyStyles.InstalledDataTextContainer()
                    }, bodyLabel);
                    var installationProgressCenterContainer = this.createDataInstallationInProgressCenterContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.BodyContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.BodyContainer, style: this._applyStyles.FRESectionContainer()
                    }, [installationProgressTextContainer, installationProgressCenterContainer]);
                };
                /**
                * Rendering the Install Button
                */
                SampleDataManagementControl.prototype.createInstallButtonContainer = function () {
                    var installButton = this.context.factory.createElement("BUTTON", {
                        key: SampleDataManagement.SampleDataManagementStrings.ButtonID,
                        id: SampleDataManagement.SampleDataManagementStrings.ButtonID,
                        onClick: this.onInstallButtonClicked.bind(this), style: this._applyStyles.FREPrimaryButton()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.InstallDialogButtonText));
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.RemoveDataButton,
                        key: SampleDataManagement.SampleDataManagementStrings.RemoveDataButton, style: this._applyStyles.RemoveButtonContainer()
                    }, installButton);
                };
                /**
                * Rendering the  Center Container When the Sample Data is Completely UnInstalled
                */
                SampleDataManagementControl.prototype.createUnInstalledSampleDataCenterContainer = function () {
                    var centerImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.ImageCenterContainer, style: this._applyStyles.InstalledImageContainer()
                    }, []);
                    var unInstalledLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.MiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.MiddleLabel, style: this._applyStyles.MiddleLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.UninstalledText));
                    var unInstalledWarningLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel,
                        key: SampleDataManagement.SampleDataManagementStrings.BottomMiddleLabel, style: this._applyStyles.BottomMiddleLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.DataRemovalInfoText));
                    var unInstalledButtonControl = this.createInstallButtonContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData,
                        key: SampleDataManagement.SampleDataManagementStrings.InstalledCenterData, style: this._applyStyles.CenterContainer()
                    }, [centerImageContainer, unInstalledLabel, unInstalledWarningLabel, unInstalledButtonControl]);
                };
                /**
                 * Rendering the FullBody Center Container when Sample data is uninstalled
                 */
                SampleDataManagementControl.prototype.createBodyForUninstallatedData = function () {
                    var bodyLabel = this.context.factory.createElement("LABEL", {
                        id: SampleDataManagement.SampleDataManagementStrings.Label,
                        key: SampleDataManagement.SampleDataManagementStrings.Label, style: this._applyStyles.TopSampleTextLabel()
                    }, this.context.resources.getString(SampleDataManagement.ResourceKeys.InstalledSampleDataText));
                    var unInstalledTextContainer = this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.TextContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.TextContainer, style: this._applyStyles.InstalledDataTextContainer()
                    }, bodyLabel);
                    var unInstalledCenterContainer = this.createUnInstalledSampleDataCenterContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: SampleDataManagement.SampleDataManagementStrings.BodyContainer,
                        key: SampleDataManagement.SampleDataManagementStrings.BodyContainer, style: this._applyStyles.FRESectionContainer()
                    }, [unInstalledTextContainer, unInstalledCenterContainer]);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SampleDataManagementControl.prototype.updateView = function (context) {
                    return this._freShell.getVirtualComponents(this.getChildControls(context));
                };
                SampleDataManagementControl.prototype.getChildControls = function (context) {
                    //icon content
                    var params = {};
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new SampleDataManagement.SampleDataManagementStyles(context);
                    }
                    params.normalIconImagePath = SampleDataManagement.SampleDataManagementStrings.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = SampleDataManagement.SampleDataManagementStrings.HeaderHighContrastIconImagePath;
                    params.areaLabel = this.context.resources.getString(SampleDataManagement.ResourceKeys.OtherText);
                    params.subAreaLabel = this.context.resources.getString(SampleDataManagement.ResourceKeys.SampleDataManagementText);
                    var that = this;
                    var uri = this.context.utils.createCrmUri(SampleDataManagement.SampleDataManagementStrings.CRMURI);
                    //O-data call for getting sampledataimportid, to determine, if the sample data is present or not
                    if ((this._unInstalledJsonData == null || this._unInstalledJsonData == undefined) || (this._unInstalledJsonData != null && this._unInstalledJsonData.value == null)) {
                        var c = $.getJSON(uri + SampleDataManagement.SampleDataManagementStrings.SampleDataImportIDURI)
                            .done(function (data) {
                            that._unInstalledJsonData = data;
                            that.context.utils.requestRender();
                        })
                            .fail(function (data) {
                            SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.SAMPLEDATAMANAGEMENT, data);
                            console.log(data);
                            that.context.utils.requestRender();
                        });
                    }
                    //Rendering the page according to conditions
                    var controls = [];
                    if (this._sampledataProgressFlag == true) {
                        if (this._sampledataUnInstalledState == false) {
                            controls.push(this.createBodyForUninstallationProgressData());
                        }
                        else {
                            controls.push(this.createBodyForDataInstallationProgressData());
                        }
                    }
                    else {
                        if (this._unInstalledJsonData.value[0].sampledataimportid === "00000000-0000-0000-0000-000000000000" || this._unInstalledJsonData.value[0].sampledataimportid === null) {
                            this._sampledataUnInstalledState = true;
                            controls.push(this.createBodyForUninstallatedData());
                        }
                        else {
                            this._sampledataUnInstalledState = false;
                            if (this._importStatus == ImportStatus.Completed) {
                                controls.push(this.createBodyForInstalledData());
                            }
                            else {
                                controls.push(this.createBodyForDataInstallationProgressData());
                            }
                        }
                    }
                    params.contentContainerChild = controls;
                    this._freShell.stopPerformanceStopWatch();
                    return params;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SampleDataManagementControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SampleDataManagementControl.prototype.destroy = function () {
                };
                return SampleDataManagementControl;
            }());
            SampleDataManagement.SampleDataManagementControl = SampleDataManagementControl;
        })(SampleDataManagement = AppCommon.SampleDataManagement || (AppCommon.SampleDataManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SampleDataManagement.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SampleDataManagement;
        (function (SampleDataManagement) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "SampleDataManagementText", {
                    get: function () {
                        return "SampleDataManagementText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "InstalledSampleDataText", {
                    get: function () {
                        return "InstalledSampleDataText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DataInTrialAccountText", {
                    get: function () {
                        return "DataInTrialAccountText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DataWarningText", {
                    get: function () {
                        return "DataWarningText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DialogText", {
                    get: function () {
                        return "DialogText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "InstalledProgressText", {
                    get: function () {
                        return "InstalledProgressText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "UninstalledProgressText", {
                    get: function () {
                        return "UninstalledProgressText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "UninstalledText", {
                    get: function () {
                        return "UninstalledText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmDialogTitleText", {
                    get: function () {
                        return "ConfirmDialogTitleText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmDialogText", {
                    get: function () {
                        return "ConfirmDialogText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmDialogButtonText", {
                    get: function () {
                        return "ConfirmDialogButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RemoveButtonText", {
                    get: function () {
                        return "RemoveButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ContinueText", {
                    get: function () {
                        return "ContinueText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "InstallDialogButtonText", {
                    get: function () {
                        return "InstallDialogButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DataRemovalInfoText", {
                    get: function () {
                        return "DataRemovalInfoText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "InstallDialogText", {
                    get: function () {
                        return "InstallDialogText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "OtherText", {
                    get: function () {
                        return "OtherText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            SampleDataManagement.ResourceKeys = ResourceKeys;
        })(SampleDataManagement = AppCommon.SampleDataManagement || (AppCommon.SampleDataManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SampleDataManagement;
        (function (SampleDataManagement) {
            'use strict';
            var SampleDataManagementStrings = (function () {
                function SampleDataManagementStrings() {
                }
                Object.defineProperty(SampleDataManagementStrings, "InstalledSampleDataText", {
                    get: function () {
                        return "Sample data gives you something to experiment with as you learn Microsoft Dynamics 365, and helps you see how data is organized in the system. By using sample data, work with records and see how they relate to each other, how data displays in charts, and see what information is in reports. At some point, you’ll probably want to remove the sample data then use the below setting to remove it.";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallDataInTrialAccountText", {
                    get: function () {
                        return "We are using sample data in your trial account.";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallDataWarningText", {
                    get: function () {
                        return "Sample data can be reInstalled if removed";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstallDataWarningText", {
                    get: function () {
                        return "Sample data can be reInstalled";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstalledProgressText", {
                    get: function () {
                        return "Removal of Sample Data is processed in background. You can continue to use Microsoft Dynamic 365";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstalledProgressText", {
                    get: function () {
                        return "Installation of Sample Data is processed in background. You can continue to use Microsoft Dynamic 365";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstallDataInTrialAccountText", {
                    get: function () {
                        return "Sample data is removed from system.";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstallDialogTitleText", {
                    get: function () {
                        return "Confirmation";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstallDialogText", {
                    get: function () {
                        return "You are about to remove sample data from your trial account.";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstallDialogButtonLabelText", {
                    get: function () {
                        return "Remove Sample Data";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallDialogTitleText", {
                    get: function () {
                        return "Confirmation";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallDialogText", {
                    get: function () {
                        return "You are about to install sample data from your trial account.";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallDialogButtonLabelText", {
                    get: function () {
                        return "Install Sample Data";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "RemovalButtonText", {
                    get: function () {
                        return "Remove Sample Data";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallButtonText", {
                    get: function () {
                        return "Install Sample Data";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "otherText", {
                    get: function () {
                        return "Others";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "SampleDataManagementText", {
                    get: function () {
                        return "Sample Data Management";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "CRMURI", {
                    get: function () {
                        return "/api/data/v8.0";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "UnInstallSampleDataURI", {
                    get: function () {
                        return "/UninstallSampleData";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstallSampleDataURI", {
                    get: function () {
                        return "/InstallSampleData";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "SampleDataImportIDURI", {
                    get: function () {
                        return "/organizations?$select=sampledataimportid";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "SampleDataStatusCodeURI", {
                    get: function () {
                        return "/imports?$select=statuscode&$filter=importid eq ";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "PageContainer", {
                    get: function () {
                        return "FREBodyContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "BodyContainer", {
                    get: function () {
                        return "FRESectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "HeaderContainer", {
                    get: function () {
                        return "FREHeaderContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "ImageCenterContainer", {
                    get: function () {
                        return "SDM_InstalledImageContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InnerHeaderRight", {
                    get: function () {
                        return "FREHeaderLeft";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "HeaderTopLabel", {
                    get: function () {
                        return "FREAreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "HeaderBottomLabel", {
                    get: function () {
                        return "FRESubareaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "Label", {
                    get: function () {
                        return "FREFieldLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "BottomMiddleLabel", {
                    get: function () {
                        return "SDM_BottomMiddleLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "SectionLabel", {
                    get: function () {
                        return "FRESectionLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "MiddleLabel", {
                    get: function () {
                        return "SDM_MiddleLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "InstalledCenterData", {
                    get: function () {
                        return "SDM_CenterContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "TextContainer", {
                    get: function () {
                        return "SDM_InstalledDataTextContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "RemoveDataButton", {
                    get: function () {
                        return "SDM_RemoveButtonContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "ButtonID", {
                    get: function () {
                        return "SDM_FREPrimaryButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/SampleDataManagement.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SampleDataManagementStrings, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/SampleDataManagement_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return SampleDataManagementStrings;
            }());
            SampleDataManagement.SampleDataManagementStrings = SampleDataManagementStrings;
        })(SampleDataManagement = AppCommon.SampleDataManagement || (AppCommon.SampleDataManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SampleDataManagement;
        (function (SampleDataManagement) {
            'use strict';
            var SampleDataManagementStyles = (function (_super) {
                __extends(SampleDataManagementStyles, _super);
                function SampleDataManagementStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._context = context;
                    _this._installedImageContainer = {};
                    _this._installedDataTextContainer = {};
                    _this._middleLabel = {};
                    _this._bottomMiddleLabel = {};
                    _this._removeButtonContainer = {};
                    _this._toptextLabel = {};
                    _this._centerContainer = {};
                    return _this;
                }
                SampleDataManagementStyles.prototype.InstalledImageContainer = function () {
                    this._installedImageContainer = {};
                    this._installedImageContainer["display"] = "flex";
                    this._installedImageContainer["justifyContent"] = "center";
                    return this._installedImageContainer;
                };
                SampleDataManagementStyles.prototype.InstalledDataTextContainer = function () {
                    this._installedDataTextContainer = {};
                    this._installedDataTextContainer["border"] = this._context.theming.borders.border02;
                    this._installedDataTextContainer["background"] = this._context.theming.colors.basecolor.white;
                    this._installedDataTextContainer["marginLeft"] = this._context.theming.measures.measure075;
                    this._installedDataTextContainer["marginRight"] = this._context.theming.measures.measure075;
                    this._installedDataTextContainer["marginTop"] = this._context.theming.measures.measure075;
                    this._installedDataTextContainer["marginBottom"] = this._context.theming.measures.measure075;
                    return this._installedDataTextContainer;
                };
                SampleDataManagementStyles.prototype.TopSampleTextLabel = function () {
                    this._toptextLabel = {};
                    this._toptextLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                    this._toptextLabel["fontSize"] = this._context.theming.fontsizes.font100;
                    this._toptextLabel["lineHeight"] = "1.43rem";
                    this._toptextLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    this._toptextLabel["marginLeft"] = this._context.theming.measures.measure075;
                    this._toptextLabel["marginRight"] = this._context.theming.measures.measure075;
                    this._toptextLabel["marginTop"] = this._context.theming.measures.measure075;
                    this._toptextLabel["marginBottom"] = this._context.theming.measures.measure075;
                    return this._toptextLabel;
                };
                SampleDataManagementStyles.prototype.MiddleLabel = function () {
                    this._middleLabel = {};
                    this._middleLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                    this._middleLabel["fontSize"] = this._context.theming.fontsizes.font100;
                    this._middleLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    this._middleLabel["lineHeight"] = "1.4rem";
                    this._middleLabel["textAlign"] = "center";
                    this._middleLabel["marginTop"] = this._context.theming.measures.measure150;
                    return this._middleLabel;
                };
                SampleDataManagementStyles.prototype.BottomMiddleLabel = function () {
                    this._bottomMiddleLabel = {};
                    this._bottomMiddleLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                    this._bottomMiddleLabel["fontSize"] = this._context.theming.fontsizes.font085;
                    this._bottomMiddleLabel["lineHeight"] = "1.4rem";
                    this._bottomMiddleLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    this._bottomMiddleLabel["textAlign"] = "center";
                    this._bottomMiddleLabel["marginTop"] = this._context.theming.measures.measure075;
                    return this._bottomMiddleLabel;
                };
                SampleDataManagementStyles.prototype.CenterContainer = function () {
                    this._centerContainer = {};
                    this._centerContainer["display"] = "flex";
                    this._centerContainer["flexDirection"] = "column";
                    this._centerContainer["background"] = this._context.theming.colors.basecolor.white;
                    this._centerContainer["justifyContent"] = "center";
                    this._centerContainer["alignItems"] = "center";
                    this._centerContainer["flex"] = "1 1 auto";
                    return this._centerContainer;
                };
                SampleDataManagementStyles.prototype.RemoveButtonContainer = function () {
                    this._removeButtonContainer = {};
                    this._removeButtonContainer["display"] = "inline-flex";
                    this._removeButtonContainer["flexDirection"] = "column";
                    this._removeButtonContainer["alignSelf"] = "center";
                    this._removeButtonContainer["marginTop"] = this._context.theming.measures.measure075;
                    return this._removeButtonContainer;
                };
                return SampleDataManagementStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            SampleDataManagement.SampleDataManagementStyles = SampleDataManagementStyles;
        })(SampleDataManagement = AppCommon.SampleDataManagement || (AppCommon.SampleDataManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SampleDataManagement;
        (function (SampleDataManagement) {
            'use strict';
            var WebApiRequest = (function () {
                function WebApiRequest(context) {
                    this._context = context;
                }
                WebApiRequest.prototype.getContext = function () {
                    return this._context;
                };
                WebApiRequest.prototype.RequestToCRM = function (action, uri, isAsync) {
                    if (!RegExp(action, "g").test("POST PATCH PUT GET DELETE")) {
                        throw new Error("Sdk.request: action parameter must be one of the following: " +
                            "POST, PATCH, PUT, GET, or DELETE.");
                    }
                    if (!(typeof uri === "string")) {
                        throw new Error("Sdk.request: uri parameter must be a string.");
                    }
                    //if ((RegExp(action, "g").test("POST PATCH PUT")) && (data === null || data === undefined)) {
                    //    throw new Error("Sdk.request: data parameter must not be null for operations that create or modify data.");
                    //}
                    // Construct a fully qualified URI if a relative URI is passed in.
                    if (uri.charAt(0) === "/") {
                        uri = "../" + this.getContext().utils.createCrmUri("/api/data/v8.0" + uri);
                    }
                    var request = new XMLHttpRequest();
                    request.open(action, encodeURI(uri), isAsync);
                    request.setRequestHeader("OData-MaxVersion", "4.0");
                    request.setRequestHeader("OData-Version", "4.0");
                    request.setRequestHeader("Accept", "application/json");
                    request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    var that = this;
                    request.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            request.onreadystatechange = null;
                            switch (this.status) {
                                case 200:
                                    var parsedResp = JSON.parse(request.responseText.replace(/(\r\n|\n|\r)/gm, "").replace(/\/\\\"/g, "").replace(/\\\"/g, "").replace("@odata.etag", "odataetag").replace("@odata.context", "odatacontext"));
                                    delete parsedResp['odatacontext'];
                                    delete parsedResp.value[0]['odataetag'];
                                    //TODO: throw an exception if json is not parsed correctly
                                    //that._jsonData = parsedResp.value[0];
                                    break;
                                case 204:
                                    break;
                                default:
                                    var error;
                                    try {
                                        error = JSON.parse(request.response).error;
                                    }
                                    catch (e) {
                                        error = new Error("Unexpected Error");
                                    }
                                    break;
                            }
                        }
                    };
                    if (action === "POST") {
                        request.send();
                    }
                    else if (action === "GET") {
                        request.send();
                    }
                };
                return WebApiRequest;
            }());
            SampleDataManagement.WebApiRequest = WebApiRequest;
        })(SampleDataManagement = AppCommon.SampleDataManagement || (AppCommon.SampleDataManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SampleDataManagement.js.map