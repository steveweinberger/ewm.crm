/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AddNewUser;
        (function (AddNewUser) {
            'use strict';
            var RetrieveCurrentOrganizationRequest = ODataContract.RetrieveCurrentOrganizationRequest;
            var EndpointAccessType = ODataContract.EndpointAccessType;
            var CommonUtils = Mscrm.AppCommon.Common.Utility;
            var WEBAPPLICATION = "WebApplication";
            var AddNewUserControl = (function () {
                /**
                 * constructor.
                 */
                function AddNewUserControl() {
                    this._context = null;
                    this._heightIFrame = null;
                    this._gladosAddUserUrl = null;
                    this._organizationId = null;
                    this._isFunctionSetGladosUrlForAddUserCalled = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                AddNewUserControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._organizationId = this._getOrganizationId();
                    this._context.client.trackContainerResize(true);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                AddNewUserControl.prototype.updateView = function (context) {
                    this._context = context;
                    this._heightIFrame = this._getAvailableHeight();
                    if (!this._isFunctionSetGladosUrlForAddUserCalled) {
                        this._setGladosUrlForAddUser();
                        this._isFunctionSetGladosUrlForAddUserCalled = true;
                    }
                    if (!CommonUtils.isNullOrUndefined(this._gladosAddUserUrl)) {
                        var dialogIFrame = this._context.factory.createElement("IFRAME", {
                            key: AddNewUser.Constants.IFrameKey, id: AddNewUser.Constants.IFrameKey,
                            title: this._context.resources.getString(AddNewUser.ResourceKeys.IFrameTitle),
                            src: this._gladosAddUserUrl,
                            style: {
                                width: "100%",
                                height: this._heightIFrame
                            }
                        });
                        return dialogIFrame;
                    }
                    var loadingLabel = this._context.factory.createElement("LABEL", {
                        key: AddNewUser.Constants.LoadingLabelKey, id: AddNewUser.Constants.LoadingLabelKey
                    }, this._context.resources.getString(AddNewUser.ResourceKeys.LoadingText));
                    var blankContainer = this._context.factory.createElement("CONTAINER", {
                        key: AddNewUser.Constants.BlankContainerKey, id: AddNewUser.Constants.BlankContainerKey,
                        style: {
                            display: "flex",
                            flex: "1 1 auto",
                            alignItems: "center",
                            justifyContent: "center"
                        }
                    }, [loadingLabel]);
                    return blankContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                AddNewUserControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                AddNewUserControl.prototype.destroy = function () {
                };
                /**
                 * Shows generic error message to user
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 */
                AddNewUserControl.prototype.showGenericError = function (context) {
                    var alertMessage = {
                        text: context.resources.getString(AddNewUser.ResourceKeys.Error_GenericErrorOccurred),
                        confirmButtonLabel: context.resources.getString(AddNewUser.ResourceKeys.ConfirmButtonText)
                    };
                    SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(null, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, alertMessage);
                    context.navigation.openAlertDialog(alertMessage);
                };
                /**
                 * Generates URL needed for AddUser iframe
                 */
                AddNewUserControl.prototype._setGladosUrlForAddUser = function () {
                    var that = this;
                    var retrieveCurrentOrganizationRequest = new RetrieveCurrentOrganizationRequest(EndpointAccessType.Default);
                    this._context.webAPI.execute(retrieveCurrentOrganizationRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                /*
                                Sample format of JSON retrived by the OData call
                                {
                                    "Detail": {
                                        "Endpoints": {
                                            "Count": 3,
                                            "IsReadOnly": false,
                                            "Keys": [
                                                "WebApplication",
                                                "OrganizationService",
                                                "OrganizationDataService"
                                            ],
                                            "Values": [
                                                "https://someorg.crmx.something.com/",
                                                "https://someorg.crmx.something.com/XRMServices/2011/Organization.svc",
                                                "https://someorg.crmx.something.com/XRMServices/2011/OrganizationData.svc"
                                            ]
                                        }
                                    }
                                }
                                */
                                try {
                                    var index = jsonResponse.Detail.Endpoints.Keys.indexOf(WEBAPPLICATION);
                                    if (index != -1) {
                                        var webApplicationEndpoint = jsonResponse.Detail.Endpoints.Values[index];
                                        var crmUrl = CommonUtils.GetCrmHostName(webApplicationEndpoint);
                                        var lcid = that._context.userSettings.languageId;
                                        that._gladosAddUserUrl = "https://port." + crmUrl + "/G/Users/AddUser.aspx?organizationId=" + that._organizationId + "&lcid=" + lcid;
                                    }
                                    else {
                                        that.showGenericError(that._context);
                                    }
                                }
                                catch (e) {
                                    console.error(e);
                                    that.showGenericError(that._context);
                                }
                                finally {
                                    that._context.utils.requestRender();
                                }
                            });
                        }
                    }, function (error) {
                        that._gladosAddUserUrl = null;
                        console.error(error);
                        that.showGenericError(that._context);
                    });
                };
                /**
                 * Get available height for Iframe
                 */
                AddNewUserControl.prototype._getAvailableHeight = function () {
                    var height = 700;
                    try {
                        height = (window.top.document.body.offsetHeight - 90);
                        height = (height < 100) ? 100 : height;
                    }
                    catch (e) {
                        console.error(e);
                    }
                    return height;
                };
                /**
                 * get organizationid from context
                 */
                AddNewUserControl.prototype._getOrganizationId = function () {
                    var orgSettings = this._context.client.orgSettings;
                    var organizationId = orgSettings.organizationId;
                    organizationId = organizationId.replace(/[{}]/g, '');
                    return organizationId;
                };
                return AddNewUserControl;
            }());
            AddNewUser.AddNewUserControl = AddNewUserControl;
        })(AddNewUser = AppCommon.AddNewUser || (AppCommon.AddNewUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="AddNewUserControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: Constants contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AddNewUser;
        (function (AddNewUser) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                Object.defineProperty(Constants, "IFrameKey", {
                    get: function () {
                        return "addNewUser_IFrame";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "LoadingLabelKey", {
                    get: function () {
                        return "addUser_LoadingLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "BlankContainerKey", {
                    get: function () {
                        return "addUser_BlankContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Constants;
            }());
            AddNewUser.Constants = Constants;
        })(AddNewUser = AppCommon.AddNewUser || (AppCommon.AddNewUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AddNewUser;
        (function (AddNewUser) {
            /**
             * Class refers to the path of all the keys for localization
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "WebApiRequestFailed", {
                    get: function () {
                        return "WebApiRequestFailed";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "WebApplicationEnpointNotFound", {
                    get: function () {
                        return "WebApplicationEnpointNotFound";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "IFrameTitle", {
                    get: function () {
                        return "IFrameTitle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "LoadingText", {
                    get: function () {
                        return "LoadingText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Error_GenericErrorOccurred", {
                    get: function () {
                        return "Error_GenericErrorOccurred";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            AddNewUser.ResourceKeys = ResourceKeys;
        })(AddNewUser = AppCommon.AddNewUser || (AppCommon.AddNewUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=AddNewUserControl.js.map