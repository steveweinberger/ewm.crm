var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var BPF;
        (function (BPF) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var Utility = Mscrm.AppCommon.Common.Utility;
            var BPFControl = (function () {
                /**
                 * Empty constructor.
                 */
                function BPFControl() {
                    var _this = this;
                    this._filteringInput = "";
                    this._entityOptionset = [];
                    /**
                    * The function is called asynchronously by AppConfig integration module when grid filtering input is available
                    **/
                    this.requiredDataAvailableToRender = function (filteringInput) {
                        _this._filteringInput = filteringInput;
                        _this._hasEntityMetadataFetched = true;
                        _this._entityMetadata = JSON.parse(_this._appModuleAppConfig.GetEntityWhiteListForCreateDialog());
                        _this.EntityOptionSet = _this._entityMetadata;
                        _this._context.utils.requestRender();
                    };
                    /**
                    * The function is called by AppConfig integration module when parking solution id is retrieved
                    **/
                    this.parkingSolutionIdIsAvailable = function (parkingSolutionId) {
                        _this._parkingSolutionId = parkingSolutionId;
                        _this._hasParkingSolutionIdFetched = true;
                        _this._context.utils.requestRender();
                    };
                    this._applyStyles = null;
                }
                Object.defineProperty(BPFControl.prototype, "EntityOptionSet", {
                    set: function (items) {
                        var _this = this;
                        items.sort(function (a, b) {
                            return a.LogicalName.localeCompare(b.LogicalName);
                        });
                        var i = 0;
                        items.forEach(function (item) {
                            _this._entityOptionset[i] = {
                                value: i + 1,
                                text: item.UserLocalizedName,
                                entityLogicalName: item.LogicalName
                            };
                            i++;
                        });
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                BPFControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    var title = this._context.resources.getString(BPF.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(BPF.ResourceKeys.SubAreaLabel) + " - " + this._context.resources.getString(BPF.ResourceKeys.MicrosoftDynamics365Text);
                    this._freshell = new FREShell(this._context, title);
                    this._hasEntityMetadataFetched = false;
                    this._hasParkingSolutionIdFetched = false;
                    this._refreshCounter = 0;
                    this._viewId = BPF.Constants.DefaultViewId;
                    this._hasAsyncFunctionInvoked = false;
                    // Description: This metric measures number of users who have visited this page. 
                    BPF.BPFTelemetry.UserVisitedBPFPage(this._context);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                BPFControl.prototype.updateView = function (context) {
                    if (!this._hasAsyncFunctionInvoked) {
                        this._appId = Utility.GetCurrentAppId();
                        this._appModuleAppConfig = new MscrmControls.AppCommon.AppModuleAppConfig(this._context.webAPI, this._context.utils, BPF.Constants.ComponentType, this._appId, this.requiredDataAvailableToRender.bind(this), this.parkingSolutionIdIsAvailable.bind(this));
                        this._hasAsyncFunctionInvoked = true;
                        this._appModuleAppConfig.AsyncGetFilteringInputForCustomizationGrid();
                        // Async Request to get backing/parking solution Id.
                        this._appModuleAppConfig.AsyncGetParkingSolution();
                    }
                    return this._freshell.getVirtualComponents(this.getChildControls());
                };
                BPFControl.prototype.getChildControls = function () {
                    var params = {};
                    // For applying styles
                    if (this._context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new BPF.BPFControlStyles(this._context);
                    }
                    params.areaLabel = this._context.resources.getString(BPF.ResourceKeys.AreaLabel);
                    params.subAreaLabel = this._context.resources.getString(BPF.ResourceKeys.SubAreaLabel);
                    /* Entity Metadata is required by the entity option set of the BPF dialogue &&
                        on creation of new BPF, It has to be saved in the parking solution.*/
                    // Don't render the newBPF Icon, If parking solution and entity metadata are not available.
                    if (this._hasEntityMetadataFetched && this._hasParkingSolutionIdFetched) {
                        params.headerRightContainerChild = this.createHeaderRightContainer();
                    }
                    params.normalIconImagePath = BPF.Constants.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = BPF.Constants.HeaderHighContrastIconImagePath;
                    /* Entity Metdata is required by the filtering input of the grid
                     parking/backing solution is required if the user is editing or deleting the BPF.*/
                    // Don't render the grid, If parking solution and entity metadata are not available.
                    if (this._hasEntityMetadataFetched && this._hasParkingSolutionIdFetched) {
                        var properties = {
                            "parameters": {
                                Grid: {
                                    TargetEntityType: BPF.Constants.Workflow,
                                    ViewId: this._viewId,
                                    Type: "Grid",
                                    RefreshInput: {
                                        Static: true,
                                        "Value": this._refreshCounter
                                    },
                                    FilteringInput: {
                                        Static: true,
                                        ControlLinked: false,
                                        Value: this._filteringInput
                                    },
                                    DataSetHostProps: {
                                        commandBarEnabled: true,
                                        jumpBarEnabled: true,
                                        quickFindEnabled: true,
                                        viewSelectorEnabled: false
                                    }
                                },
                                EnableGroupBy: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableFiltering: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableEditing: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                }
                            }
                        };
                        var grid = this._context.factory.createComponent("MscrmControls.Grid.GridControl", "BusinessProcessFlow", properties);
                        //Grid container
                        var gridContainer = this._context.factory.createElement("CONTAINER", {
                            id: BPF.Constants.BPFGridContainerKey, key: BPF.Constants.BPFGridContainerKey,
                            style: this._applyStyles.FREGridContainer()
                        }, [grid]);
                        params.contentContainerChild = gridContainer;
                        this._freshell.stopPerformanceStopWatch();
                    }
                    return params;
                };
                BPFControl.prototype.onNewBPFClick = function (event) {
                    var dialogParams = this.initiailizeDialogParams();
                    var dialogOpt = {};
                    dialogOpt.position = BPF.DialogParam.DIALOGPOSITIONRIGHT;
                    var that = this;
                    this._context.navigation.openDialog(BPF.DialogParam.SMBBPFDialog, dialogOpt, dialogParams)
                        .then(function successCallBack(successResponse) {
                        if (successResponse.parameters[BPF.DialogParam.SHOULDCREATEBPF] == "true") {
                            var newBPF;
                            var BPFName = successResponse.parameters[BPF.DialogControls.NAMEOFBUSINESSPROCESSFLOWID];
                            var selectedEntityOption = successResponse.parameters[BPF.DialogControls.ENTITYOPTIONSETID];
                            var entityLogicalName = that._entityOptionset[selectedEntityOption - 1].entityLogicalName;
                            newBPF = new BPF.NewBPF(BPFName, entityLogicalName, that._context);
                            newBPF.createBPFAsync(function (successResponse) {
                                // Open up the designer page.
                                that.openBPFDesignerURL(newBPF.WorkFlowID);
                                // Publishing the current APP
                                that.publishTheCurrentAPP()
                                    .then(function (successResponse) {
                                    // Refreshing the grid.
                                    that._hasAsyncFunctionInvoked = false;
                                    that._refreshCounter++;
                                    that._context.utils.requestRender();
                                }, function () { throw new Error("Error in publishing the app"); });
                                // Adding the new BPF in the parking/backing solution.
                                that._appModuleAppConfig.AsyncAddComponentAndAppToUnmanagedSolution(newBPF.WorkFlowID, true, that._parkingSolutionId);
                                // Description: This metric measures number of times where the user created a new BPF.
                                BPF.BPFTelemetry.NewBPFCreated(that._context);
                            }, function (error) {
                                SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.BUSINESSPROCESSFLOW, error);
                                AppCommon.Utils.Utility.handleErrorResponse(error);
                            });
                        }
                        that._context.accessibility.focusElementById(BPF.Constants.AddBPFButtonKey);
                    }, function errorCallback(errorResponse) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.BUSINESSPROCESSFLOW, errorResponse, "Cannot create new BPF");
                        AppCommon.Utils.Utility.handleErrorResponse(errorResponse, "Cannot create new BPF");
                        that._context.accessibility.focusElementById(BPF.Constants.AddBPFButtonKey);
                    });
                };
                BPFControl.prototype.publishTheCurrentAPP = function () {
                    var appId = Mscrm.AppCommon.Common.Utility.GetCurrentAppId();
                    var ParameterXml = "<importexportxml><appmodules><appmodule>{" + appId + "}</appmodule></appmodules></importexportxml>";
                    var publishXmlRequestDataContract = new ODataContract.PublishXmlRequest(ParameterXml);
                    return this._context.webAPI.execute(publishXmlRequestDataContract);
                };
                /**
                 * Initializes the input and output parameters to be passed to BPF Dialog.
                 */
                BPFControl.prototype.initiailizeDialogParams = function () {
                    var dialogParams = {};
                    dialogParams[BPF.DialogParam.APPID] = this._appId;
                    dialogParams[BPF.DialogParam.SOLUTIONID] = this._solutionId;
                    dialogParams[BPF.DialogParam.ENTITYLIST] = JSON.stringify(this._entityOptionset);
                    dialogParams[BPF.DialogParam.SHOULDCREATEBPF] = "false";
                    return dialogParams;
                };
                /**
                 * Creates RightContainer for header
                 */
                BPFControl.prototype.createHeaderRightContainer = function () {
                    var addBPFIconContainer = this._context.factory.createElement("CONTAINER", {
                        key: BPF.Constants.AddBPFIconContainerKey, id: BPF.Constants.AddBPFIconContainerKey, style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var addBPFButton = this._context.factory.createElement("BUTTON", {
                        key: BPF.Constants.AddBPFButtonKey, id: BPF.Constants.AddBPFButtonKey,
                        onClick: this.onNewBPFClick.bind(this),
                        title: this._context.resources.getString(BPF.ResourceKeys.NewBPFButtonToolTip),
                        tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [addBPFIconContainer, this._context.resources.getString(BPF.ResourceKeys.NewBPFButtonLabel)]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: BPF.Constants.BPFHeaderSeparatorContainer, id: BPF.Constants.BPFHeaderSeparatorContainer,
                        style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: BPF.Constants.BPFHeaderRightContainer, id: BPF.Constants.BPFHeaderRightContainer,
                        style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, addBPFButton]);
                    return headerRightContainer;
                };
                BPFControl.prototype.openBPFDesignerURL = function (workflowId) {
                    var width = 1200;
                    var height = 700;
                    if (window && window.top && window.top.innerWidth) {
                        width = window.top.innerWidth;
                    }
                    if (window && window.top && window.top.innerHeight) {
                        height = window.top.innerHeight;
                    }
                    window.open(this.getBPFDesignerURL(workflowId), "", "width=" + width + ",height=" + height + ",resizable=1");
                };
                /**
                 * URL for designer form
                 * @param workflowId:of the BPF i.e. workflowId of the BPF
                 */
                BPFControl.prototype.getBPFDesignerURL = function (workflowId) {
                    //For example: http://rahasija9x/rahasija9x/Tools/ProcessControl/UnifiedProcessDesigner.aspx?id=b4291961A-05E0-4898-AC38-C1A318E6CE43
                    var designerURL = this._context.utils.createCrmUri("/Tools/ProcessControl/UnifiedProcessDesigner.aspx?id=" + workflowId +
                        "&appid=" + this._appId +
                        "&parkingsolutionId=" + this._parkingSolutionId);
                    return designerURL;
                };
                /**
                * This function will return an "Output Bag" to the Crm Infrastructure
                * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                * {
                *		value: myvalue
                * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
             */
                BPFControl.prototype.getOutputs = function () {
                    return null;
                };
                /**
                * This function will be called when the control is destroyed
                * It should be used for cleanup and releasing any memory the control is using
                */
                BPFControl.prototype.destroy = function () {
                };
                return BPFControl;
            }());
            BPF.BPFControl = BPFControl;
        })(BPF = AppCommon.BPF || (AppCommon.BPF = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="BPFControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var Utils;
        (function (Utils) {
            var Utility = (function () {
                function Utility() {
                }
                Utility.handleError = function (err, message) {
                    console.log(err.message);
                    message = message + "\n" + "server error: " + err.message;
                    alert(message);
                };
                Utility.handleErrorResponse = function (err, message) {
                    console.log(err.message);
                    message = message + "\n" + "Error Code: " + err.errorCode + "Error Message: " + err.message;
                    alert(message);
                };
                Utility.newGuid = function () {
                    return 'xxxxxxxx-xxxx-xxxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                        return v.toString(16);
                    });
                };
                return Utility;
            }());
            Utils.Utility = Utility;
        })(Utils = AppCommon.Utils || (AppCommon.Utils = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var PublishXmlRequest = (function () {
        function PublishXmlRequest(parameterXml) {
            this.ParameterXml = parameterXml;
        }
        PublishXmlRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "ParameterXml": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                },
                operationName: "PublishXml",
                operationType: 0,
            };
            return metadata;
        };
        return PublishXmlRequest;
    }());
    ODataContract.PublishXmlRequest = PublishXmlRequest;
})(ODataContract || (ODataContract = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
/// <reference path="../../../../../TypeDefinitions/mscrm.d.ts" />
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var AddAppComponentsRequest = (function () {
        function AddAppComponentsRequest(appId, components) {
            this.AppId = appId;
            this.Components = components;
        }
        AddAppComponentsRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "AppId": {
                        "typeName": "Edm.Guid",
                        "structuralProperty": 1,
                    },
                    "Components": {
                        "typeName": "mscrm.crmbaseentity",
                        "structuralProperty": 4,
                    },
                },
                operationName: "AddAppComponents",
                operationType: 0,
            };
            return metadata;
        };
        return AddAppComponentsRequest;
    }());
    ODataContract.AddAppComponentsRequest = AddAppComponentsRequest;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts"/>
/// <reference path="../Common/Utility.ts"/>
/// <reference path="../freshell/libs/smbappmoduleappconfig-lib.d.ts" />
/// <reference path= "../../Controls/FREShell/DataContracts/PublishXmlRequest.ts" />
/// <reference path= "../../Controls/FREShell/DataContracts/AddAppComponentsRequest.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var BPF;
        (function (BPF) {
            'use strict';
            var BPFControlStyles = (function (_super) {
                __extends(BPFControlStyles, _super);
                function BPFControlStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._newBPFButtonLabel = {};
                    _this._newBPFButton = {};
                    _this._bpfContainer = {};
                    _this._context = context;
                    _this._newBPFButtonLabel = null;
                    _this._newBPFButton = null;
                    _this._bpfContainer = null;
                    return _this;
                }
                BPFControlStyles.prototype.NewBPFButtonLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._newBPFButtonLabel)) {
                        this._newBPFButtonLabel = {};
                        var isRTL = this._context.client.isRTL;
                        this._newBPFButtonLabel["margin"] = isRTL ? "auto auto auto 0.25rem" : "auto 0.25rem auto auto";
                        this._newBPFButtonLabel["cursor"] = "pointer";
                    }
                    return this._newBPFButtonLabel;
                };
                BPFControlStyles.prototype.NewBPFButton = function () {
                    if (this._context.utils.isNullOrUndefined(this._newBPFButton)) {
                        this._newBPFButton = {};
                        var isRTL = this._context.client.isRTL;
                        this._newBPFButton["borderWidth"] = "0px";
                        this._newBPFButton["cursor"] = "pointer";
                        this._newBPFButton["backgroundColor"] = "transparent";
                        this._newBPFButton["margin"] = isRTL ? "auto auto auto 1.5rem" : "auto 1.5rem auto auto";
                        this._newBPFButton["fontSize"] = this._context.theming.fontsizes.font100;
                        this._newBPFButton["color"] = "#0078D7";
                        this._newBPFButton["letterSpacing"] = "0px";
                        this._newBPFButton["whiteSpace"] = "nowrap";
                    }
                    return this._newBPFButton;
                };
                BPFControlStyles.prototype.BpfContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._bpfContainer)) {
                        this._bpfContainer = {};
                        this._bpfContainer["display"] = "flex";
                    }
                    return this._bpfContainer;
                };
                return BPFControlStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            BPF.BPFControlStyles = BPFControlStyles;
        })(BPF = AppCommon.BPF || (AppCommon.BPF = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var BPF;
        (function (BPF) {
            var BPFEntityAttribute = (function () {
                function BPFEntityAttribute() {
                }
                Object.defineProperty(BPFEntityAttribute, "NAME", {
                    //Attributes of Entity "Workflow" Entity
                    get: function () {
                        return { key: "name", value: "defaultBPF" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "PRIMARYENTIY", {
                    get: function () {
                        return { key: "primaryentity", value: "" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "XAML", {
                    get: function () {
                        return {
                            key: "xaml", value: '<?xml version="1.0" encoding="utf-16"?><Activity x:Class="XrmWorkflow00000000000000000000000000000000" xmlns="http://schemas.microsoft.com/netfx/2009/xaml/activities" xmlns:mcwb="clr-namespace:Microsoft.Crm.Workflow.BusinessProcessFlowActivities;assembly=Microsoft.Crm.Workflow, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" xmlns:mcwo="clr-namespace:Microsoft.Crm.Workflow.ObjectModel;assembly=Microsoft.Crm, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" xmlns:mva="clr-namespace:Microsoft.VisualBasic.Activities;assembly=System.Activities, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" xmlns:mxs="clr-namespace:Microsoft.Xrm.Sdk;assembly=Microsoft.Xrm.Sdk, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" xmlns:mxswa="clr-namespace:Microsoft.Xrm.Sdk.Workflow.Activities;assembly=Microsoft.Xrm.Sdk.Workflow, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" xmlns:scg="clr-namespace:System.Collections.Generic;assembly=mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" xmlns:sco="clr-namespace:System.Collections.ObjectModel;assembly=mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" xmlns:srs="clr-namespace:System.Runtime.Serialization;assembly=System.Runtime.Serialization, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" xmlns:this="clr-namespace:" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"><x:Members><x:Property Name="InputEntities" Type="InArgument(scg:IDictionary(x:String, mxs:Entity))" /><x:Property Name="CreatedEntities" Type="InArgument(scg:IDictionary(x:String, mxs:Entity))" /></x:Members><this:XrmWorkflow00000000000000000000000000000000.InputEntities><InArgument x:TypeArguments="scg:IDictionary(x:String, mxs:Entity)" /></this:XrmWorkflow00000000000000000000000000000000.InputEntities><this:XrmWorkflow00000000000000000000000000000000.CreatedEntities><InArgument x:TypeArguments="scg:IDictionary(x:String, mxs:Entity)" /></this:XrmWorkflow00000000000000000000000000000000.CreatedEntities><mva:VisualBasic.Settings>Assembly references and imported namespaces for internal implementation</mva:VisualBasic.Settings><mxswa:Workflow><mxswa:ActivityReference AssemblyQualifiedName="Microsoft.Crm.Workflow.Activities.EntityComposite, Microsoft.Crm.Workflow, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" DisplayName="EntityStep1: {3}"><mxswa:ActivityReference.Properties><sco:Collection x:TypeArguments="Variable" x:Key="Variables" /><sco:Collection x:TypeArguments="Activity" x:Key="Activities"><mxswa:ActivityReference AssemblyQualifiedName="Microsoft.Crm.Workflow.Activities.StageComposite, Microsoft.Crm.Workflow, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" DisplayName="StageStep2: New Stage"><mxswa:ActivityReference.Properties><sco:Collection x:TypeArguments="Variable" x:Key="Variables" /><sco:Collection x:TypeArguments="Activity" x:Key="Activities"><mxswa:ActivityReference AssemblyQualifiedName="Microsoft.Crm.Workflow.Activities.StepComposite, Microsoft.Crm.Workflow, Version=9.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" DisplayName="StepStep3: New Step"><mxswa:ActivityReference.Properties><sco:Collection x:TypeArguments="Variable" x:Key="Variables" /><sco:Collection x:TypeArguments="Activity" x:Key="Activities"><Sequence DisplayName="ControlStep4"><mcwb:Control ControlId="{0}" IsSystemControl="False" IsUnbound="False" SystemStepType="0"><mcwb:Control.ClassId><InArgument x:TypeArguments="x:String"><Literal x:TypeArguments="x:String" Value="" /></InArgument></mcwb:Control.ClassId><mcwb:Control.ControlDisplayName><InArgument x:TypeArguments="x:String"><Literal x:TypeArguments="x:String" Value="" /></InArgument></mcwb:Control.ControlDisplayName><mcwb:Control.DataFieldName><InArgument x:TypeArguments="x:String"><Literal x:TypeArguments="x:String" Value="" /></InArgument></mcwb:Control.DataFieldName><mcwb:Control.Parameters><InArgument x:TypeArguments="x:String"><Literal x:TypeArguments="x:String" Value="" /></InArgument></mcwb:Control.Parameters></mcwb:Control></Sequence></sco:Collection><sco:Collection x:TypeArguments="mcwo:StepLabel" x:Key="StepLabels"><mcwo:StepLabel Description="New Step" LabelId="{1}" LanguageCode="{4}" /></sco:Collection><x:String x:Key="ProcessStepId">{1}</x:String><x:Boolean x:Key="IsProcessRequired">False</x:Boolean></mxswa:ActivityReference.Properties></mxswa:ActivityReference></sco:Collection><sco:Collection x:TypeArguments="mcwo:StepLabel" x:Key="StepLabels"><mcwo:StepLabel Description="New Stage" LabelId="{2}" LanguageCode="{4}" /></sco:Collection><x:String x:Key="StageId">{2}</x:String><x:Null x:Key="StageCategory" /><x:Null x:Key="NextStageId" /></mxswa:ActivityReference.Properties></mxswa:ActivityReference></sco:Collection><x:Null x:Key="RelationshipName" /><x:Null x:Key="AttributeName" /><x:Boolean x:Key="IsClosedLoop">False</x:Boolean></mxswa:ActivityReference.Properties></mxswa:ActivityReference></mxswa:Workflow></Activity>'
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "WORKFLOWID", {
                    // This property will ensure that you get new workflowId always.
                    get: function () {
                        BPFEntityAttribute.workFlowId.value = AppCommon.Utils.Utility.newGuid();
                        return BPFEntityAttribute.workFlowId;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "TYPE", {
                    get: function () {
                        return { key: "type", value: 1 };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "CATEGORY", {
                    get: function () {
                        return { key: "category", value: 4 };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "SCOPE", {
                    get: function () {
                        return { key: "scope", value: 4 };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntityAttribute, "APPID", {
                    //Attributes of Entity "AppModuleComponent"
                    get: function () {
                        return { key: "AppId", value: "" };
                    },
                    enumerable: true,
                    configurable: true
                });
                return BPFEntityAttribute;
            }());
            BPFEntityAttribute.workFlowId = { key: "workflowid", value: "" };
            BPF.BPFEntityAttribute = BPFEntityAttribute;
            var BPFEntity = (function () {
                function BPFEntity() {
                }
                Object.defineProperty(BPFEntity, "WORKFLOW", {
                    get: function () {
                        return "workflow";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntity, "WORKFLOWENTITYTYPE", {
                    get: function () {
                        return "Microsoft.Dynamics.CRM.workflow";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BPFEntity, "ADDAPPCOMPONENTS", {
                    get: function () {
                        return "AddAppComponents";
                    },
                    enumerable: true,
                    configurable: true
                });
                return BPFEntity;
            }());
            BPF.BPFEntity = BPFEntity;
        })(BPF = AppCommon.BPF || (AppCommon.BPF = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var AddAppComponentsRequest = ODataContract.AddAppComponentsRequest;
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var BPF;
        (function (BPF) {
            var NewBPF = (function () {
                function NewBPF(BPFName, primaryEntity, context) {
                    this._BPFName = BPFName;
                    this._primaryEntity = primaryEntity;
                    this._context = context;
                    this._XAML = this.createXAML(BPF.BPFEntityAttribute.XAML.value, primaryEntity);
                    this._workflowId = BPF.BPFEntityAttribute.WORKFLOWID.value;
                    this._type = BPF.BPFEntityAttribute.TYPE.value;
                    this._category = BPF.BPFEntityAttribute.CATEGORY.value;
                    this._scope = BPF.BPFEntityAttribute.SCOPE.value;
                }
                Object.defineProperty(NewBPF.prototype, "WorkFlowID", {
                    get: function () { return this._workflowId; },
                    enumerable: true,
                    configurable: true
                });
                ;
                // Computing values of the parameters to be passed in templatise XAML
                NewBPF.prototype.createXAML = function (XAML, primaryEntityLogicalName) {
                    var controlId = AppCommon.Utils.Utility.newGuid(); //replaced at one place
                    var processStepId = AppCommon.Utils.Utility.newGuid();
                    ; //replaced at two places
                    var stageId = AppCommon.Utils.Utility.newGuid(); //replaced at two places
                    var languageCode = 1033; //replaced at one place #TODO:hardcoded
                    return this.formatXAML(XAML, controlId, processStepId, stageId, primaryEntityLogicalName, languageCode);
                };
                // Adding values of parameters in templatise XAML
                NewBPF.prototype.formatXAML = function (s) {
                    var args = [];
                    for (var _i = 1; _i < arguments.length; _i++) {
                        args[_i - 1] = arguments[_i];
                    }
                    for (var i = 0; i < args.length; i++) {
                        var reg = new RegExp("\\{" + i + "\\}", "gm");
                        s = s.replace(reg, args[i]);
                    }
                    return s;
                };
                NewBPF.prototype.createBPFAsync = function (successCallBack, errorCallBack) {
                    var record = {};
                    record[BPF.BPFEntityAttribute.NAME.key] = this._BPFName;
                    record[BPF.BPFEntityAttribute.PRIMARYENTIY.key] = this._primaryEntity;
                    record[BPF.BPFEntityAttribute.XAML.key] = this._XAML;
                    record[BPF.BPFEntityAttribute.WORKFLOWID.key] = this._workflowId;
                    record[BPF.BPFEntityAttribute.TYPE.key] = this._type;
                    record[BPF.BPFEntityAttribute.CATEGORY.key] = this._category;
                    record[BPF.BPFEntityAttribute.SCOPE.key] = this._scope;
                    // Creating the record in the workflow entity
                    var that = this;
                    // Create record in workflow entity.
                    this._context.webAPI.createRecord(BPF.BPFEntity.WORKFLOW, record)
                        .then(function (successParameter) {
                        // Create record in the appmodule component.
                        that.addWorkflowInAppmoduleComponent()
                            .then(function () { successCallBack(); }, function () {
                            errorCallBack("Error in creating record in AppModuleComponent entity");
                            SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.BUSINESSPROCESSFLOW, "Error in creating record in AppModuleComponent entity");
                        });
                    }, function (errorParameter) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.BUSINESSPROCESSFLOW, errorParameter);
                        errorCallBack("Error in creating record in Workflow entity");
                    });
                };
                //create a record in AppmoduleComponent
                NewBPF.prototype.addWorkflowInAppmoduleComponent = function () {
                    var appId = Mscrm.AppCommon.Common.Utility.GetCurrentAppId();
                    //"Microsoft.Dynamics.CRM.workflow"
                    var addAPPComponentContract = new AddAppComponentsRequest({ guid: appId }, [{ id: this._workflowId, entityType: BPF.BPFEntity.WORKFLOW }]);
                    return this._context.webAPI.execute(addAPPComponentContract);
                };
                return NewBPF;
            }());
            BPF.NewBPF = NewBPF;
        })(BPF = AppCommon.BPF || (AppCommon.BPF = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var BPF;
        (function (BPF) {
            // The Id of the controls rendered on the Dialog
            var DialogControls = (function () {
                function DialogControls() {
                }
                Object.defineProperty(DialogControls, "NAMEOFBUSINESSPROCESSFLOWID", {
                    get: function () {
                        return "NAMEOFBUSINESSPROCESSFLOWID";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogControls, "ENTITYOPTIONSETID", {
                    /*Id of the optionset control*/
                    get: function () {
                        return "ENTITYOPTIONSETID";
                    },
                    enumerable: true,
                    configurable: true
                });
                return DialogControls;
            }());
            BPF.DialogControls = DialogControls;
            // The name of the input, output parameter and options passed to the Dialog. 
            var DialogParam = (function () {
                function DialogParam() {
                }
                Object.defineProperty(DialogParam, "APPID", {
                    // Input parameters to the Dialog.
                    get: function () {
                        return "appmoduleid_param";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogParam, "SOLUTIONID", {
                    get: function () {
                        return "solutionid_param";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogParam, "ENTITYLIST", {
                    get: function () {
                        return "entitylist_param";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogParam, "SHOULDCREATEBPF", {
                    // Output parameters from Dialog.
                    get: function () {
                        return "shouldcreatebpf_param";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogParam, "SMBBPFDialog", {
                    // The id of the Dialog.
                    get: function () {
                        return "SMBBPFDialog";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogParam, "DIALOGPOSITIONRIGHT", {
                    // The options passed to the Dialog.
                    get: function () {
                        return 2;
                    },
                    enumerable: true,
                    configurable: true
                });
                return DialogParam;
            }());
            BPF.DialogParam = DialogParam;
            var BPFTelemetry = (function () {
                function BPFTelemetry() {
                }
                // Description: This metric measures number of times where the user created a new BPF.
                BPFTelemetry.NewBPFCreated = function (context) {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(context, 1, SmbAppsTelemetryUtility.Controls_PageType.BUSINESSPROCESSFLOW, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "BPFCustomizerPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "NewBPF Button Clicked", false);
                };
                // Description: This metric measures number of users who have visited this page. 
                BPFTelemetry.UserVisitedBPFPage = function (context) {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(context, 1, SmbAppsTelemetryUtility.Controls_PageType.BUSINESSPROCESSFLOW, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "BPFCustomizerPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "BPFPageVisited", false);
                };
                return BPFTelemetry;
            }());
            BPF.BPFTelemetry = BPFTelemetry;
            var Constants = (function () {
                function Constants() {
                }
                return Constants;
            }());
            Constants.Workflow = "workflow";
            Constants.DefaultViewId = "4722d513-e4f1-e611-80da-00155ded280d";
            Constants.BPFDialog = "Business_Process_Flow";
            Constants.PrimaryEntity = "primaryentity";
            Constants.ComponentType = 29;
            Constants.HeaderNormalIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/BPF.svg";
            Constants.HeaderHighContrastIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/BPF_HC.svg";
            Constants.BPFGridContainerKey = "BPFFREGridContainer";
            Constants.AddBPFIconContainerKey = "BPFPage.NewButton_label";
            Constants.AddBPFButtonKey = "BPFPage.NewButton";
            Constants.BPFHeaderSeparatorContainer = "BPF_FREHeaderSeparatorContainer";
            Constants.BPFHeaderRightContainer = "BPF_FREHeaderRightContainer";
            BPF.Constants = Constants;
        })(BPF = AppCommon.BPF || (AppCommon.BPF = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var BPF;
        (function (BPF) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "AreaLabel", {
                    get: function () {
                        return "BPFHomePage.AreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SubAreaLabel", {
                    get: function () {
                        return "BPFHomePage.SubAreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "NewBPFButtonLabel", {
                    get: function () {
                        return "BPFHomePage.NewBPFButtonLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "NewBPFButtonToolTip", {
                    get: function () {
                        return "BPFHomePage.NewBPFButtonToolTip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            BPF.ResourceKeys = ResourceKeys;
        })(BPF = AppCommon.BPF || (AppCommon.BPF = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=BPFControl.js.map