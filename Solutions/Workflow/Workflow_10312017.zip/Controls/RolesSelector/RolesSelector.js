var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        'use strict';
        var RolesSelector = (function () {
            /**
             * Empty constructor.
             */
            function RolesSelector() {
                //Strings
                this.rolesContainer = "RolesContainer";
                this.checkboxId = this.rolesContainer + "_cb";
                this.dataColumnId = this.rolesContainer + "_datacol";
                this.headerColumnId = this.rolesContainer + "_headercol";
                this.headerId = this.rolesContainer + "_header";
                this.rowId = this.rolesContainer + "_row";
                this.rowHeight = 20;
                this.checkboxPadding = 5;
                this._applyStyles = null;
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            RolesSelector.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this._theming = context.theming;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
                this._columnDefinitions = this.getColumnDefinitions() || {};
                this._rows = this.getData() || [];
                this._applyStyles = new AppCommon.RolesSelectorStyles(context);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            RolesSelector.prototype.updateView = function (context) {
                var _this = this;
                var children = [];
                // Push the header component onto children array.
                children.push(this.getHeaderComponent(this._columnDefinitions));
                // For each row in rows, push row component onto childern array.
                this._rows.forEach(function (row, index) {
                    children.push(_this.getRowComponent(row, index));
                });
                return this._context.factory.createElement("CONTAINER", {
                    id: this.rolesContainer,
                    key: this.rolesContainer,
                    style: this._applyStyles.ContentContainerChild()
                }, children);
            };
            RolesSelector.prototype.getHeaderComponent = function (headerColumns) {
                var _this = this;
                var children = [];
                // Push a dummy checkbox in children array.
                children.push(this._context.factory.createElement("BOOLEAN", {
                    type: "checkbox",
                    id: 'header_dummy_cb',
                    key: 'header_dummy_cb',
                    tagname: "INPUT",
                    style: this._applyStyles.GetHeaderCheckbox(),
                    value: false
                }));
                Object.keys(headerColumns).forEach(function (key, index) {
                    children.push(_this.getHeaderCellComponent(headerColumns[key], index));
                });
                return this._context.factory.createElement("CONTAINER", {
                    id: "" + this.headerId,
                    key: "" + this.headerId,
                    style: this._applyStyles.GetHeaderContainer()
                }, children);
            };
            RolesSelector.prototype.getRowComponent = function (row, index) {
                var _this = this;
                var children = [];
                // Push checkbox in children array.
                children.push(this._context.factory.createElement("BOOLEAN", {
                    type: "checkbox",
                    id: this.checkboxId + "_" + index,
                    key: this.checkboxId + "_" + index,
                    tagname: "INPUT",
                    style: this._applyStyles.GetRowCheckbox(),
                    value: false || row.IsSelected,
                    onValueChange: this.onRecordSelected.bind(this, row.Id)
                }));
                // Foreach column mentioned in column array get value of corresponding cell in this row and push in
                // child array
                Object.keys(row.CellValues).forEach(function (colName) {
                    children.push(_this.getCellComponent(row, colName, _this._columnDefinitions[colName], index));
                });
                return this._context.factory.createElement("CONTAINER", {
                    id: this.rowId + "_" + index,
                    key: this.rowId + "_" + index,
                    style: this._applyStyles.GetRowContainer()
                }, children);
            };
            RolesSelector.prototype.getCellComponent = function (row, colName, columnDefinition, index, cellStyle) {
                var cell = this._context.factory.createElement("LABEL", {
                    id: this.dataColumnId + "_" + columnDefinition.Name,
                    key: this.dataColumnId + "_" + columnDefinition.Name,
                    style: cellStyle || this._applyStyles.GetCellComponent(),
                    forElementId: this._context.accessibility.getUniqueId(this.checkboxId + "_" + index),
                    onClick: this.onRecordSelected.bind(this, row.Id)
                }, row.CellValues[colName]);
                return this._context.factory.createElement("CONTAINER", {
                    id: this.dataColumnId + "wrapper_" + columnDefinition.Name,
                    key: this.dataColumnId + "wrapper_" + columnDefinition.Name,
                    style: this._applyStyles.GetCellContainer() && { width: columnDefinition.Width + "px" }
                }, cell);
            };
            RolesSelector.prototype.getHeaderCellComponent = function (columnDefinition, index) {
                var headerCell = this._context.factory.createElement("LABEL", {
                    id: this.headerColumnId + "_" + index,
                    key: this.headerColumnId + "_" + index,
                    style: this._applyStyles.GetHeaderCellComponent()
                }, columnDefinition.DisplayName);
                return this._context.factory.createElement("CONTAINER", {
                    id: this.headerColumnId + "wrapper_" + index,
                    key: this.headerColumnId + "wrapper_" + index,
                    style: this._applyStyles.GetHeaderCellContainer() && { width: columnDefinition.Width + "px" }
                }, headerCell);
            };
            RolesSelector.prototype.getData = function () {
                //Expected format:
                // [
                //	{ Id: "1", IsSelected: true, CellValues: { rolename: "Administrator" } },
                //	{ Id: "2", IsSelected: false, CellValues: { rolename: "SalesSMB Rep" } },
                //	{ Id: "3", IsSelected: true, CellValues: { rolename: "SalesSMB Manager" } },
                //];
                if (this._context.parameters.rowsData) {
                    return this._context.parameters.rowsData.raw;
                }
                return null;
            };
            RolesSelector.prototype.getColumnDefinitions = function () {
                if (this._context.parameters.columnsDefinition) {
                    return this._context.parameters.columnsDefinition.raw;
                }
                return null;
            };
            RolesSelector.prototype.onRecordSelected = function (id) {
                this._rows.forEach(function (row) {
                    if (row.Id == id) {
                        row.IsSelected = !row.IsSelected;
                    }
                });
                this._context.utils.requestRender();
                this._notifyOutputChanged();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            RolesSelector.prototype.getOutputs = function () {
                return {
                    rowsData: this._rows
                };
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            RolesSelector.prototype.destroy = function () {
            };
            return RolesSelector;
        }());
        AppCommon.RolesSelector = RolesSelector;
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="RolesSelector.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var RolesSelectorStyles = (function (_super) {
            __extends(RolesSelectorStyles, _super);
            function RolesSelectorStyles(context) {
                var _this = _super.call(this, context) || this;
                _this._contentContainerChild = {};
                _this._getHeaderCheckbox = {};
                _this._getHeaderContainer = {};
                _this._getRowCheckbox = {};
                _this._getRowContainer = {};
                _this._getCellComponent = {};
                _this._getCellContainer = {};
                _this._getHeaderCellComponent = {};
                _this._getHeaderCellContainer = {};
                _this._context = context;
                _this._contentContainerChild = null;
                _this._getHeaderCheckbox = null;
                _this._getHeaderContainer = null;
                _this._getRowCheckbox = null;
                _this._getRowContainer = null;
                _this._getCellComponent = null;
                _this._getCellContainer = null;
                _this._getHeaderCellComponent = null;
                _this._getHeaderCellContainer = null;
                return _this;
            }
            RolesSelectorStyles.prototype.ContentContainerChild = function () {
                if (this._context.utils.isNullOrUndefined(this._contentContainerChild)) {
                    this._contentContainerChild = {};
                    this._contentContainerChild["display"] = "flex";
                    this._contentContainerChild["flexDirection"] = "column";
                    this._contentContainerChild["border"] = this._context.theming.borders.border02;
                    this._contentContainerChild["width"] = "100%";
                    this._contentContainerChild["white-space"] = "nowrap";
                    this._contentContainerChild["overflow"] = "hidden";
                    this._contentContainerChild["text-overflow"] = "ellipsis";
                }
                return this._contentContainerChild;
            };
            RolesSelectorStyles.prototype.GetHeaderCheckbox = function () {
                if (this._context.utils.isNullOrUndefined(this._getHeaderCheckbox)) {
                    this._getHeaderCheckbox = {};
                    this._getHeaderCheckbox["marginLeft"] = "5px";
                    this._getHeaderCheckbox["marginRight"] = "5px";
                    this._getHeaderCheckbox["visibility"] = "hidden";
                }
                return this._getHeaderCheckbox;
            };
            RolesSelectorStyles.prototype.GetHeaderContainer = function () {
                if (this._context.utils.isNullOrUndefined(this._getHeaderContainer)) {
                    this._getHeaderContainer = {};
                    this._getHeaderContainer["display"] = "flex";
                    this._getHeaderContainer["borderBottom"] = this._context.theming.borders.border02;
                    this._getHeaderContainer["height"] = "20px";
                    this._getHeaderContainer["alignItems"] = "center";
                }
                return this._getHeaderContainer;
            };
            RolesSelectorStyles.prototype.GetRowCheckbox = function () {
                if (this._context.utils.isNullOrUndefined(this._getRowCheckbox)) {
                    this._getRowCheckbox = {};
                    this._getRowCheckbox["marginLeft"] = "5px";
                    this._getRowCheckbox["marginRight"] = "5px";
                }
                return this._getRowCheckbox;
            };
            RolesSelectorStyles.prototype.GetRowContainer = function () {
                if (this._context.utils.isNullOrUndefined(this._getRowContainer)) {
                    this._getRowContainer = {};
                    this._getRowContainer["display"] = "flex";
                    this._getRowContainer["height"] = "20px";
                    this._getRowContainer["alignItems"] = "center";
                }
                return this._getRowContainer;
            };
            RolesSelectorStyles.prototype.GetCellComponent = function () {
                if (this._context.utils.isNullOrUndefined(this._getCellComponent)) {
                    this._getCellComponent = {};
                    this._getCellComponent["alignSelf"] = "center";
                    this._getCellComponent["height"] = "100%";
                    this._getCellComponent["cursor"] = "pointer";
                }
                return this._getCellComponent;
            };
            RolesSelectorStyles.prototype.GetCellContainer = function () {
                if (this._context.utils.isNullOrUndefined(this._getCellContainer)) {
                    this._getCellContainer = {};
                    this._getCellContainer["display"] = "block";
                    this._getCellContainer["textOverflow"] = "ellipsis";
                    this._getCellContainer["whiteSpace"] = "nowrap";
                    this._getCellContainer["overflow"] = "hidden";
                }
                return this._getCellContainer;
            };
            RolesSelectorStyles.prototype.GetHeaderCellComponent = function () {
                if (this._context.utils.isNullOrUndefined(this._getHeaderCellComponent)) {
                    this._getHeaderCellComponent = {};
                    this._getHeaderCellComponent["alignSelf"] = "center";
                    this._getHeaderCellComponent["height"] = "100%";
                    this._getHeaderCellComponent["cursor"] = "pointer";
                }
                return this._getHeaderCellComponent;
            };
            RolesSelectorStyles.prototype.GetHeaderCellContainer = function () {
                if (this._context.utils.isNullOrUndefined(this._getHeaderCellContainer)) {
                    this._getHeaderCellContainer = {};
                    this._getHeaderCellContainer["display"] = "block";
                    this._getHeaderCellContainer["textOverflow"] = "ellipsis";
                    this._getHeaderCellContainer["whiteSpace"] = "nowrap";
                    this._getHeaderCellContainer["overflow"] = "hidden";
                    this._getHeaderCellContainer["height"] = "100%";
                }
                return this._getHeaderCellContainer;
            };
            return RolesSelectorStyles;
        }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
        AppCommon.RolesSelectorStyles = RolesSelectorStyles;
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=RolesSelector.js.map