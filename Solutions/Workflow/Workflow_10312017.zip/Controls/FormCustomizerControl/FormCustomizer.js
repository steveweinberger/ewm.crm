/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/smbappmoduleappconfig-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FormCustomizer;
        (function (FormCustomizer) {
            'use strict';
            // imports
            var Utility = Mscrm.AppCommon.Common.Utility;
            var FREShell = MscrmControls.AppCommon.FREShell;
            var FormCustomizerControl = (function () {
                /* constructor */
                function FormCustomizerControl() {
                    var _this = this;
                    /* Private Variables */
                    this._appId = "";
                    this._asyncFunctionsInvoked = false;
                    this._filteredDataAvailableToRender = false;
                    this._filteringInputForFormCustomizer = "";
                    this._parkingSolutionId = "";
                    this._refreshCounter = 0;
                    /**
                    * The function is called by AppConfig integration module when grid filtering input is available
                    **/
                    this.requiredDataAvailableToRender = function (filteringInput) {
                        _this._filteringInputForFormCustomizer = filteringInput;
                        _this._filteredDataAvailableToRender = true;
                        _this._context.utils.requestRender();
                    };
                    /**
                    * The function is called by AppConfig integration module when parking solution id is retrieved
                    **/
                    this.parkingSolutionIdIsAvailable = function (parkingSolutionId) {
                        _this._parkingSolutionId = parkingSolutionId;
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 */
                FormCustomizerControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._asyncFunctionsInvoked = false;
                    this._context = context;
                    var title = this._context.resources.getString(FormCustomizer.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(FormCustomizer.ResourceKeys.SubAreaLabel) + " - " + this._context.resources.getString(FormCustomizer.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(this._context, title);
                    this._filteredDataAvailableToRender = false;
                    this._parkingSolutionId = null;
                    this._refreshCounter = 0;
                    // Add Telemetry Information
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.FORMS, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "FormCustomizationPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                    this._context.client.trackContainerResize(true);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                FormCustomizerControl.prototype.updateView = function (context) {
                    this._context = context;
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new AppCommon.AdvancedSettingCommonStyle(context);
                    }
                    if (!(this._asyncFunctionsInvoked)) {
                        this._appId = Utility.GetCurrentAppId();
                        this._appModuleAppConfig =
                            new MscrmControls.AppCommon.AppModuleAppConfig(this._context.webAPI, this._context.utils, FormCustomizer.FormCustomizerConstants.SystemFormComponentType, this._appId, this.requiredDataAvailableToRender.bind(this), this.parkingSolutionIdIsAvailable.bind(this));
                        this._appModuleAppConfig.AsyncGetFilteringInputForCustomizationGrid();
                        this._appModuleAppConfig.AsyncGetParkingSolution();
                        this._asyncFunctionsInvoked = true;
                    }
                    return this._freShell.getVirtualComponents(this.getChildControls(this._context));
                };
                /** Creates FRE Shell common content
                 * @param context
                 */
                FormCustomizerControl.prototype.getChildControls = function (context) {
                    var params = {};
                    params.normalIconImagePath = FormCustomizer.FormCustomizerConstants.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = FormCustomizer.FormCustomizerConstants.HeaderHighContrastIconImagePath;
                    params.areaLabel = this._context.resources.getString(FormCustomizer.ResourceKeys.AreaLabel);
                    params.subAreaLabel = this._context.resources.getString(FormCustomizer.ResourceKeys.SubAreaLabel);
                    /* Structure of Controls
                         bodyContainer
                            |----headerContainer
                                 |----headerLeftDivWithIcon
                                        |---headerLeftDivWithIcon
                                        |---headerLeftDiv
                                            |----customizationLbl
                                            |----formLbl
                            |----sectionContainer
                                |----formListLbl
                                |----gridContainer
                                    |----grid
                                |----designerIFrame
                        */
                    var formListLbl = context.factory.createElement("LABEL", { key: FormCustomizer.FormCustomizerConstants.FORMLISTLABELID, id: FormCustomizer.FormCustomizerConstants.FORMLISTLABELID, style: this._applyStyles.FREGridHeaderLabel() }, this._context.resources.getString(FormCustomizer.ResourceKeys.FormListLabel));
                    // Render grid only if filtered data is available to render
                    if (this._filteredDataAvailableToRender) {
                        // Read-Only grid to render System Forms which filters with following criteria:
                        // Retrieves all records from App Module
                        // Retrieves all forms as per mentioned savedqueryid(ViewId)
                        // Filter out records that are not white listed in App Config
                        var gridProps = {
                            parameters: {
                                Grid: {
                                    Type: "Grid",
                                    TargetEntityType: "systemform",
                                    ViewId: FormCustomizer.FormCustomizerConstants.FC_SavedQueryId,
                                    RefreshInput: {
                                        Static: true,
                                        Value: this._refreshCounter
                                    },
                                    FilteringInput: {
                                        Static: true,
                                        ControlLinked: false,
                                        Value: this._filteringInputForFormCustomizer
                                    },
                                    DataSetHostProps: {
                                        commandBarEnabled: true,
                                        jumpBarEnabled: true,
                                        quickFindEnabled: true,
                                        viewSelectorEnabled: false
                                    }
                                },
                                EnableGroupBy: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableFiltering: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableEditing: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                }
                            }
                        };
                        var grid = context.factory.createComponent("MscrmControls.Grid.GridControl", "cc_FRE_SystemViewList", gridProps);
                        var designerIframe = context.factory.createElement("IFRAME", {
                            id: "designerIFrame",
                            title: this._parkingSolutionId,
                            onLoad: this.onLoadDesigner.bind(this),
                            style: this._applyStyles.DesignerIframeStyle()
                        });
                        var gridContainer = context.factory.createElement("CONTAINER", {
                            key: FormCustomizer.FormCustomizerConstants.GRIDCONTAINERID, id: FormCustomizer.FormCustomizerConstants.GRIDCONTAINERID, style: this._applyStyles.FREGridContainer()
                        }, [grid]);
                        var sectionContainer = context.factory.createElement("CONTAINER", { key: FormCustomizer.FormCustomizerConstants.SECTIONCONTAINERID, id: FormCustomizer.FormCustomizerConstants.SECTIONCONTAINERID, style: this._applyStyles.FRESectionContainer() }, [formListLbl, gridContainer, designerIframe]);
                        params.contentContainerChild = sectionContainer;
                        this.onDesingerContainerResize();
                        this._freShell.stopPerformanceStopWatch();
                    }
                    return params;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                FormCustomizerControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                FormCustomizerControl.prototype.destroy = function () {
                };
                /**
                * This function handles event to resize the designer when the window get resized.
                * @param event
                */
                FormCustomizerControl.prototype.onDesingerContainerResize = function () {
                    var designerIFrame = document.getElementById("designerIFrame");
                    if (designerIFrame && designerIFrame.style && !(designerIFrame.style.width == "" || designerIFrame.style.width == "0%")) {
                        designerIFrame.style.width = this._applyStyles.FREDesignerWidth();
                        designerIFrame.style.height = this._applyStyles.FREDesignerHeight();
                    }
                };
                FormCustomizerControl.prototype.onLoadDesigner = function (event) {
                    var designerIFrame = document.getElementById("designerIFrame");
                    // Designer is being lauched first time
                    if (designerIFrame.style.display == "flex") {
                        if (designerIFrame.style.width == "" || designerIFrame.style.width == "0%") {
                            // Setting appId in the designer Iframe
                            var designerLaunchArgs = {};
                            designerLaunchArgs.AppModuleId = this._appId;
                            designerIFrame.contentWindow.DesignerLaunchArgs = designerLaunchArgs;
                            designerIFrame.style.width = this._applyStyles.FREDesignerWidth();
                            designerIFrame.style.height = this._applyStyles.FREDesignerHeight();
                        }
                        else {
                            this._refreshCounter = this._refreshCounter + 1;
                            designerIFrame.style.width = "0%";
                            designerIFrame.style.height = "0%";
                            designerIFrame.style.display = "none";
                        }
                        // Setting designerIFrame title to parking solution id, this id is used to launch desinger
                        // Currently there is a limitation as we cannot pass parameters from control page to command context.
                        designerIFrame.title = this._parkingSolutionId;
                    }
                };
                return FormCustomizerControl;
            }());
            FormCustomizer.FormCustomizerControl = FormCustomizerControl;
        })(FormCustomizer = AppCommon.FormCustomizer || (AppCommon.FormCustomizer = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="FormCustomizer.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FormCustomizer;
        (function (FormCustomizer) {
            'use strict';
            var FormCustomizerConstants = (function () {
                function FormCustomizerConstants() {
                }
                Object.defineProperty(FormCustomizerConstants, "SystemFormComponentType", {
                    get: function () {
                        return 60;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "WebApiBaseURL", {
                    get: function () {
                        return "/api/data/v9.0/";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "CUSTOMIZATIONLABELID", {
                    get: function () {
                        return "FormC_customizationLbl_FREAreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "FORMLABELID", {
                    get: function () {
                        return "FormC_formLbl_FRESubareaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "GRIDCONTAINERID", {
                    get: function () {
                        return "FormC_FREGridContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "FORMLISTLABELID", {
                    get: function () {
                        return "FormC_formLbl_FREGridHeaderLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "HEADERLEFTDIVID", {
                    get: function () {
                        return "FormC_FREHeaderLeft";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "HEADLEFTDIVWITHICONID", {
                    get: function () {
                        return "FormC_FREheaderLeftDivWithIcon";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "HEADERCONTAINERID", {
                    get: function () {
                        return "FormC_FREHeaderContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "SECTIONCONTAINERID", {
                    get: function () {
                        return "FormC_FRESectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "BODYCONTAINERID", {
                    get: function () {
                        return "FormC_FREBodyContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "FC_SavedQueryId", {
                    /* Saved Query Id for Form List Page */
                    get: function () {
                        return "38741D7E-B4BB-48F4-AD68-E42B0CC36525";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/Forms.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FormCustomizerConstants, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/Forms_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return FormCustomizerConstants;
            }());
            FormCustomizer.FormCustomizerConstants = FormCustomizerConstants;
        })(FormCustomizer = AppCommon.FormCustomizer || (AppCommon.FormCustomizer = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FormCustomizer;
        (function (FormCustomizer) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "AreaLabel", {
                    get: function () {
                        return "FormListHomePage.AreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SubAreaLabel", {
                    get: function () {
                        return "FormListHomePage.SubAreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FormListLabel", {
                    get: function () {
                        return "FormListHomePage.FormListLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            FormCustomizer.ResourceKeys = ResourceKeys;
        })(FormCustomizer = AppCommon.FormCustomizer || (AppCommon.FormCustomizer = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=FormCustomizer.js.map