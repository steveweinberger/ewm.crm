var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Core logic rendern composite custom contorl for System View List (Saved Queries)
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="../freshell/libs/smbappmoduleappconfig-lib.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SystemView;
        (function (SystemView) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            var SystemViewCtrl = (function () {
                /**
                 * Constructor.
                 */
                function SystemViewCtrl() {
                    var _this = this;
                    this._appId = "";
                    this._serviceURL = "";
                    this._filteringInputForViewList = "";
                    this._requiredDataAvailableToRender = false;
                    this._asyncFunctionsInvoked = false;
                    /**
                    * The function is called by AppConfig integration module when grid filtering input is available
                    **/
                    this.requiredDataAvailableToRender = function (filteringInput) {
                        _this._filteringInputForViewList = filteringInput;
                        //Rerendering the control with filtering input
                        _this._requiredDataAvailableToRender = true;
                        _this._context.utils.requestRender();
                    };
                    /**
                    * The function is called by AppConfig integration module when parking solution id is retrieved
                    **/
                    this.parkingSolutionIdIsAvailable = function (parkingSolutionId) {
                        _this._parkingSolutionId = parkingSolutionId;
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                SystemViewCtrl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    var title = this._context.resources.getString(SystemView.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(SystemView.ResourceKeys.AREA) + " - " + this._context.resources.getString(SystemView.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(this._context, title);
                    this._parkingSolutionId = null;
                    this._requiredDataAvailableToRender = false;
                    this._asyncFunctionsInvoked = false;
                    this._refreshCounter = 0;
                    this._context.client.trackContainerResize(true);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SystemViewCtrl.prototype.updateView = function (context) {
                    return this._freShell.getVirtualComponents(this.getChildControls(context));
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SystemViewCtrl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SystemViewCtrl.prototype.destroy = function () {
                };
                /**
                * Private methods
                */
                SystemViewCtrl.prototype.getChildControls = function (context) {
                    //icon content
                    var params = {};
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new SystemView.SystemViewStyles(context);
                    }
                    if (this._asyncFunctionsInvoked == false) {
                        this.setAppID();
                        //Initializing filtering input based on AppModule and AppConfig
                        this._requiredDataAvailableToRender = false;
                        this._appModuleAppConfig = new MscrmControls.AppCommon.AppModuleAppConfig(this._context.webAPI, this._context.utils, SystemView.SystemViewListConstants.SAVED_QUERY_COMPONENT_TYPE, this._appId, this.requiredDataAvailableToRender.bind(this), this.parkingSolutionIdIsAvailable.bind(this));
                        this._appModuleAppConfig.AsyncGetFilteringInputForCustomizationGrid();
                        this._appModuleAppConfig.AsyncGetParkingSolution();
                        this._asyncFunctionsInvoked = true;
                    }
                    if (this._requiredDataAvailableToRender) {
                        this._context = context;
                        params.normalIconImagePath = SystemView.SystemViewListConstants.HeaderNormalIconImagePath;
                        params.highContrastIconImagePath = SystemView.SystemViewListConstants.HeaderHighContrastIconImagePath;
                        params.areaLabel = this._context.resources.getString(SystemView.ResourceKeys.SUB_AREA);
                        params.subAreaLabel = this._context.resources.getString(SystemView.ResourceKeys.AREA);
                        // grid heading label
                        var gridHeadingLbl = context.factory.createElement("LABEL", { key: "viewListFREGridHeaderLabel", id: "viewListFREGridHeaderLabel", style: this._applyStyles.FREGridHeaderLabel() }, this._context.resources.getString(SystemView.ResourceKeys.GRID_HEADER));
                        // read-only grid to render system views 
                        var gridProps = {
                            parameters: {
                                Grid: {
                                    Type: "Grid",
                                    TargetEntityType: "savedquery",
                                    ViewId: "80D8928C-0FFA-4580-8672-57589339A64B",
                                    FilteringInput: {
                                        Static: true,
                                        ControlLinked: false,
                                        Value: this._filteringInputForViewList
                                    },
                                    RefreshInput: {
                                        Static: true,
                                        Value: this._refreshCounter
                                    },
                                    DataSetHostProps: {
                                        commandBarEnabled: true,
                                        jumpBarEnabled: true,
                                        quickFindEnabled: true,
                                        viewSelectorEnabled: false
                                    }
                                },
                                EnableGroupBy: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableFiltering: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableEditing: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                }
                            }
                        };
                        var grid = context.factory.createComponent("MscrmControls.Grid.GridControl", "cc_FRE_SystemViewList", gridProps);
                        //Grid container
                        var gridContainer = context.factory.createElement("CONTAINER", {
                            id: "viewListFREGridContainer", key: "viewListFREGridContainer",
                            style: this._applyStyles.FREGridContainer()
                        }, [grid]);
                        var designerIframe = context.factory.createElement("IFRAME", {
                            id: "designerIFrame",
                            title: this._parkingSolutionId,
                            onLoad: this.onLoadDesigner.bind(this),
                            style: this._applyStyles.DesignerIframeStyle(),
                        });
                        //Section Container
                        var sectionContainerProps = {
                            id: "sectionContainer", key: "sectionContainer", style: this._applyStyles.FRESectionContainer()
                        };
                        var sectionContainer = context.factory.createElement("CONTAINER", sectionContainerProps, [gridHeadingLbl, gridContainer, designerIframe]);
                        params.contentContainerChild = sectionContainer;
                        // Header CreateView Image container 
                        var zeroWidthContainer = context.factory.createElement("CONTAINER", { key: "ViewListCreteViewIconContainer", id: "ViewListCreteViewIconContainer", style: this._applyStyles.ViewListCreteViewIconContainer() }, []);
                        // Create View Button
                        var newButton = context.factory.createElement("BUTTON", {
                            key: SystemView.SystemViewListConstants.ViewListFREHeaderRightButtonStyle,
                            id: SystemView.SystemViewListConstants.ViewListFREHeaderRightButtonStyle,
                            tabIndex: 0,
                            title: this._context.resources.getString(SystemView.ResourceKeys.CREATE_NEW_TOOLTIP),
                            onClick: this.onNewButtonClicked.bind(this), style: this._applyStyles.FREHeaderRightButtonStyle()
                        }, [zeroWidthContainer, this._context.resources.getString(SystemView.ResourceKeys.CREATE_NEW)]);
                        params.headerRightContainerChild = newButton;
                        this.onDesingerContainerResize();
                        this._freShell.stopPerformanceStopWatch();
                    }
                    return params;
                };
                /**
                 * This function handles event to resize the designer when the window get resized.
                 * @param event
                 */
                SystemViewCtrl.prototype.onDesingerContainerResize = function () {
                    var designerIFrame = document.getElementById("designerIFrame");
                    if (designerIFrame && designerIFrame.style && !(designerIFrame.style.width == "" || designerIFrame.style.width == "0%")) {
                        designerIFrame.style.width = this._applyStyles.FREDesignerWidth();
                        designerIFrame.style.height = this._applyStyles.FREDesignerHeight();
                    }
                };
                /**
                 * This function handles events when designer get loaded with different src set
                 * @param event
                 */
                SystemViewCtrl.prototype.onLoadDesigner = function (event) {
                    var designerIFrame = document.getElementById("designerIFrame");
                    if (designerIFrame.style.display == "flex") {
                        //In case designer is being lauched first time or consequently
                        if (designerIFrame.style.width == "" || designerIFrame.style.width == "0%") {
                            //Setting appId in the designer Iframe
                            var designerLaunchArgs = {};
                            designerLaunchArgs.AppModuleId = this._appId;
                            designerIFrame.contentWindow.DesignerLaunchArgs = designerLaunchArgs;
                            designerIFrame.style.width = this._applyStyles.FREDesignerWidth();
                            designerIFrame.style.height = this._applyStyles.FREDesignerHeight();
                        }
                        else {
                            this._refreshCounter = this._refreshCounter + 1;
                            this._requiredDataAvailableToRender = false;
                            this._appModuleAppConfig.AsyncGetFilteringInputForCustomizationGrid();
                            designerIFrame.style.width = "0%";
                            designerIFrame.style.height = "0%";
                            designerIFrame.style.display = "none";
                        }
                        // Setting designerIFrame title to parking solution id, thie id is used to launch desinger in edit scenario
                        // Currently there is a limitation as we cannot pass parameters from control page to commnad context.
                        designerIFrame.title = this._parkingSolutionId;
                    }
                };
                /**
                * The function is to launch entity selector for new view create creation
                */
                SystemViewCtrl.prototype.onNewButtonClicked = function () {
                    var entityWhiteList = this._appModuleAppConfig.GetEntityWhiteListForCreateDialog();
                    var dialogParams = {};
                    dialogParams[SystemView.SystemViewListConstants.APPMODULE_FORM_PARAM] = this._appId;
                    dialogParams[SystemView.SystemViewListConstants.PARKINGSOLUTION_FORM_PARAM] = this._parkingSolutionId;
                    dialogParams[SystemView.SystemViewListConstants.DIALOGSELECTOPTIONS_FORM_PARAM] = entityWhiteList;
                    var dialogOpt = {};
                    dialogOpt.position = SystemView.SystemViewListConstants.MDD_DIALOG_POSITION_RIGHT;
                    var that = this;
                    this._context.navigation.openDialog(SystemView.SystemViewListConstants.VIEW_ENTITY_SELECTOR_MDD_NAME, dialogOpt, dialogParams).then(function (response) {
                        that._context.accessibility.focusElementById(SystemView.SystemViewListConstants.ViewListFREHeaderRightButtonStyle);
                    }, function (error) {
                        that._context.accessibility.focusElementById(SystemView.SystemViewListConstants.ViewListFREHeaderRightButtonStyle);
                    });
                };
                /**
                 *  This funciton will fetch the Appid from URL
                 */
                SystemViewCtrl.prototype.setAppID = function () {
                    this._appId = "";
                    if (window && window.top && window.top.location && window.top.location.href) {
                        var currentUrl = window.top.location.href;
                        var index = currentUrl.indexOf("?");
                        var queryString = currentUrl.toLowerCase().substring(index + 1, currentUrl.length);
                        var UrlVariables = queryString.split("&");
                        for (var i = 0; i < UrlVariables.length; i++) {
                            var Entry = UrlVariables[i].split("=");
                            var key = Entry.length === 2 ? Entry[0] : null;
                            if (key === "appid") {
                                this._appId = Entry[1];
                            }
                        }
                    }
                };
                return SystemViewCtrl;
            }());
            SystemView.SystemViewCtrl = SystemViewCtrl;
        })(SystemView = AppCommon.SystemView || (AppCommon.SystemView = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="control.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SystemView;
        (function (SystemView) {
            'use strict';
            var SystemViewListConstants = (function () {
                function SystemViewListConstants() {
                }
                Object.defineProperty(SystemViewListConstants, "APPMODULE_FORM_PARAM", {
                    get: function () {
                        return "appmodule_id";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "PARKINGSOLUTION_FORM_PARAM", {
                    get: function () {
                        return "parkingsolution_id";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "DIALOGSELECTOPTIONS_FORM_PARAM", {
                    get: function () {
                        return "dialogselect_options";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "VIEW_ENTITY_SELECTOR_MDD_NAME", {
                    get: function () {
                        return "SMBAppViewCustomizationEntityListDialog";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "SAVED_QUERY_COMPONENT_TYPE", {
                    get: function () {
                        return 26;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "ENTITY_COMPONENT_TYPE", {
                    get: function () {
                        return 1;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "MDD_DIALOG_POSITION_RIGHT", {
                    get: function () {
                        return 2;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/Views.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/Views_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SystemViewListConstants, "ViewListFREHeaderRightButtonStyle", {
                    get: function () {
                        return "ViewListFREHeaderRightButtonStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                return SystemViewListConstants;
            }());
            SystemView.SystemViewListConstants = SystemViewListConstants;
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "AREA", {
                    get: function () {
                        return "SystemViewList_AreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SUB_AREA", {
                    get: function () {
                        return "SystemViewList_SubAreaLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "CREATE_NEW", {
                    get: function () {
                        return "SystemViewList_CreateNewLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "CREATE_NEW_TOOLTIP", {
                    get: function () {
                        return "SystemViewList_CreateNewTooltip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "GRID_HEADER", {
                    get: function () {
                        return "SystemViewList_GridHeaderLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SettingsTooltip", {
                    get: function () {
                        return "SystemViewList_Settings";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            SystemView.ResourceKeys = ResourceKeys;
        })(SystemView = AppCommon.SystemView || (AppCommon.SystemView = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SystemView;
        (function (SystemView) {
            'use strict';
            var SystemViewStyles = (function (_super) {
                __extends(SystemViewStyles, _super);
                function SystemViewStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._viewListCreteViewIconContainer = {};
                    _this._context = context;
                    _this._viewListCreteViewIconContainer = null;
                    return _this;
                }
                SystemViewStyles.prototype.ViewListCreteViewIconContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._viewListCreteViewIconContainer)) {
                        this._viewListCreteViewIconContainer = {};
                        this._viewListCreteViewIconContainer["display"] = "flex";
                        this._viewListCreteViewIconContainer["justifyContent"] = "center";
                        this._viewListCreteViewIconContainer["alignItems"] = "center";
                        this._viewListCreteViewIconContainer["backgroundColor"] = "transparent";
                        this._viewListCreteViewIconContainer["margin"] = "0.4rem";
                    }
                    return this._viewListCreteViewIconContainer;
                };
                return SystemViewStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            SystemView.SystemViewStyles = SystemViewStyles;
        })(SystemView = AppCommon.SystemView || (AppCommon.SystemView = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SystemViewList.js.map