/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var InviteUser;
        (function (InviteUser) {
            'use strict';
            var RetrieveCurrentOrganizationRequest = ODataContract.RetrieveCurrentOrganizationRequest;
            var EndpointAccessType = ODataContract.EndpointAccessType;
            var CommonUtils = Mscrm.AppCommon.Common.Utility;
            var WEBAPPLICATION = "WebApplication";
            var InviteUserControl = (function () {
                /**
                 * constructor.
                 */
                function InviteUserControl() {
                    this._context = null;
                    this._heightIFrame = null;
                    this._gladosInviteUserUrl = null;
                    this._organizationId = null;
                    this._isFunctionSetGladosUrlForInviteUserCalled = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                InviteUserControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._organizationId = this._getOrganizationId();
                    this._context.client.trackContainerResize(true);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                InviteUserControl.prototype.updateView = function (context) {
                    this._context = context;
                    this._heightIFrame = this._getAvailableHeight();
                    if (!this._isFunctionSetGladosUrlForInviteUserCalled) {
                        this._setGladosUrlForInviteUser();
                        this._isFunctionSetGladosUrlForInviteUserCalled = true;
                    }
                    if (!CommonUtils.isNullOrUndefined(this._gladosInviteUserUrl)) {
                        var dialogIFrame = this._context.factory.createElement("IFRAME", {
                            key: InviteUser.Constants.IFrameKey, id: InviteUser.Constants.IFrameKey,
                            title: this._context.resources.getString(InviteUser.ResourceKeys.IFrameTitle),
                            src: this._gladosInviteUserUrl,
                            style: {
                                width: "100%",
                                height: this._heightIFrame
                            }
                        });
                        return dialogIFrame;
                    }
                    var loadingLabel = this._context.factory.createElement("LABEL", {
                        key: InviteUser.Constants.LoadingLabelKey, id: InviteUser.Constants.LoadingLabelKey
                    }, this._context.resources.getString(InviteUser.ResourceKeys.LoadingText));
                    var blankContainer = this._context.factory.createElement("CONTAINER", {
                        key: InviteUser.Constants.BlankContainerKey, id: InviteUser.Constants.BlankContainerKey,
                        style: {
                            display: "flex",
                            flex: "1 1 auto",
                            alignItems: "center",
                            justifyContent: "center"
                        }
                    }, [loadingLabel]);
                    return blankContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                InviteUserControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                InviteUserControl.prototype.destroy = function () {
                };
                /**
                 * Generates URL needed for InviteUser iframe
                 */
                InviteUserControl.prototype._setGladosUrlForInviteUser = function () {
                    var that = this;
                    var retrieveCurrentOrganizationRequest = new RetrieveCurrentOrganizationRequest(EndpointAccessType.Default);
                    this._context.webAPI.execute(retrieveCurrentOrganizationRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                /*
                                Sample format of JSON retrived by the OData call
                                {
                                    "Detail": {
                                        "Endpoints": {
                                            "Count": 3,
                                            "IsReadOnly": false,
                                            "Keys": [
                                                "WebApplication",
                                                "OrganizationService",
                                                "OrganizationDataService"
                                            ],
                                            "Values": [
                                                "https://someorg.crmx.something.com/",
                                                "https://someorg.crmx.something.com/XRMServices/2011/Organization.svc",
                                                "https://someorg.crmx.something.com/XRMServices/2011/OrganizationData.svc"
                                            ]
                                        }
                                    }
                                }
                                */
                                var index = jsonResponse.Detail.Endpoints.Keys.indexOf(WEBAPPLICATION);
                                if (index != -1) {
                                    var webApplicationEndpoint = jsonResponse.Detail.Endpoints.Values[index];
                                    var crmUrl = CommonUtils.GetCrmHostName(webApplicationEndpoint);
                                    that._gladosInviteUserUrl = "https://port." + crmUrl + "/G/Users/Invite.aspx?organizationId=" + that._organizationId;
                                }
                                else {
                                    var alertMessage = {
                                        text: that._context.resources.getString(InviteUser.ResourceKeys.WebApplicationEnpointNotFound),
                                        confirmButtonLabel: that._context.resources.getString(InviteUser.ResourceKeys.ConfirmButtonText)
                                    };
                                    that._context.navigation.openAlertDialog(alertMessage);
                                }
                                that._context.utils.requestRender();
                            });
                        }
                    }, function (error) {
                        that._gladosInviteUserUrl = null;
                        console.error(error);
                        var alertMessage = {
                            text: that._context.resources.getString(InviteUser.ResourceKeys.WebApiRequestFailed),
                            confirmButtonLabel: that._context.resources.getString(InviteUser.ResourceKeys.ConfirmButtonText)
                        };
                        that._context.navigation.openAlertDialog(alertMessage);
                        that._context.utils.requestRender();
                    });
                };
                /**
                 * Get available height for Iframe
                 */
                InviteUserControl.prototype._getAvailableHeight = function () {
                    var height = window.top.document.body.offsetHeight;
                    return (height - 90);
                };
                /**
                 * get organizationid from context
                 */
                InviteUserControl.prototype._getOrganizationId = function () {
                    var orgSettings = this._context.client.orgSettings;
                    var organizationId = orgSettings.organizationId;
                    organizationId = organizationId.replace(/[{}]/g, '');
                    return organizationId;
                };
                return InviteUserControl;
            }());
            InviteUser.InviteUserControl = InviteUserControl;
        })(InviteUser = AppCommon.InviteUser || (AppCommon.InviteUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="InviteUserControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: Constants contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var InviteUser;
        (function (InviteUser) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                Object.defineProperty(Constants, "IFrameKey", {
                    get: function () {
                        return "inviteUser_IFrame";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "LoadingLabelKey", {
                    get: function () {
                        return "inviteUser_LoadingLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "BlankContainerKey", {
                    get: function () {
                        return "inviteUser_BlankContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Constants;
            }());
            InviteUser.Constants = Constants;
        })(InviteUser = AppCommon.InviteUser || (AppCommon.InviteUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var InviteUser;
        (function (InviteUser) {
            /**
             * Class refers to the path of all the keys for localization
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "WebApiRequestFailed", {
                    get: function () {
                        return "WebApiRequestFailed";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "WebApplicationEnpointNotFound", {
                    get: function () {
                        return "WebApplicationEnpointNotFound";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "IFrameTitle", {
                    get: function () {
                        return "IFrameTitle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "LoadingText", {
                    get: function () {
                        return "LoadingText";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            InviteUser.ResourceKeys = ResourceKeys;
        })(InviteUser = AppCommon.InviteUser || (AppCommon.InviteUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=InviteUserControl.js.map