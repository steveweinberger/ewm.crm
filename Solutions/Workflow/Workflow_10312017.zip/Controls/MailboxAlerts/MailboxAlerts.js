/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var MailboxAlerts;
        (function (MailboxAlerts_1) {
            'use strict';
            var AlertType;
            (function (AlertType) {
                AlertType[AlertType["INFO"] = 0] = "INFO";
                AlertType[AlertType["WARNING"] = 1] = "WARNING";
                AlertType[AlertType["ERROR"] = 2] = "ERROR";
            })(AlertType = MailboxAlerts_1.AlertType || (MailboxAlerts_1.AlertType = {}));
            var MailboxAlerts = (function () {
                /**
                 * Empty constructor.
                 */
                function MailboxAlerts() {
                    this._isLoading = true;
                    this._alertsArray = [];
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                MailboxAlerts.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._mailboxId = this._context.parameters.mailboxId.raw;
                    this._URL = "/api/data/v9.0/tracelogs?$select=text,level,createdon&$filter=_regardingobjectid_value%20eq%20" + this._mailboxId;
                    var that = this;
                    $.getJSON(this._context.utils.createCrmUri(this._URL))
                        .done(function (data) {
                        that._alertsArray = data.value.map(that.decodeAlert);
                        that._isLoading = false;
                        that._context.utils.requestRender();
                    });
                };
                MailboxAlerts.prototype.decodeAlert = function (json) {
                    var text = json.text;
                    var nameTag = text.substring(text.indexOf("@["), text.indexOf("]")).split(",")[2].replace(/['"\\]+/g, '');
                    //@\[((0-9){5},(.*),\"(a-z A-Z)*\\")\]
                    var cleanText = text.replace(/@\[(.*)\]+/g, nameTag);
                    var alert = AlertType.ERROR;
                    switch (json.level) {
                        case 1:
                            alert = AlertType.INFO;
                        case 2:
                            alert = AlertType.WARNING;
                        default:
                            alert = AlertType.ERROR;
                    }
                    return {
                        name: nameTag,
                        message: cleanText,
                        date: new Date(json.createdon),
                        type: alert
                    };
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                MailboxAlerts.prototype.updateView = function (context) {
                    this._context = context;
                    var containerList = [];
                    if (!this._isLoading) {
                        containerList.push(this._containerAlertList());
                    }
                    var pageContainer = this._context.factory.createElement("CONTAINER", {
                        id: "page",
                        key: "page",
                        style: {}
                    }, containerList);
                    return pageContainer;
                };
                MailboxAlerts.prototype._containerNameText = function (alert, counter) {
                    var name = this._context.factory.createElement("LABEL", {
                        id: "name" + counter,
                        key: "name" + counter,
                        style: MailboxAlerts_1.Styling._styleName()
                    }, alert.name);
                    return name;
                };
                MailboxAlerts.prototype._containerMessageText = function (alert, counter) {
                    var messageLabel = this._context.factory.createElement("LABEL", {
                        id: "message" + counter,
                        key: "message" + counter,
                        style: MailboxAlerts_1.Styling._styleMessage()
                    }, alert.message);
                    return messageLabel;
                };
                MailboxAlerts.prototype._containerDateText = function (alert, counter) {
                    var dateLabel = this._context.factory.createElement("LABEL", {
                        id: "date" + counter,
                        key: "date" + counter,
                        style: MailboxAlerts_1.Styling._styleDate()
                    }, alert.date.toLocaleDateString());
                    return dateLabel;
                };
                MailboxAlerts.prototype._containerAlertTextContainer = function (alert, counter) {
                    var textContainer = this._context.factory.createElement("CONTAINER", {
                        id: "text" + counter,
                        key: "text" + counter,
                        style: MailboxAlerts_1.Styling._styleAlertText()
                    }, [this._containerNameText(alert, counter), this._containerMessageText(alert, counter), this._containerDateText(alert, counter)]);
                    return textContainer;
                };
                MailboxAlerts.prototype._containerAlertIcon = function (alert, counter) {
                    var imageContainer = this._context.factory.createElement("IMG", {
                        id: "img" + counter,
                        key: "img" + counter,
                        source: "",
                        style: MailboxAlerts_1.Styling._styleAlertIcon()
                    }, []);
                    return imageContainer;
                };
                MailboxAlerts.prototype._containerAlertItem = function (alert, counter) {
                    var alertContainer = this._context.factory.createElement("CONTAINER", {
                        id: "alert" + counter,
                        key: "alert" + counter,
                        style: MailboxAlerts_1.Styling._styleAlertItem()
                    }, [this._containerAlertIcon(alert, counter), this._containerAlertTextContainer(alert, counter)]);
                    return alertContainer;
                };
                MailboxAlerts.prototype._containerAlertList = function () {
                    var alertList = [];
                    for (var counter in this._alertsArray) {
                        var alert_1 = this._alertsArray[counter];
                        alertList.push(this._containerAlertItem(alert_1, counter));
                    }
                    var alertListContainer = this._context.factory.createElement("LIST", {
                        id: "alerts",
                        key: "aalerts",
                        style: MailboxAlerts_1.Styling._stylePage()
                    }, alertList);
                    return alertListContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                MailboxAlerts.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                MailboxAlerts.prototype.destroy = function () {
                };
                return MailboxAlerts;
            }());
            MailboxAlerts_1.MailboxAlerts = MailboxAlerts;
        })(MailboxAlerts = AppCommon.MailboxAlerts || (AppCommon.MailboxAlerts = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="MailboxAlerts.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var MailboxAlerts;
        (function (MailboxAlerts) {
            'use strict';
            var Styling = (function () {
                function Styling() {
                }
                Styling._styleName = function () {
                    var style = {};
                    style["fontSize"] = "1.2rem";
                    style["fontFamily"] = "Segoe UI Bold";
                    style["color"] = "#666666";
                    return style;
                };
                Styling._styleMessage = function () {
                    var style = {};
                    style["fontSize"] = "0.85rem";
                    style["fontFamily"] = "Segoe UI Regular";
                    style["color"] = "#000000";
                    return style;
                };
                Styling._styleDate = function () {
                    var style = {};
                    style["fontSize"] = "0.85rem";
                    style["fontFamily"] = "Segoe UI Regular";
                    style["color"] = "#666666";
                    return style;
                };
                Styling._styleAlertText = function () {
                    var style = {};
                    style["flexDirection"] = "column";
                    return style;
                };
                Styling._styleAlertIcon = function () {
                    var style = {};
                    return style;
                };
                Styling._styleAlertItem = function () {
                    var style = {};
                    style["flexDirection"] = "row";
                    style["borderWidth"] = "1px";
                    style["borderStyle"] = "solid";
                    style["borderColor"] = "#CCCCCC";
                    return style;
                };
                Styling._stylePage = function () {
                    var style = {};
                    style["flexDirection"] = "column";
                    style["justifyContent"] = "flex-start";
                    style["backgroundColor"] = "#FFFFFF";
                    style["flex"] = "1 1 auto";
                    style["whiteSpace"] = "normal";
                    style["width"] = "100%";
                    return style;
                };
                return Styling;
            }());
            MailboxAlerts.Styling = Styling;
        })(MailboxAlerts = AppCommon.MailboxAlerts || (AppCommon.MailboxAlerts = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=MailboxAlerts.js.map