var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var SampleEditorCustomControl;
    (function (SampleEditorCustomControl) {
        var AssistEditSourceDataSetPropertyNames = (function () {
            function AssistEditSourceDataSetPropertyNames() {
            }
            Object.defineProperty(AssistEditSourceDataSetPropertyNames, "fieldsName", {
                get: function () { return 'fields'; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AssistEditSourceDataSetPropertyNames, "itemTypeName", {
                get: function () { return 'itemType'; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AssistEditSourceDataSetPropertyNames, "syntaxName", {
                get: function () { return 'syntax'; },
                enumerable: true,
                configurable: true
            });
            return AssistEditSourceDataSetPropertyNames;
        }());
        SampleEditorCustomControl.AssistEditSourceDataSetPropertyNames = AssistEditSourceDataSetPropertyNames;
    })(SampleEditorCustomControl = MscrmControls.SampleEditorCustomControl || (MscrmControls.SampleEditorCustomControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="CommonReferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var SampleEditorCustomControl;
    (function (SampleEditorCustomControl_1) {
        'use strict';
        var Object = MktSvc.Controls.Common.Object;
        var String = MktSvc.Controls.Common.String;
        var EventBroker = MktSvc.Controls.Common.EventBroker;
        var SampleEditorCustomControl = (function (_super) {
            __extends(SampleEditorCustomControl, _super);
            function SampleEditorCustomControl() {
                var _this = this;
                _super.call(this);
                this.ajaxCall = new MktSvc.Controls.Common.AjaxCall();
                this.controlTabbingManager = new Editor.ControlTabbingManager();
                this.initialHeight = 600;
                this.minWidth = 643;
                this.contentFinalizedHandler = function (eventArgs) {
                    if (_this.finalizedHtml !== eventArgs.html) {
                        _this.finalizedHtml = eventArgs.html;
                        _this.notifyEnabledControlOutputChanged();
                    }
                };
                this.maximizeToggleHandler = function (eventArgs) {
                    _this.fullScreenProvider(eventArgs.isFullscreen);
                    if (eventArgs.isFullscreen === false) {
                        $(_this.container).height(_this.initialHeight);
                    }
                    else {
                        $(_this.container).height('100%');
                    }
                };
                // Sample template that would trigger the drag and drop designer
                this.dragAndDropDesignerExampleTemplate = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title></title><meta name="referrer" content="never"/><meta type="xrm/designer/setting" name="version" value="1.0"><meta type="xrm/designer/setting" name="type" value="marketing-designer-content-editor-document"></head><body><div class="wrapperContainer" data-container="true"></div></body></html>';
                // Sample template that would not trigger the drag and drop designer, rather, rich text editor
                this.template = '<p></p>';
                this.editorControlFactory = new SampleEditorCustomControl_1.SampleEditorControlFactory();
                this.browserPreviewFactory = new Editor.BrowserPreviewFactory();
            }
            SampleEditorCustomControl.prototype.getEventBroker = function () {
                return this.editor.getEventBroker();
            };
            /**
             * Initializes the Input Mask control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             */
            SampleEditorCustomControl.prototype.initCore = function (context) {
                var _this = this;
                // TODO: remove 'any' and condition after moving to the CRM 9.0
                if (!Object.isNullOrUndefined(context.client.trackContainerResize)) {
                    context.client.trackContainerResize(true);
                }
                /*
                 * TODO: remove Xrm, when context.page.getClientUrl() will work on webclient. (Bug: 557161)
                 * Currently UClient breaks when multiple controls fetch window.xrm at the same time. Workaround: defaultly try uclient first. (Bug: 646489)  */
                var clientUrl = "";
                try {
                    clientUrl = context.page.getClientUrl();
                }
                catch (err) {
                    clientUrl = window.Xrm.Utility.getGlobalContext().getClientUrl();
                }
                var logger = new MktSvcCommon.Logger.TelemetryLogger("MscrmControls.SampleEditorControl", context);
                var getLabelsPromise = new MktSvc.Controls.Common.LabelsProvider(context.userSettings.languageId.toString(), this.ajaxCall, logger, clientUrl + "/WebResources/msdyncrm_").getLabels();
                this.renderEditorPromise = $.when(getLabelsPromise)
                    .done(function (labels) {
                    var executionContext = new SampleEditorCustomControl_1.EditorExecutionContext(new MktSvc.Controls.Common.LocalizationProvider(labels, context.userSettings.languageId.toString(), context.client.isRtl, logger), logger, clientUrl + "/WebResources/msdyncrm_");
                    $(_this.container).height(_this.initialHeight);
                    if (Object.isNullOrUndefined(context.parameters.value.raw)) {
                        // Fix for the issue with incorrect updating
                        context.parameters.value.raw = _this.template;
                    }
                    _this.initPreview(executionContext);
                    _this.initEditor(context, executionContext);
                })
                    .fail(function () { throw new Error("Labels were not loaded."); });
                // TODO Replace it with context.accessibility.assignedTabIndex once mscrm.d.ts typings are updated
                var assignedTabIndex = !Object.isNullOrUndefined(context.accessibility) ? context.accessibility.assignedTabIndex : 0;
                this.controlTabbingManager.init(this.container, assignedTabIndex);
            };
            /**
             * Updates the control with data from the a bag of values currently assigned to the control's manifest parameters
             * @params context The bag of values described above
             */
            SampleEditorCustomControl.prototype.updateCore = function (context) {
                if (!(MktSvc.Controls.Common.Object.isNullOrUndefined(context) || MktSvc.Controls.Common.Object.isNullOrUndefined(context.updatedProperties) || context.updatedProperties.length === 0)) {
                    if (context.updatedProperties.indexOf(Editor.CommonConstants.fullscreenClose) !== -1) {
                        this.editor.getEventBroker().notify(Editor.EventConstants.exitFullScreenButtonClicked);
                        this.editor.getEventBroker().notify(Editor.EventConstants.maximizeExecuted, new Editor.FullScreenChangedEventArgs(false));
                    }
                }
                if (Object.isNullOrUndefined(context.parameters.value)) {
                    // Fix for the issue with incorrect updating
                    context.parameters.value = {};
                }
            };
            /**
             * Handles edit mode rendering.
             * Method should be overridden in the controls specialized classes.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             */
            SampleEditorCustomControl.prototype.renderEditMode = function (context) {
                var _this = this;
                if (!this.canEditorBeRendered(context)) {
                    this.renderReadMode(context);
                }
                else {
                    this.renderEditorPromise = this.renderEditorPromise.done(function () {
                        _super.prototype.renderEditMode.call(_this, context);
                        _this.showEditor();
                        _this.hide(_this.previewId);
                        _this.preview.deactivate();
                        // Prevent components updates if the content does not changed
                        if (String.isNullOrEmpty(_this.editor.getContent()) || _this.editor.getContent() !== context.parameters.value.raw) {
                            _this.editor.setContent(context.parameters.value.raw);
                        }
                        _this.shouldNotifyOutputChanged = true;
                    }).fail(function () { throw new Error("Unexpected error. Edit mode was not rendered."); });
                }
            };
            /**
             * Handles edit mode rendering.
             * Method should be overridden in the controls specialized classes.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             */
            SampleEditorCustomControl.prototype.renderReadMode = function (context) {
                var _this = this;
                this.renderEditorPromise = this.renderEditorPromise.done(function () {
                    _super.prototype.renderReadMode.call(_this, context);
                    _this.hideEditor();
                    _this.show(_this.previewId);
                    _this.preview.activate();
                    var eventArgs = new Editor.ContentChangedEventArgs(context.parameters.value.raw, '');
                    _this.previewEventBroker.notify(Editor.EventConstants.contentFinalized, eventArgs);
                }).fail(function () { throw new Error("Unexpected error. Read mode was not rendered."); });
                ;
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            SampleEditorCustomControl.prototype.getOutputsCore = function () {
                var result = {
                    value: Object.isNullOrUndefined(this.editor) ? String.Empty : this.editor.getContent()
                };
                return result;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            SampleEditorCustomControl.prototype.destroyCore = function () {
                // unsubscribe event handlers
                this.editor.getEventBroker().unsubscribe(Editor.EventConstants.maximizeExecuted, this.maximizeToggleHandler);
                this.editor.getEventBroker().unsubscribe(Editor.EventConstants.contentFinalized, this.contentFinalizedHandler);
                // dispose editor
                this.editor.dispose();
                this.preview.dispose();
                this.controlTabbingManager.dispose();
                $(this.container).empty();
            };
            /**
             * Notifies output changed only if the control has a full mask or is empty
             */
            SampleEditorCustomControl.prototype.notifyEnabledControlOutputChanged = function () {
                try {
                    _super.prototype.notifyEnabledControlOutputChanged.call(this);
                }
                catch (e) {
                }
            };
            SampleEditorCustomControl.prototype.showEditor = function () {
                this.show(this.editorId);
                var eventArgs = new Editor.VisibilityChangedEventArgs(true);
                this.editor.getEventBroker().notify(Editor.EventConstants.editorVisibilityChanged, eventArgs);
            };
            SampleEditorCustomControl.prototype.hideEditor = function () {
                this.hide(this.editorId);
                var eventArgs = new Editor.VisibilityChangedEventArgs(false);
                this.editor.getEventBroker().notify(Editor.EventConstants.editorVisibilityChanged, eventArgs);
            };
            SampleEditorCustomControl.prototype.show = function (elemantId) {
                $('#' + elemantId).show();
            };
            SampleEditorCustomControl.prototype.hide = function (elemantId) {
                $('#' + elemantId).hide();
            };
            SampleEditorCustomControl.prototype.initPreview = function (executionContext) {
                this.previewId = MktSvc.Controls.Common.ControlGuidGenerator.newGuid("preview_container");
                var previewContainer = $('<div>');
                previewContainer.attr('id', this.previewId);
                previewContainer.addClass('editorPreviewContainer');
                $(this.container).append(previewContainer);
                this.previewEventBroker = new EventBroker(executionContext.getLogger());
                this.preview = this.browserPreviewFactory.create(this.previewId, false, new MktSvc.Controls.Common.KeyboardCommandManager(), executionContext);
                this.preview.init(this.previewEventBroker);
            };
            SampleEditorCustomControl.prototype.initEditor = function (context, executionContext) {
                this.editorId = MktSvc.Controls.Common.ControlGuidGenerator.newGuid("editor_container");
                this.editor = this.createEditor(context, executionContext);
                var editorContainer = $('<div>');
                editorContainer.attr('id', this.editorId);
                $(this.container).append(editorContainer);
                this.editor.init(editorContainer);
                this.editor.getEventBroker().subscribe(Editor.EventConstants.contentFinalized, this.contentFinalizedHandler);
                var castClient = context.client;
                this.fullScreenProvider = castClient.setFullscreen;
                this.editor.getEventBroker().subscribe(Editor.EventConstants.maximizeExecuted, this.maximizeToggleHandler);
            };
            SampleEditorCustomControl.prototype.createEditor = function (context, executionContext) {
                var imagePickerControlFactory = new MktSvcCommon.ImagePicker.ImagePickerCustomControlFactory(context);
                var editorPlugin = new Editor.BasicPlugin(imagePickerControlFactory.create());
                return this.editorControlFactory.create(editorPlugin, executionContext);
            };
            SampleEditorCustomControl.prototype.canEditorBeRendered = function (context) {
                var isContextReadOnly = context.mode.isRead || context.mode.isPreview || (context.page && context.page.isPageReadOnly);
                var isWidthAllocatedInitialized = !MktSvc.Controls.Common.Object.isNullOrUndefined(context.client.allocatedWidth);
                var isWidthAllocated = context.client.allocatedWidth > 0 && $(this.container).width() > 0;
                var isWidthEnough = $(this.container).width() >= this.minWidth;
                return !isContextReadOnly && isWidthAllocatedInitialized && (isWidthEnough || !isWidthAllocated);
            };
            return SampleEditorCustomControl;
        }(MktSvcCommon.FieldControlBase));
        SampleEditorCustomControl_1.SampleEditorCustomControl = SampleEditorCustomControl;
    })(SampleEditorCustomControl = MscrmControls.SampleEditorCustomControl || (MscrmControls.SampleEditorCustomControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="typings/Editor.d.ts" />
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="editorexecutioncontext.ts" />
/// <reference path="SampleEditorCustomControl.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="CommonReferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var SampleEditorCustomControl;
    (function (SampleEditorCustomControl) {
        'use strict';
        var EditorExecutionContext = (function () {
            function EditorExecutionContext(localizationProvider, logger, cdnPath) {
                this.libsFolder = "libs";
                this.defaultContextExecution = new Editor.DefaultExecutionContext(localizationProvider, logger, cdnPath, this.libsFolder);
            }
            /*
            Gets the logger
            */
            EditorExecutionContext.prototype.getLogger = function () {
                return this.defaultContextExecution.getLogger();
            };
            /*
           Gets the localization provider
           */
            EditorExecutionContext.prototype.getLocalizationProvider = function () {
                return this.defaultContextExecution.getLocalizationProvider();
            };
            /*
            Gets default time for the delay scheuler - the number of milliseconds to wait before scheduling the operation
            */
            EditorExecutionContext.prototype.getDelaySchedulerTime = function () {
                return this.defaultContextExecution.getDelaySchedulerTime();
            };
            /*
            Gets base cdn path for external dependencies
            */
            EditorExecutionContext.prototype.getBasePath = function () {
                return this.defaultContextExecution.getBasePath();
            };
            /*
            Gets libs cdn path for external dependencies
            */
            EditorExecutionContext.prototype.getLibsPath = function () {
                return this.defaultContextExecution.getLibsPath();
            };
            /*
            Gets the content sanitizer.
            */
            EditorExecutionContext.prototype.getContentSanitizer = function () {
                return this.defaultContextExecution.getContentSanitizer();
            };
            /*
            Gets the configuration provider.
            */
            EditorExecutionContext.prototype.getConfigurationProvider = function () {
                return null;
            };
            /*
            Gets a bool to indicate whether to sandbox the preview frame
            */
            EditorExecutionContext.prototype.isSandboxed = function () {
                return true;
            };
            ;
            /*
            Tries to execute the action and log the error on fail.
            */
            EditorExecutionContext.prototype.tryExecute = function (action, event, throwError, onErrorAction) {
                this.defaultContextExecution.tryExecute(action, event, throwError, onErrorAction);
            };
            /*
            Dispose.
            */
            EditorExecutionContext.prototype.dispose = function () {
                this.defaultContextExecution.dispose();
                this.defaultContextExecution = null;
            };
            return EditorExecutionContext;
        }());
        SampleEditorCustomControl.EditorExecutionContext = EditorExecutionContext;
    })(SampleEditorCustomControl = MscrmControls.SampleEditorCustomControl || (MscrmControls.SampleEditorCustomControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="commonreferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var SampleEditorCustomControl;
    (function (SampleEditorCustomControl) {
        'use strict';
        var ArrayQuery = MktSvc.Controls.Common.ArrayQuery;
        var UniqueId = MktSvc.Controls.Common.UniqueId;
        var EventBroker = MktSvc.Controls.Common.EventBroker;
        var SampleEditorControlFactory = (function () {
            function SampleEditorControlFactory() {
            }
            SampleEditorControlFactory.prototype.create = function (plugin, executionContext) {
                Editor.CommonUtils.localizationProvider = executionContext.getLocalizationProvider();
                var eventBroker = new EventBroker(executionContext.getLogger());
                var blockDefinition = new Editor.BlockDefinitionFactory().create(plugin);
                var keyboardCommandManager = new MktSvc.Controls.Common.KeyboardCommandManager();
                var tools = new ArrayQuery(plugin.getTools());
                var toolBlockMapping = plugin.getToolBlockMapping();
                var sections = plugin.getSections ? new ArrayQuery(plugin.getSections()) : null;
                var sectionToToolsMapping = plugin.getSectionToolsMapping ? plugin.getSectionToolsMapping() : null;
                var controlToTabItemConverter = new Editor.ControlToTabItemConverter(eventBroker);
                var focusManagerFactory = new Editor.FocusManagerFactory();
                var designerFocusManager = focusManagerFactory.create(eventBroker, Editor.EventConstants.onElementFocussedIn, Editor.EventConstants.onKeypressToFocusPreviousElementCalled);
                var designerContentEditor = new Editor.DesignerContentEditorFactory().create(plugin, executionContext, eventBroker, designerFocusManager, keyboardCommandManager, blockDefinition);
                var keyboardAccessibilityManager = new Editor.KeyboardAccessibilityManager();
                var fullPageContentEditor = new Editor.FullPageContentEditorFactory().create(plugin, executionContext, eventBroker, keyboardCommandManager);
                var toolboxView = new Editor.ToolboxView(UniqueId.generate('toolboxId'), tools, toolBlockMapping, keyboardAccessibilityManager, keyboardCommandManager, executionContext, sections, sectionToToolsMapping);
                var detailsView = new Editor.DetailsView(UniqueId.generate('detailsViewId'), plugin.getBlockDetailsViewMapping(), keyboardCommandManager);
                var browserPreviewView = new Editor.BrowserPreviewFactory().create(UniqueId.generate('browserPreviewViewId'), true, keyboardCommandManager, executionContext);
                var menuBarView = new Editor.MenuBarView(UniqueId.generate('menuBarViewId'), new ArrayQuery([
                    new Editor.UndoButton(UniqueId.generate('undoButtonId')),
                    new Editor.RedoButton(UniqueId.generate('redoButtonId')),
                    new Editor.ToolsDropdown(UniqueId.generate('toolsDropdownId'), new Editor.AddToolsDropdownButton(), tools, toolBlockMapping),
                    new Editor.MaximizeButton(UniqueId.generate('maximizeButtonId'))
                ]), keyboardCommandManager);
                var detailsViewFactory = new Editor.DetailsViewControlFactory();
                var stylesView = new Editor.StylesView(UniqueId.generate('stylesViewId'), detailsViewFactory.create(), new Editor.MetadataFieldRendererFactory(plugin.getBlockDetailsViewMapping(), detailsViewFactory.create()), keyboardCommandManager);
                var htmlContentEditor = new Editor.HtmlContentEditorFactory().create(keyboardCommandManager, executionContext);
                var layoutRenderer = new Editor.LayoutRenderer();
                var designerEditorLayout = new Editor.LayoutConfiguration();
                designerEditorLayout.cssClass = 'designerContentEditor';
                var fullPageEditorLayout = new Editor.LayoutConfiguration();
                fullPageEditorLayout.cssClass = 'fullPageContentEditor';
                var previewLayout = new Editor.LayoutConfiguration();
                previewLayout.cssClass = 'preview';
                var layout = new Editor.LayoutConfiguration();
                layout.cssClass = 'editorContainer';
                var menuBarControlLayout = new Editor.LayoutConfiguration();
                menuBarControlLayout.cssClass = 'menuBarControlLayout';
                var designerTabButtonViewLayout = new Editor.ComponentLayoutConfiguration();
                designerTabButtonViewLayout.cssClass = 'designerTabButtonView';
                designerTabButtonViewLayout.id = UniqueId.generate('designerTabButtonView');
                var previewTabButtonViewLayout = new Editor.ComponentLayoutConfiguration();
                previewTabButtonViewLayout.cssClass = 'previewTabButtonView';
                previewTabButtonViewLayout.id = UniqueId.generate('previewTabButtonView');
                var menuBarLayout = new Editor.ComponentLayoutConfiguration();
                menuBarLayout.id = menuBarView.id;
                menuBarLayout.cssClass = 'menuBar';
                var designerLayout = new Editor.ComponentLayoutConfiguration();
                designerLayout.id = designerContentEditor.id;
                designerLayout.cssClass = 'designer';
                var designerTabView = new Editor.TabControl(UniqueId.generate('designerTabView'), new ArrayQuery([
                    controlToTabItemConverter.convert(toolboxView, Editor.CommonUtils.getLocalizedString("[TOOLBOX]"), Editor.CommonConstants.toolboxTabContentClassName),
                    controlToTabItemConverter.convert(detailsView, Editor.CommonUtils.getLocalizedString("[DETAILS]"), Editor.CommonConstants.detailsTabContentClassName),
                    controlToTabItemConverter.convert(stylesView, Editor.CommonUtils.getLocalizedString("[STYLES]"), Editor.CommonConstants.stylesTabContentClassName)]), executionContext, designerTabButtonViewLayout.id);
                var previewTabView = new Editor.TabControl(UniqueId.generate('previewTabView'), new ArrayQuery([
                    controlToTabItemConverter.convert(browserPreviewView, Editor.CommonUtils.getLocalizedString("[BASICPREVIEW]"), Editor.CommonConstants.browserPreviewTabContentClassName)]), executionContext, previewTabButtonViewLayout.id);
                var designerTabViewLayout = new Editor.ComponentLayoutConfiguration();
                designerTabViewLayout.cssClass = 'designerTabView';
                designerTabViewLayout.id = designerTabView.id;
                designerEditorLayout.components = new ArrayQuery([new ArrayQuery([designerLayout, designerTabButtonViewLayout, designerTabViewLayout])]);
                var previewViewLayout = new Editor.ComponentLayoutConfiguration();
                previewViewLayout.id = previewTabView.id;
                previewViewLayout.cssClass = 'previewView';
                previewLayout.components = new ArrayQuery([new ArrayQuery([previewTabButtonViewLayout]), new ArrayQuery([previewViewLayout])]);
                var designerEditor = new Editor.ComposeControl(UniqueId.generate('designerContentEditor'), new ArrayQuery([designerContentEditor, designerTabView]), layoutRenderer, designerEditorLayout);
                var previewView = new Editor.ComposeControl(UniqueId.generate('previewView'), new ArrayQuery([previewTabView]), layoutRenderer, previewLayout);
                menuBarControlLayout.components = new ArrayQuery([new ArrayQuery([menuBarLayout])]);
                var menuBarControl = new Editor.ComposeControl(UniqueId.generate('menuBarControl'), new ArrayQuery([menuBarView]), layoutRenderer, menuBarControlLayout);
                var designerTab = new Editor.TabControlItem(Editor.CommonUtils.getLocalizedString("[DESIGNER]"), designerEditor.id, function () { return designerEditor.init(eventBroker); }, function () { return designerEditor.activate(); }, function () { return designerEditor.deactivate(); }, function () { return designerEditor.dispose(); }, Editor.CommonConstants.designerTabContentClassName);
                var fullPageTab = new Editor.TabControlItem(Editor.CommonUtils.getLocalizedString("[FULL PAGE]"), fullPageContentEditor.id, function () { return fullPageContentEditor.init(eventBroker); }, function () { return fullPageContentEditor.activate(); }, function () { return fullPageContentEditor.deactivate(); }, function () { return fullPageContentEditor.dispose(); }, Editor.CommonConstants.fullPageContentEditorcssClass);
                var tabVisibilityManager = new Editor.TabControlVisibilityManager(new MktSvc.Controls.Common.ArrayQuery([new Editor.DesignerTabItemVisibility(designerTab), new Editor.FullPageTabItemVisibility(fullPageTab)]), eventBroker);
                var contentEditorTabControl = new Editor.TabControl(UniqueId.generate('contentEditorTab'), new ArrayQuery([
                    designerTab,
                    fullPageTab,
                    controlToTabItemConverter.convert(htmlContentEditor, Editor.CommonUtils.getLocalizedString("[HTML]"), Editor.CommonConstants.htmlTabContentClassName),
                    controlToTabItemConverter.convert(previewView, Editor.CommonUtils.getLocalizedString("[PREVIEW]"), Editor.CommonConstants.previewViewClassName)]), executionContext, menuBarView.id, tabVisibilityManager);
                var conentEditorLayout = new Editor.ComponentLayoutConfiguration();
                conentEditorLayout.id = contentEditorTabControl.id;
                conentEditorLayout.cssClass = 'contentEditor';
                layout.components = new ArrayQuery([new ArrayQuery([menuBarLayout]), new ArrayQuery([conentEditorLayout])]);
                // If the control should author a well formed HTML Document, e.g. doctype, html, head, body - <html><head></head><div>My Content!</div><body></body></html>,
                // then provide an instance of a new Editor.DocumentContentModel().
                // 
                // If the editor should author a HTML fragment, e.g <div>My Content!</div>, then, provide an instance of a new Editor.FragmentContentModel().
                var contentModel = new Editor.FragmentContentModel(executionContext, new Editor.MetadataParser(executionContext), eventBroker, new ArrayQuery([new Editor.SetOrphanBlockContainerWrapContentModelProcessor(), new Editor.SetContainerIdContentModelProcessor(), new Editor.SetBlockIdContentModelProcessor()]), new ArrayQuery([new Editor.RemoveContainerIdContentModelProcessor(), new Editor.RemoveBlockIdContentModelProcessor()]));
                return new Editor.EditorControl(executionContext, layoutRenderer, layout, new ArrayQuery([contentEditorTabControl, menuBarControl]), eventBroker, contentModel, keyboardCommandManager, new Editor.UndoRedoManager());
            };
            return SampleEditorControlFactory;
        }());
        SampleEditorCustomControl.SampleEditorControlFactory = SampleEditorControlFactory;
    })(SampleEditorCustomControl = MscrmControls.SampleEditorCustomControl || (MscrmControls.SampleEditorCustomControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SampleEditorCustomControl.js.map