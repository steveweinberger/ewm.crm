var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SummaryPage;
        (function (SummaryPage) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            var PageType;
            (function (PageType) {
                PageType[PageType["control"] = 0] = "control";
                PageType[PageType["webresource"] = 1] = "webresource";
                PageType[PageType["designer"] = 2] = "designer";
            })(PageType || (PageType = {}));
            var SummaryPageControl = (function () {
                /**
                 * Empty constructor.
                 */
                function SummaryPageControl() {
                    this._mapImagesByWebResourceID = {};
                    this._dialogOpen = false;
                    this.isInitialized = undefined;
                    this._applyStyles = null;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                SummaryPageControl.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    this._currentPageControlName = SummaryPage.SummaryPageHelper.GetURLVariableValue(SummaryPage.SummaryPageStrings.QueryStringCustomControlKey);
                    var title = (SummaryPage.SummaryPageHelper.IsAppshellmodeBasic() ? this._context.resources.getString(SummaryPage.ResourceKeys.QuickSetupText) : this._context.resources.getString(SummaryPage.ResourceKeys.SubareaLabelForAdvancedShellMode)) + " - " + this._context.resources.getString(SummaryPage.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(this._context, title);
                    this.isInitialized = false;
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SummaryPageControl.prototype.updateView = function (context) {
                    // custom code goes here
                    if (!this.isInitialized) {
                        this.initializeData(context);
                    }
                    else {
                        if (context && context.client && context.client.getClient() == SummaryPage.SummaryPageStrings.AppClient) {
                            if (!this._dialogOpen) {
                                var alertMessage = {
                                    text: this._context.resources.getString(SummaryPage.ResourceKeys.FormFactorOrDeviceNotSupportedMessage),
                                };
                                this._dialogOpen = true;
                                this._context.navigation.openAlertDialog(alertMessage, null)
                                    .then(function successCallBack(successResponse) {
                                    // On clicking OK button, the user will land on the previous visited page.
                                    if (window && window.history) {
                                        window.history.back();
                                    }
                                });
                            }
                            return;
                        }
                        return this._freShell.getVirtualComponents(this.getChildControls(this._context));
                    }
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SummaryPageControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SummaryPageControl.prototype.destroy = function () {
                };
                SummaryPageControl.prototype.getChildControls = function (context) {
                    var IsAppshellmodeBasic = SummaryPage.SummaryPageHelper.IsAppshellmodeBasic();
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new SummaryPage.SummaryPageStyles(context);
                    }
                    var params = {};
                    params.normalIconImagePath = SummaryPage.SummaryPageStrings.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = SummaryPage.SummaryPageStrings.HeaderHighContrastIconImagePath;
                    params.areaLabel = "";
                    params.subAreaLabel = this._context.resources.getString(SummaryPage.ResourceKeys.SubareaLabelForAdvancedShellMode);
                    params.contentContainerStyle = this._applyStyles.ContentContainerStyle();
                    params.bodyContainerStyle = this._applyStyles.FREExtendedBodyContainer();
                    if (!context.utils.isNullOrUndefined(this._NavJsondata)) {
                        // for accessibility
                        var tabIndexerCount = 0;
                        var mydata = JSON.parse(this._NavJsondata);
                        var appId = SummaryPage.SummaryPageHelper.GetURLVariableValue(SummaryPage.SummaryPageStrings.QueryStringAppIdKey);
                        var gotoBasicUrl = function (e) {
                            window.top.location.href = window.top.location.href.replace(SummaryPage.SummaryPageStrings.QueryStringAppShellModeAdvanced, SummaryPage.SummaryPageStrings.QueryStringAppShellModeBasic);
                        };
                        var keyDownLinkforgotoBasicUrl = function (e) {
                            if (e.key === 'Enter')
                                window.top.location.href = window.top.location.href.replace(SummaryPage.SummaryPageStrings.QueryStringAppShellModeAdvanced, SummaryPage.SummaryPageStrings.QueryStringAppShellModeBasic);
                        };
                        var gotoBasicSetupLink;
                        var gotoBasicSetupContainer;
                        // Depending on the appshell mode hide and display the go to basic setup link
                        if (IsAppshellmodeBasic) {
                            gotoBasicSetupLink = context.factory.createElement("LABEL", {
                                key: "InBasicSetupLabel",
                                id: "InBasicSetupLabel", style: this._applyStyles.InBasicSetupContainer()
                            }, this._context.resources.getString(SummaryPage.ResourceKeys.SetupInformationForBasicShellMode));
                            gotoBasicSetupContainer = context.factory.createElement("CONTAINER", {
                                id: "FREHeaderRightContainer",
                                key: "FREHeaderRightContainer",
                                tabIndex: tabIndexerCount,
                                style: this._applyStyles.FREHeaderRightContainer()
                            }, [gotoBasicSetupLink]);
                            params.headerRightContainerChild = gotoBasicSetupContainer;
                        }
                        else {
                            gotoBasicSetupLink = context.factory.createElement("BUTTON", {
                                key: "FREHeaderRightButtonStyle",
                                id: "FREHeaderRightButtonStyle",
                                onClick: gotoBasicUrl,
                                tabIndex: tabIndexerCount,
                                onKeyDown: keyDownLinkforgotoBasicUrl,
                                title: this._context.resources.getString(SummaryPage.ResourceKeys.GotoSetupLinkForAdvancedShellModeToolTip),
                                style: this._applyStyles.FREHeaderRightButtonStyle(),
                                role: "link"
                            }, [this._context.resources.getString(SummaryPage.ResourceKeys.GotoSetupLinkForAdvancedShellMode)]);
                            gotoBasicSetupContainer = context.factory.createElement("CONTAINER", {
                                id: "FREHeaderRightContainerStyle",
                                key: "FREHeaderRightContainerStyle",
                                style: this._applyStyles.FREHeaderRightContainer()
                            }, [gotoBasicSetupLink]);
                            params.headerRightContainerChild = gotoBasicSetupContainer;
                        }
                        //1.2 Top 2nd Container to display the description
                        var summaryDescLbl = context.factory.createElement("LABEL", {
                            key: "summaryDescLbl",
                            id: "summaryDescLbl"
                        }, this._context.resources.getString(SummaryPage.ResourceKeys.SummaryDescription));
                        var top3ContainerProps = {
                            id: "topDescContainer", key: "topDescContainer", style: this._applyStyles.TopDescContainer()
                        };
                        var top3Container = context.factory.createElement("CONTAINER", top3ContainerProps, [summaryDescLbl]);
                        var areaContainer;
                        var sectionWiseContainer = {};
                        var currentPageUrl = window.top.location.href;
                        for (var i = 0; i < mydata.Groups.length; i++) {
                            if (mydata.Groups[i].SubAreas.length > 0) {
                                var countValue = i + 1;
                                var areaName = mydata.Groups[i].Name;
                                //To display the section/area name
                                var areaLbl = context.factory.createElement("LABEL", {
                                    key: "areaLbl" + countValue,
                                    id: "areaLbl" + countValue,
                                    role: "heading"
                                }, areaName);
                                var areaLblContainer = {
                                    id: "areaLblContainer" + countValue,
                                    key: "areaLblContainer" + countValue, style: this._applyStyles.AreaLblContainer()
                                };
                                areaContainer = context.factory.createElement("CONTAINER", areaLblContainer, [areaLbl]);
                                var tileContainer = {};
                                for (var j = 0; j < mydata.Groups[i].SubAreas.length; j++) {
                                    var tileCountValue = j + 1;
                                    // Tile Image
                                    var imgtileIcon = context.factory.createElement("IMG", {
                                        key: "tileImage" + mydata.Groups[i].SubAreas[j].Id + countValue + tileCountValue,
                                        id: "tileImage" + mydata.Groups[i].SubAreas[j].Id + countValue + tileCountValue, style: this._applyStyles.TileImage(),
                                        altText: mydata.Groups[i].SubAreas[j].Name,
                                        source: context.utils.isNullOrUndefined(this._mapImagesByWebResourceID[mydata.Groups[i].SubAreas[j].IconResourceId]) ? this._mapImagesByWebResourceID[SummaryPage.SummaryPageStrings.defaultIconToDisplayOnTile] : this._mapImagesByWebResourceID[mydata.Groups[i].SubAreas[j].IconResourceId]
                                    });
                                    // Tile Name & Detials
                                    var tileLbl = context.factory.createElement("LABEL", {
                                        key: "tileLbl" + countValue + tileCountValue,
                                        id: "tileLbl" + countValue + tileCountValue, style: this._applyStyles.TileLbl()
                                    }, mydata.Groups[i].SubAreas[j].Name);
                                    // Creating tile Link by replacing current pagetype/pageid in the current page url by tile's pagetype/pageid
                                    var pageURL = mydata.Groups[i].SubAreas[j].Url;
                                    var linkforTileContainer = this.getLinkForTileContainer(pageURL);
                                    //In case the summary page is loaded in basic shell, tile links should have appshellmode=advanced instead of basic
                                    linkforTileContainer = linkforTileContainer.replace(SummaryPage.SummaryPageStrings.QueryStringAppShellModeBasic, SummaryPage.SummaryPageStrings.QueryStringAppShellModeAdvanced);
                                    var keyDownLinkforTileContainer = function (e) {
                                        if (e.key === 'Enter')
                                            document.getElementById(this.id).click();
                                    };
                                    var tileContainerProps = {
                                        id: "tileContainer" + countValue + tileCountValue,
                                        key: "tileContainer" + countValue + tileCountValue,
                                        tabIndex: tabIndexerCount,
                                        href: linkforTileContainer,
                                        onKeyDown: keyDownLinkforTileContainer, style: this._applyStyles.TileContainer()
                                    };
                                    tileContainer[j] = context.factory.createElement("HYPERLINK", tileContainerProps, [imgtileIcon, tileLbl]);
                                }
                                var sectionDetailContainerProps = {
                                    id: "sectionDetailContainer" + countValue,
                                    key: "sectionDetailContainer" + countValue, style: this._applyStyles.SectionDetailContainer()
                                };
                                var sectionDetailContainer = context.factory.createElement("CONTAINER", sectionDetailContainerProps, [tileContainer[0], tileContainer[1], tileContainer[2], tileContainer[3], tileContainer[4], tileContainer[5], tileContainer[6], tileContainer[7], tileContainer[8], tileContainer[9]]);
                                //sectionWiseContainer
                                var sectionWiseContainerProps = {
                                    id: "sectionWiseContainer" + countValue,
                                    key: "sectionWiseContainer" + countValue, style: this._applyStyles.SectionWiseContainer()
                                };
                                //Container to display a line
                                var displayLineContainerProps = {
                                    id: "displayLineContainer" + countValue, key: "displayLineContainer" + countValue, style: this._applyStyles.DisplayLineContainer()
                                };
                                var displayLineContainer = context.factory.createElement("CONTAINER", displayLineContainerProps);
                                sectionWiseContainer[i] = context.factory.createElement("CONTAINER", sectionWiseContainerProps, [areaContainer, displayLineContainer, sectionDetailContainer]);
                            }
                        }
                        //mainSectionContainer
                        var mainSectionContainerProps = {
                            id: "mainSectionContainer",
                            key: "mainSectionContainer", style: this._applyStyles.MainSectionContainer()
                        };
                        var mainSectionContainer = context.factory.createElement("CONTAINER", mainSectionContainerProps, [top3Container, sectionWiseContainer[0], sectionWiseContainer[1], sectionWiseContainer[2], sectionWiseContainer[3], sectionWiseContainer[4], sectionWiseContainer[5], sectionWiseContainer[6], sectionWiseContainer[7], sectionWiseContainer[8], sectionWiseContainer[9]]);
                        params.contentContainerChild = mainSectionContainer;
                        this._freShell.stopPerformanceStopWatch();
                    }
                    return params;
                };
                SummaryPageControl.prototype.initializeJsonData = function (uri) {
                    return $.ajax({
                        url: uri,
                        type: 'GET',
                        async: true,
                        beforeSend: function (request) {
                            request.setRequestHeader("OData-MaxVersion", "4.0");
                            request.setRequestHeader("OData-Version", "4.0");
                            request.setRequestHeader("Accept", "application/json");
                            request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                            request.setRequestHeader("Cache-Control", " no-cache, no-store, must-revalidate");
                            request.setRequestHeader("Pragma", " no-cache");
                            request.setRequestHeader("Expires", "0");
                            request.setRequestHeader("If-None-Match", "");
                        }
                    });
                };
                SummaryPageControl.prototype.transformJsonData = function (myDataJson) {
                    var that = this;
                    var groupRecords = {};
                    groupRecords.Groups = [];
                    var basicSetupRecords = [];
                    var subAreaRecords = [];
                    var groupRecordsWithSubArea = [];
                    var groupMap = [];
                    var records = myDataJson.appconfig_navigationsetting;
                    var groupOrder = 0;
                    for (var i = 0; i < records.length; i++) {
                        var record = records[i];
                        if (!this._context.utils.isNullOrUndefined(record)) {
                            // parentnavigationsettingid is null for Groups.
                            if (this._context.utils.isNullOrUndefined(record.parentnavigationsettingid)) {
                                groupRecords.Groups[groupOrder++] = {
                                    "Name": this._context.utils.isNullOrUndefined(record.name) ? "" : record.name,
                                    "Id": this._context.utils.isNullOrUndefined(record.navigationsettingid) ? "" : record.navigationsettingid,
                                    "SubAreas": [],
                                };
                            }
                            else {
                                var subArea = {
                                    "Name": this._context.utils.isNullOrUndefined(record.name) ? "" : record.name,
                                    "Id": this._context.utils.isNullOrUndefined(record.navigationsettingid) ? "" : record.navigationsettingid,
                                    "ParentGroupID": this._context.utils.isNullOrUndefined(record.parentnavigationsettingid) ? "" : record.parentnavigationsettingid,
                                    "Url": this._context.utils.isNullOrUndefined(record.pageurl) ? "" : record.pageurl,
                                    "SettingsType": this._context.utils.isNullOrUndefined(record.settingtype) ? "" : record.settingtype,
                                    "IconResourceId": this._context.utils.isNullOrUndefined(record.iconresourceid) ? "" : record.iconresourceid
                                };
                                subAreaRecords.push(subArea);
                                // SettingsType: distinguish the settings type.
                                if (subArea.SettingsType === 1) {
                                    basicSetupRecords.push(subArea);
                                }
                            }
                        }
                    }
                    for (var i = 0; i < groupRecords.Groups.length; i++) {
                        for (var j = 0; j < subAreaRecords.length; j++) {
                            if (groupRecords.Groups[i].Id == subAreaRecords[j].ParentGroupID) {
                                groupRecords.Groups[i].SubAreas.push(subAreaRecords[j]);
                            }
                        }
                    }
                    that._NavJsondata = JSON.stringify(groupRecords);
                };
                SummaryPageControl.prototype.getLinkForTileContainer = function (pageURL) {
                    var currentPageUrl = window.top.location.href;
                    var pageType = SummaryPage.SummaryPageHelper.GetVariableValue(pageURL, SummaryPage.SummaryPageStrings.QueryStringPageTypeKey);
                    var linkforTileContainer = "";
                    switch (pageType) {
                        case PageType[PageType.control]:
                            var controlName = SummaryPage.SummaryPageHelper.GetVariableValue(pageURL, SummaryPage.SummaryPageStrings.QueryStringCustomControlKey);
                            linkforTileContainer = currentPageUrl.replace(this._currentPageControlName, controlName);
                            break;
                        case PageType[PageType.webresource]:
                            var webresourceName = SummaryPage.SummaryPageHelper.GetVariableValue(pageURL, SummaryPage.SummaryPageStrings.QueryStringWebresourceKey);
                            linkforTileContainer = currentPageUrl.replace(SummaryPage.SummaryPageStrings.QueryStringCustomControlPageTypeKeyValuePair, SummaryPage.SummaryPageStrings.QueryStringWebresourcePageTypeKeyValuePair).replace(SummaryPage.SummaryPageStrings.QueryStringCustomControlKey + "=" + this._currentPageControlName, SummaryPage.SummaryPageStrings.QueryStringWebresourceKey + "=" + webresourceName);
                            break;
                        case PageType[PageType.designer]:
                            var DesignerName = SummaryPage.SummaryPageHelper.GetVariableValue(pageURL, SummaryPage.SummaryPageStrings.QueryStringDesignerControlKey);
                            linkforTileContainer = currentPageUrl.replace(SummaryPage.SummaryPageStrings.QueryStringCustomControlPageTypeKeyValuePair, SummaryPage.SummaryPageStrings.QueryStringDesignerPageTypeKeyValuePair).replace(SummaryPage.SummaryPageStrings.QueryStringCustomControlKey + "=" + this._currentPageControlName, SummaryPage.SummaryPageStrings.QueryStringDesignerControlKey + "=" + DesignerName + "&" + SummaryPage.SummaryPageStrings.QueryStringDefaultSolutionIdKeyValuePair);
                            break;
                        default:
                            break;
                    }
                    return linkforTileContainer;
                };
                SummaryPageControl.prototype.initializeData = function (context) {
                    if (context.utils.isNullOrUndefined(this._appConfigIdValue)) {
                        var appModuleId = SummaryPage.SummaryPageHelper.GetURLVariableValue(SummaryPage.SummaryPageStrings.QueryStringAppIdKey);
                        var appConfigIdUrl = SummaryPage.SummaryPageHelper.getAppConfigRequest(appModuleId);
                        var that = this;
                        this.getAppConfigId(context.utils.createCrmUri(appConfigIdUrl)).then(function (data) {
                            if (data.value.length == 0) {
                                throw new Error("appconfigid not found");
                            }
                            else {
                                that._appConfigIdValue = data.value[0]["appconfigid"];
                                var uri = context.utils.createCrmUri(SummaryPage.SummaryPageHelper.getNavSettingsURL(that._appConfigIdValue));
                                that.initializeJsonData(uri).then(function (data) {
                                    that.transformJsonData(data);
                                    if (!context.utils.isNullOrUndefined(that._NavJsondata) && Object.keys(that._mapImagesByWebResourceID).length != 0) {
                                        that._context.utils.requestRender();
                                    }
                                }, function (error) {
                                    var errMessage = "Retrieval of navsettings Failed.";
                                    that.handleError(error, errMessage);
                                });
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of appconfigid Failed.";
                            that.handleError(error, errMessage);
                        });
                    }
                    if (Object.keys(this._mapImagesByWebResourceID).length == 0) {
                        this.getSummaryScreenSVGs().then(function (data) {
                            for (var i = 0; i < data.value.length; i++) {
                                var webResourceId = data.value[i]["webresourceid"];
                                var displayname = data.value[i]["displayname"];
                                if (true == context.accessibility.isHighContrastEnabled) {
                                    //Example for the displayname - BPF.svg
                                    that._mapImagesByWebResourceID[webResourceId] = "../../WebResources/AppCommon/ControlWS/SummaryPageImages/" + displayname.split(".")[0] + "_HighContrast.svg";
                                }
                                else {
                                    that._mapImagesByWebResourceID[webResourceId] = "../../WebResources/AppCommon/ControlWS/SummaryPageImages/" + displayname;
                                }
                            }
                            if (!context.utils.isNullOrUndefined(that._NavJsondata) && Object.keys(that._mapImagesByWebResourceID).length != 0) {
                                that._context.utils.requestRender();
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of svg images from webresources Failed.";
                            that.handleError(error, errMessage);
                        });
                    }
                    this.isInitialized = true;
                };
                SummaryPageControl.prototype.getAppConfigId = function (appConfigIdUrl) {
                    return $.ajax({
                        url: appConfigIdUrl,
                        type: 'GET',
                        async: true,
                        beforeSend: function (request) {
                            request.setRequestHeader("OData-MaxVersion", "4.0");
                            request.setRequestHeader("OData-Version", "4.0");
                            request.setRequestHeader("Accept", "application/json");
                            request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        }
                    });
                };
                SummaryPageControl.prototype.getSummaryScreenSVGs = function () {
                    var uri = this._context.utils.createCrmUri("/api/data/v9.0/webresourceset?$select=webresourceid,displayname&$filter=contains(name,'AppCommon/ControlWS/SummaryPageImages/') and not(endswith(displayname,'_HighContrast.svg'))");
                    return $.ajax({
                        url: uri,
                        type: 'GET',
                        async: true,
                        beforeSend: function (request) {
                            request.setRequestHeader("OData-MaxVersion", "4.0");
                            request.setRequestHeader("OData-Version", "4.0");
                            request.setRequestHeader("Accept", "application/json");
                            request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        }
                    });
                };
                /**
                 * The function handles errors/exceptions
                 * @param e
                 * @param errMessage
                 */
                SummaryPageControl.prototype.handleError = function (e, errMessage) {
                    SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(this._context, SmbAppsTelemetryUtility.Controls_PageType.BASICSETUPSUMMARY, e, errMessage);
                    console.log("Summary Page Error : " + errMessage);
                    if (e instanceof Error) {
                        errMessage = e.message;
                        console.log(errMessage);
                    }
                    throw new Error(errMessage);
                };
                return SummaryPageControl;
            }());
            SummaryPage.SummaryPageControl = SummaryPageControl;
        })(SummaryPage = AppCommon.SummaryPage || (AppCommon.SummaryPage = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SummaryPage.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SummaryPage;
        (function (SummaryPage) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "SubareLabelForBasicShellMode", {
                    get: function () {
                        return "SubareLabelForBasicShellMode";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SubareaLabelForAdvancedShellMode", {
                    get: function () {
                        return "SubareaLabelForAdvancedShellMode";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SetupInformationForBasicShellMode", {
                    get: function () {
                        return "SetupInformationForBasicShellMode";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "GotoSetupLinkForAdvancedShellMode", {
                    get: function () {
                        return "GotoSetupLinkForAdvancedShellMode";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "GotoSetupLinkForAdvancedShellModeToolTip", {
                    get: function () {
                        return "GotoSetupLinkForAdvancedShellModeToolTip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SummaryDescription", {
                    get: function () {
                        return "SummaryDescription";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "TextToDsiplayAsTooltipOnTiles", {
                    get: function () {
                        return "TextToDsiplayAsTooltipOnTiles";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "QuickSetupText", {
                    get: function () {
                        return "QuickSetupText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FormFactorOrDeviceNotSupportedMessage", {
                    get: function () {
                        return "SMBAdvSettings_FormFactorOrDeviceNotSupportedMessage";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            SummaryPage.ResourceKeys = ResourceKeys;
        })(SummaryPage = AppCommon.SummaryPage || (AppCommon.SummaryPage = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SummaryPage;
        (function (SummaryPage) {
            'use strict';
            var SummaryPageHelper = (function () {
                function SummaryPageHelper() {
                }
                SummaryPageHelper.IsAppshellmodeBasic = function () {
                    return window && window.parent && window.parent.location && window.parent.location.href && window.parent.location.href.toLowerCase().indexOf("appshellmode=basic") !== -1;
                };
                /**
                 * retrieves a query string variable value from top window URL
                 * @param paramKey
                 */
                SummaryPageHelper.GetURLVariableValue = function (paramKey) {
                    if (window && window.top && window.top.location && window.top.location.href) {
                        var currentUrl = window.top.location.href;
                        return SummaryPageHelper.GetVariableValue(currentUrl, paramKey);
                    }
                };
                /**
                 * Retrieves a query string variable value from given input string
                 * @param inputStr
                 * @param paramKey
                 */
                SummaryPageHelper.GetVariableValue = function (inputStr, paramKey) {
                    inputStr = SummaryPageHelper.removeBaseURLAndHashComponentFromURL(inputStr);
                    var variables = inputStr.split("&");
                    for (var i = 0; i < variables.length; i++) {
                        var Entry = variables[i].split("=");
                        var key = Entry.length === 2 ? Entry[0] : null;
                        if (key != null && key.toLowerCase() === paramKey.toLowerCase()) {
                            return Entry[1];
                        }
                    }
                };
                SummaryPageHelper.getAppConfigRequest = function (appModuleId) {
                    return "/api/data/v9.0/appconfigs?$filter=_appmoduleid_value eq " + appModuleId + "&$select=appconfigid";
                };
                SummaryPageHelper.getNavSettingsURL = function (appConfigId) {
                    return "/api/data/v9.0/appconfigs(" + appConfigId + ")?$expand=appconfig_navigationsetting($select=parentnavigationsettingid,name,pageurl,navigationsettingid,iconresourceid,settingtype;$orderby=advancedsettingorder asc;$filter=settingtype ne 2 and settingtype ne 3)";
                };
                SummaryPageHelper.getRoleIdsRequestURL = function () {
                    return "/api/data/v9.0/roles?$select=roletemplateid&$filter=_roletemplateid_value eq 627090ff-40a3-4053-8790-584edc5be201";
                };
                /**
                 * Returns query string from URL after removing base url and # component
                 * @param inputStr
                 */
                SummaryPageHelper.removeBaseURLAndHashComponentFromURL = function (inputStr) {
                    var queryString = "";
                    //Removing base URL
                    var indexQuestionMark = inputStr.indexOf("?");
                    if (indexQuestionMark >= 0) {
                        queryString = inputStr.substring(indexQuestionMark + 1, inputStr.length);
                    }
                    else {
                        queryString = inputStr;
                    }
                    //Removing Hash Component
                    var indexHash = queryString.indexOf("#");
                    if (indexHash >= 0) {
                        queryString = queryString.substring(0, indexHash);
                    }
                    return queryString;
                };
                return SummaryPageHelper;
            }());
            SummaryPage.SummaryPageHelper = SummaryPageHelper;
        })(SummaryPage = AppCommon.SummaryPage || (AppCommon.SummaryPage = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SummaryPage;
        (function (SummaryPage) {
            'use strict';
            var SummaryPageStrings = (function () {
                function SummaryPageStrings() {
                }
                Object.defineProperty(SummaryPageStrings, "AppClient", {
                    get: function () {
                        return "Mobile";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "defaultIconToDisplayOnTile", {
                    get: function () {
                        return "ce609b73-70fc-459d-9409-b1e45d9cf289";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringAppIdKey", {
                    get: function () {
                        return "appid";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringAppShellModeAdvanced", {
                    get: function () {
                        return "&appshellmode=advanced";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringAppShellModeBasic", {
                    get: function () {
                        return "&appshellmode=basic";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringPageTypeKey", {
                    get: function () {
                        return "pagetype";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringWebresourceKey", {
                    get: function () {
                        return "webresourceName";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringCustomControlKey", {
                    get: function () {
                        return "controlName";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringDashboardIdKey", {
                    get: function () {
                        return "id";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "DefaultDashboardId", {
                    get: function () {
                        return "3b5d39a7-b216-e711-80d8-00155d896f83";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringDesignerControlKey", {
                    get: function () {
                        return "name";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringWebresourcePageTypeKeyValuePair", {
                    get: function () {
                        return "pagetype=webresource";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringDashboardPageTypeKeyValuePair", {
                    get: function () {
                        return "pagetype=dashboard";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringCustomControlPageTypeKeyValuePair", {
                    get: function () {
                        return "pagetype=control";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringDesignerPageTypeKeyValuePair", {
                    get: function () {
                        return "pagetype=designer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "QueryStringDefaultSolutionIdKeyValuePair", {
                    get: function () {
                        return "solutionid=default";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/AdvancedSettings.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(SummaryPageStrings, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/AdvancedSettings_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return SummaryPageStrings;
            }());
            SummaryPage.SummaryPageStrings = SummaryPageStrings;
        })(SummaryPage = AppCommon.SummaryPage || (AppCommon.SummaryPage = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SummaryPage;
        (function (SummaryPage) {
            'use strict';
            var SummaryPageStyles = (function (_super) {
                __extends(SummaryPageStyles, _super);
                function SummaryPageStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._fREExtendedBodyContainer = {};
                    _this._mainSectionContainer = {};
                    _this._topDescContainer = {};
                    _this._sectionDetailContainer = {};
                    _this._sectionWiseContainer = {};
                    _this._tileContainer = {};
                    _this._areaLblContainer = {};
                    _this._tileLbl = {};
                    _this._displayLineContainer = {};
                    _this._gotoBasicSetupContainer = {};
                    _this._inBasicSetupContainer = {};
                    _this._tileImage = {};
                    _this._contentContainerStyle = {};
                    _this._context = context;
                    _this._fREExtendedBodyContainer = null;
                    _this._mainSectionContainer = null;
                    _this._topDescContainer = null;
                    _this._sectionDetailContainer = null;
                    _this._sectionWiseContainer = null;
                    _this._tileContainer = null;
                    _this._areaLblContainer = null;
                    _this._tileLbl = null;
                    _this._displayLineContainer = null;
                    _this._gotoBasicSetupContainer = null;
                    _this._inBasicSetupContainer = null;
                    _this._tileImage = null;
                    _this._contentContainerStyle = null;
                    return _this;
                }
                SummaryPageStyles.prototype.FREExtendedBodyContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._fREExtendedBodyContainer)) {
                        this._fREExtendedBodyContainer = {};
                        this._fREExtendedBodyContainer["background"] = this._context.theming.colors.basecolor.white;
                        this._fREExtendedBodyContainer["border"] = this._context.theming.borders.border02;
                        this._fREExtendedBodyContainer["display"] = "flex";
                        this._fREExtendedBodyContainer["flexDirection"] = "column";
                        this._fREExtendedBodyContainer["flex"] = "1";
                        this._fREExtendedBodyContainer["maxWidth"] = "100%";
                        this._fREExtendedBodyContainer["height"] = $(window).height() + 60;
                        this._fREExtendedBodyContainer["minWidth"] = "600px";
                        this._fREExtendedBodyContainer["minHeight"] = "500px";
                    }
                    return this._fREExtendedBodyContainer;
                };
                SummaryPageStyles.prototype.MainSectionContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._mainSectionContainer)) {
                        this._mainSectionContainer = {};
                        this._mainSectionContainer["flexDirection"] = "column";
                        this._mainSectionContainer["background"] = this._context.theming.colors.basecolor.white;
                        this._mainSectionContainer["display"] = "inline-block";
                        this._mainSectionContainer["width"] = "100%";
                    }
                    return this._mainSectionContainer;
                };
                SummaryPageStyles.prototype.TopDescContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._topDescContainer)) {
                        this._topDescContainer = {};
                        this._topDescContainer["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._topDescContainer["fontSize"] = this._context.theming.fontsizes.font100;
                        this._topDescContainer["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._topDescContainer["letterSpacing"] = "0";
                        this._topDescContainer["lineHeight"] = "1.2rem";
                        this._topDescContainer["height"] = "1.2rem";
                        this._topDescContainer["marginTop"] = this._context.theming.measures.measure075;
                        this._topDescContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._topDescContainer["marginBottom"] = this._context.theming.measures.measure150;
                        this._topDescContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._topDescContainer["display"] = "inline-block";
                        this._topDescContainer["flexDirection"] = "row";
                    }
                    return this._topDescContainer;
                };
                SummaryPageStyles.prototype.SectionDetailContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._sectionDetailContainer)) {
                        this._sectionDetailContainer = {};
                        this._sectionDetailContainer["display"] = "flex";
                        this._sectionDetailContainer["flexDirection"] = "row";
                        this._sectionDetailContainer["justifyContent"] = "flex-left";
                        this._sectionDetailContainer["flexWrap"] = "wrap";
                        this._sectionDetailContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._sectionDetailContainer["background"] = this._context.theming.colors.basecolor.white;
                    }
                    return this._sectionDetailContainer;
                };
                SummaryPageStyles.prototype.SectionWiseContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._sectionWiseContainer)) {
                        this._sectionWiseContainer = {};
                        this._sectionWiseContainer["display"] = "flex";
                        this._sectionWiseContainer["flexDirection"] = "column";
                        this._sectionWiseContainer["justifyContent"] = "flex-left";
                    }
                    return this._sectionWiseContainer;
                };
                SummaryPageStyles.prototype.TileContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._tileContainer)) {
                        var hoverTileContainer = {};
                        hoverTileContainer["backgroundColor"] = this._context.theming.colors.basecolor.grey.grey1;
                        hoverTileContainer["border"] = this._context.theming.borders.border01;
                        hoverTileContainer["cursor"] = "pointer";
                        this._tileContainer = {};
                        this._tileContainer["display"] = "flex";
                        this._tileContainer["flexDirection"] = "column";
                        this._tileContainer["justifyContent"] = "flex-left";
                        this._tileContainer["width"] = "9rem";
                        this._tileContainer["height"] = "9rem";
                        this._tileContainer["alignItemss"] = "center";
                        this._tileContainer["textDecoration"] = "none";
                        this._tileContainer["border"] = "1px solid #FFFFFF";
                        this._tileContainer[":hover"] = hoverTileContainer;
                    }
                    return this._tileContainer;
                };
                SummaryPageStyles.prototype.AreaLblContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._areaLblContainer)) {
                        this._areaLblContainer = {};
                        this._areaLblContainer["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._areaLblContainer["fontSize"] = this._context.theming.fontsizes.font100;
                        this._areaLblContainer["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._areaLblContainer["letterSpacing"] = "0";
                        this._areaLblContainer["lineHeight"] = "1.2rem";
                        this._areaLblContainer["height"] = "1.2rem";
                        this._areaLblContainer["marginTop"] = "0rem";
                        this._areaLblContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._areaLblContainer["marginBottom"] = this._context.theming.measures.measure025;
                        this._areaLblContainer["marginLeft"] = this._context.theming.measures.measure075;
                    }
                    return this._areaLblContainer;
                };
                SummaryPageStyles.prototype.TileLbl = function () {
                    if (this._context.utils.isNullOrUndefined(this._tileLbl)) {
                        this._tileLbl = {};
                        this._tileLbl["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._tileLbl["fontSize"] = this._context.theming.fontsizes.font100;
                        this._tileLbl["color"] = "#0063B1";
                        this._tileLbl["letterSpacing"] = "0";
                        this._tileLbl["lineHeight"] = "1.2rem";
                        this._tileLbl["marginTop"] = "auto";
                        this._tileLbl["marginRight"] = this._context.theming.measures.measure075;
                        this._tileLbl["marginBottom"] = this._context.theming.measures.measure075;
                        this._tileLbl["marginLeft"] = this._context.theming.measures.measure075;
                        this._tileLbl["textAlign"] = "center";
                        this._tileLbl["cursor"] = "pointer";
                        this._tileLbl["width"] = "7.5rem";
                        this._tileLbl["height"] = "4.75rem";
                        this._tileLbl["overflow"] = "hidden";
                        this._tileLbl["textOverflow"] = "ellipsis";
                    }
                    return this._tileLbl;
                };
                SummaryPageStyles.prototype.DisplayLineContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._displayLineContainer)) {
                        this._displayLineContainer = {};
                        this._displayLineContainer["border"] = this._context.theming.borders.border01;
                        this._displayLineContainer["marginTop"] = this._context.theming.measures.measure025;
                        this._displayLineContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._displayLineContainer["marginBottom"] = this._context.theming.measures.measure025;
                        this._displayLineContainer["marginLeft"] = this._context.theming.measures.measure075;
                    }
                    return this._displayLineContainer;
                };
                SummaryPageStyles.prototype.InBasicSetupContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._inBasicSetupContainer)) {
                        this._inBasicSetupContainer = {};
                        this._inBasicSetupContainer["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._inBasicSetupContainer["fontSize"] = this._context.theming.fontsizes.font100;
                        this._inBasicSetupContainer["color"] = "#0063B1";
                        this._inBasicSetupContainer["letterSpacing"] = "0";
                        this._inBasicSetupContainer["lineHeight"] = "1.2rem";
                        this._inBasicSetupContainer["marginTop"] = this._context.theming.measures.measure075;
                        this._inBasicSetupContainer["marginRight"] = this._context.theming.measures.measure150;
                        this._inBasicSetupContainer["marginBottom"] = this._context.theming.measures.measure075;
                        this._inBasicSetupContainer["marginLeft"] = "auto";
                        this._inBasicSetupContainer["textAlign"] = "center";
                    }
                    return this._inBasicSetupContainer;
                };
                SummaryPageStyles.prototype.TileImage = function () {
                    if (this._context.utils.isNullOrUndefined(this._tileImage)) {
                        this._tileImage = {};
                        this._tileImage["marginTop"] = this._context.theming.measures.measure075;
                        this._tileImage["marginRight"] = this._context.theming.measures.measure075;
                        this._tileImage["marginBottom"] = this._context.theming.measures.measure075;
                        this._tileImage["marginLeft"] = this._context.theming.measures.measure075;
                        this._tileImage["maxHeight"] = "2rem";
                        this._tileImage["maxWidth"] = "7.5rem";
                        this._tileImage["alignSelf"] = "center";
                    }
                    return this._tileImage;
                };
                SummaryPageStyles.prototype.ContentContainerStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._contentContainerStyle)) {
                        this._contentContainerStyle = {};
                        this._contentContainerStyle["backgroundColor"] = this._context.theming.colors.basecolor.white;
                        this._contentContainerStyle["flex"] = "1 1";
                        this._contentContainerStyle["display"] = "inline-block";
                    }
                    return this._contentContainerStyle;
                };
                return SummaryPageStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            SummaryPage.SummaryPageStyles = SummaryPageStyles;
        })(SummaryPage = AppCommon.SummaryPage || (AppCommon.SummaryPage = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SummaryPage.js.map