/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        'use strict';
        var PartyListWrapper = (function () {
            /**
             * Empty constructor.
             */
            function PartyListWrapper() {
                this._controlId = "cc_partylist_lookup";
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            PartyListWrapper.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
                this.selectedRecords = this.selectedRecords || [];
                this.targetEntities = this.targetEntities || [];
                if (context.parameters.targetEntities && context.parameters.targetEntities.raw) {
                    this.targetEntities = context.parameters.targetEntities.raw.split(",");
                }
                else {
                    // Target entities not specified.
                    throw new Error("Target entities for the lookup are not specified.");
                }
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            PartyListWrapper.prototype.updateView = function (context) {
                return this.buildMultiPartyLookupControl(context, this.onSelectionChanged.bind(this));
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            PartyListWrapper.prototype.getOutputs = function () {
                return {
                    selectedEntities: this.selectedRecords
                };
            };
            PartyListWrapper.prototype.onSelectionChanged = function (e) {
                if (e && e.length > 0) {
                    this.selectedRecords = e.slice();
                    this._notifyOutputChanged();
                }
                else {
                    console.log("Unexpected value recieved: " + e);
                }
            };
            PartyListWrapper.prototype.buildMultiPartyLookupControl = function (context, callback) {
                return context.factory.createComponent("MscrmControls.FieldControls.SimpleLookupControl", this._controlId, {
                    controlstates: {
                        hasFocus: context.mode.hasFocus,
                        isControlDisabled: false
                    },
                    descriptor: {
                        Id: this._controlId + "-Id",
                        Label: this._controlId + "-Label",
                        Name: this._controlId + "-Name",
                        ShowLabel: false,
                        Visible: true,
                        Disabled: false
                    },
                    configuration: {
                        FormFactor: 3 /* Desktop */,
                        CustomControlId: "MscrmControls.FieldControls.SimpleLookupControl",
                        Name: this._controlId + "-Config",
                        Version: "1.0.0",
                        Parameters: {
                            value: this.getValueParameter(callback)
                        }
                    }
                });
            };
            PartyListWrapper.prototype.getValueParameter = function (callback) {
                return {
                    Usage: 3,
                    Static: false,
                    Value: this.selectedRecords,
                    Type: "Lookup.PartyList",
                    Attributes: {
                        Targets: this.targetEntities
                    },
                    Callback: callback,
                };
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            PartyListWrapper.prototype.destroy = function () {
            };
            return PartyListWrapper;
        }());
        AppCommon.PartyListWrapper = PartyListWrapper;
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="PartyListWrapper.ts" /> 
//# sourceMappingURL=PartyListWrapper.js.map