/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
var Mscrm;
(function (Mscrm) {
    var AppCommon;
    (function (AppCommon) {
        var Common;
        (function (Common) {
            'use strict';
            var DocumentTemplateType;
            (function (DocumentTemplateType) {
                DocumentTemplateType[DocumentTemplateType["None"] = 0] = "None";
                DocumentTemplateType[DocumentTemplateType["Excel"] = 1] = "Excel";
                DocumentTemplateType[DocumentTemplateType["Word"] = 2] = "Word";
            })(DocumentTemplateType = Common.DocumentTemplateType || (Common.DocumentTemplateType = {}));
            var Utility = (function () {
                function Utility() {
                }
                /**
                 * Checks whether an object is null.
                 * @param object The object to check.
                 * @returns A flag indicating whether the object is null.
                 */
                Utility.isNull = function (object) {
                    return object === null;
                };
                /**
                 * Checks whether an object is null or undefined.
                 * @param object The object to check.
                 * @returns A flag indicating whether the object is null or undefined.
                 */
                Utility.isNullOrUndefined = function (object) {
                    return object === null || object === undefined;
                };
                /**
                 * Checks whether an object is an undefined, null or empty string.
                 * @param object The object to check.
                 * @returns A flag indicating whether the object is undefined, null or an empty string.
                 */
                Utility.isNullOrEmptyString = function (object) {
                    return Utility.isNullOrUndefined(object) || object === "";
                };
                /**
                * Tries to convert an object to string
                * @param object The object to convert.
                * @returns Returns the object converted to string or the object itself if this is null or undefined.
                */
                Utility.toStringWithNullCheck = function (object) {
                    return Utility.isNullOrUndefined(object) ? object : object.toString();
                };
                Utility.newGuid = function () {
                    return 'xxxxxxxx-xxxx-xxxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                        return v.toString(16);
                    });
                };
                /**
                * The method for creating Blob object from base64 content.
                */
                Utility.Base64ToBlob = function (fileContent, fileType) {
                    if (this.isNullOrEmptyString(fileContent))
                        throw new Error("file Content cannot be empty");
                    if (this.isNullOrEmptyString(fileType))
                        throw new Error("file Type cannot be empty");
                    // convert base64 content to raw binary data held in a string
                    var binary = window.atob(fileContent);
                    var binaryLength = binary.length;
                    // create ArrayBuffer with binary length
                    var buffer = new ArrayBuffer(binaryLength);
                    // create 8-bit Array for ArrayBuffer
                    var viewBuffer = new Uint8Array(buffer);
                    // save unicode of binary data into 8-bit Array
                    for (var i = 0; i < binaryLength; i++) {
                        viewBuffer[i] = binary.charCodeAt(i);
                    }
                    return new Blob([buffer], { type: fileType });
                };
                Utility.clickOnTempAnchor = function (url, fileName) {
                    var tempAnchorElement = document.createElement("a");
                    tempAnchorElement.setAttribute("href", url);
                    tempAnchorElement.setAttribute("target", "_blank");
                    tempAnchorElement.setAttribute("download", fileName);
                    document.body.appendChild(tempAnchorElement);
                    tempAnchorElement.click();
                    document.body.removeChild(tempAnchorElement);
                };
                Utility.GetCurrentAppId = function () {
                    if (window && window.top && window.top.location && window.top.location.href) {
                        var currentUrl = window.top.location.href;
                        var index = currentUrl.indexOf("?");
                        var queryString = currentUrl.substring(index + 1, currentUrl.length);
                        var UrlVariables = queryString.split("&");
                        for (var i = 0; i < UrlVariables.length; i++) {
                            var Entry = UrlVariables[i].split("=");
                            var key = Entry.length === 2 ? Entry[0] : null;
                            if (key === "appid") {
                                return Entry[1];
                            }
                        }
                    }
                    return "";
                };
                /**
                 * returns the fetchXML, which can be used to fetch the parkinsolutionID of the app.
                 * @param appId : appId of the App being used.
                 * @param parkingSolutionAppConfigMasterId
                 */
                Utility.GetParkingSolutionIdFetchXML = function (appId, parkingSolutionAppConfigMasterId) {
                    var retFetchXML = "?fetchXml=" + encodeURI("<fetch version=\"1.0\" mapping=\"logical\" distinct=\"true\">\n\t\t\t\t\t <entity name=\"appconfiginstance\">\n\t\t\t\t\t <attribute name=\"value\" />\n\t\t\t\t\t <link-entity name=\"appconfig\" to=\"appconfigid\" from=\"appconfigid\" link-type=\"inner\" >\n\t\t\t\t\t\t <filter type=\"and\">\n\t\t\t\t\t\t\t <condition attribute=\"appmoduleid\" operator=\"eq\" value=\"" + appId + "\"/>\n\t\t\t\t\t\t </filter >\n\t\t\t\t\t </link-entity>\n\t\t\t\t\t <link-entity name=\"solution\" to=\"value\" from=\"solutionid\" link-type=\"inner\"  />\n\t\t\t\t\t <filter type=\"and\">\n\t\t\t\t\t\t<condition attribute=\"appconfigmasterid\" operator=\"eq\" value=\"" + parkingSolutionAppConfigMasterId + "\"/> </filter>\n\t\t\t\t\t </entity>\n\t\t\t\t </fetch>");
                    return retFetchXML;
                };
                Utility.GetCurrentShellMode = function () {
                    if (window && window.top && window.top.location && window.top.location.href) {
                        var currentUrl = window.top.location.href;
                        var index = currentUrl.indexOf("?");
                        var queryString = currentUrl.substring(index + 1, currentUrl.length);
                        var UrlVariables = queryString.split("&");
                        for (var i = 0; i < UrlVariables.length; i++) {
                            var Entry = UrlVariables[i].split("=");
                            var key = Entry.length === 2 ? Entry[0] : null;
                            if (key === "appshellmode") {
                                return Entry[1].toLowerCase();
                            }
                        }
                    }
                    return "";
                };
                Utility.GetFileExtension = function (fileName) {
                    return this.isNullOrEmptyString(fileName) ? fileName
                        : fileName.substr(fileName.lastIndexOf('.') + 1);
                };
                Utility.GetFileNameWithoutExtension = function (fileName) {
                    return this.isNullOrEmptyString(fileName) ? fileName
                        : fileName.substr(0, fileName.lastIndexOf('.'));
                };
                Utility.GetDocumentTemplateType = function (fileExtension) {
                    switch (fileExtension) {
                        case "xlsx":
                            return DocumentTemplateType.Excel;
                        case "docx":
                            return DocumentTemplateType.Word;
                    }
                    return DocumentTemplateType.None;
                };
                Utility.GetFileExtensionForDocument = function (docType) {
                    switch (docType) {
                        case DocumentTemplateType.Excel:
                            return "xlsx";
                        case DocumentTemplateType.Word:
                            return "docx";
                    }
                    return "";
                };
                Utility.EqualsIgnoreCase = function (string1, string2) {
                    var isString1Null = string1 == null;
                    var isString2Null = string2 == null;
                    var isString1Undefined = string1 == undefined;
                    var isString2Undefined = string2 == undefined;
                    if (isString1Null && isString2Null || isString1Undefined && isString2Undefined) {
                        return true;
                    }
                    if (isString1Null != isString2Null || isString1Undefined != isString2Undefined) {
                        return false;
                    }
                    return string1.toUpperCase() === string2.toUpperCase();
                };
                Utility.isNullUndefinedOrWhitespace = function (s) {
                    return s == null || s == undefined || s.trim().length === 0;
                };
                ;
                /**
                 * Parses webapplication endpoint url and returns crmhostname : used for AddNewUserControl, EditUserControl and ApplicationManagementControl
                 */
                Utility.GetCrmHostName = function (webApplicationEndpoint) {
                    /*
                    * Parsing considers following 4 forms of URLs:
                    *   1."https://someorg.crmx.something.com/"
                    *   2."https://someorg.crmx.something.com"
                    *   3."someorg.crmx.something.com"
                    *   4."someorg.crmx.something.com/"
                    * converts into "crmx.something.com"
                    */
                    var currentUrl = webApplicationEndpoint;
                    var matchedStringIndex = currentUrl.indexOf(".");
                    if (matchedStringIndex != -1) {
                        currentUrl = currentUrl.substring(matchedStringIndex + 1);
                        //remove last "/" if there
                        var lastIndex = currentUrl.lastIndexOf("/");
                        if (lastIndex != -1) {
                            currentUrl = currentUrl.substring(0, lastIndex);
                        }
                    }
                    //TODO: throw exception if not able to process the string and catch it when function is called.
                    return currentUrl;
                };
                return Utility;
            }());
            Common.Utility = Utility;
        })(Common = AppCommon.Common || (AppCommon.Common = {}));
    })(AppCommon = Mscrm.AppCommon || (Mscrm.AppCommon = {}));
})(Mscrm || (Mscrm = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="../../Controls/FREShell/WebApi/Utility.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            'use strict';
            var Utility = Mscrm.AppCommon.Common.Utility;
            var SummarySectionControl = (function () {
                /**
                 * Empty constructor.
                 */
                function SummarySectionControl() {
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                SummarySectionControl.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    this._applyStyles = new ExcelWordTemplate.SummarySectionStyles(context);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SummarySectionControl.prototype.updateView = function (context) {
                    // custom code goes here
                    if (Utility.isNullOrUndefined(this._context.parameters.uploaded_template_id)) {
                        return;
                    }
                    this._filteringInput = this._context.parameters.uploaded_template_id.raw;
                    if (!(this._filteringInput == null || this._filteringInput == undefined)) {
                        if ((this.parsedResp == null || this.parsedResp == undefined)) {
                            var loadingLabel = context.factory.createElement("LABEL", {
                                id: "SummaryKeyType",
                                key: "SummaryKeyType",
                                style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                            }, "Loading...");
                            this.SummarySectionContainer = context.factory.createElement("CONTAINER", {
                                id: "SummarySectionContainer",
                                key: "SummarySectionContainer",
                                style: this._applyStyles.SummarySectionContainer()
                            }, [loadingLabel]);
                            // Retrieve Summary Data
                            this.getSummaryValues();
                        }
                    }
                    return this.SummarySectionContainer;
                };
                SummarySectionControl.prototype.createSummaryContent = function (context) {
                    // Left Side Items
                    // Create SummaryOfFile
                    var SummaryOfFileKey = context.factory.createElement("LABEL", {
                        id: "SummaryOfFileKey",
                        key: "SummaryOfFileKey",
                        style: this._applyStyles.SummarySectionOfFileKey()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.SummaryOfFileValue));
                    // Create SummaryStatus key
                    var SummaryKeyStatus = context.factory.createElement("LABEL", {
                        id: "SummaryKeyStatus",
                        key: "SummaryKeyStatus",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.StatusValue));
                    // Create SummaryName Key
                    var SummaryKeyName = context.factory.createElement("LABEL", {
                        id: "SummaryKeyName",
                        key: "SummaryKeyName",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.NameValue));
                    // Create SummaryDescription Key
                    var SummaryKeyDescription = context.factory.createElement("LABEL", {
                        id: "SummaryKeyDescription",
                        key: "SummaryKeyDescription",
                        style: this._applyStyles.SummarySectionKeyDescription()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.DescriptionValue));
                    // Create SummaryType Key
                    var SummaryKeyType = context.factory.createElement("LABEL", {
                        id: "SummaryKeyType",
                        key: "SummaryKeyType",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.TypeValue));
                    // Create SummaryModifiedOn Key
                    var SummaryKeyModifiedOn = context.factory.createElement("LABEL", {
                        id: "SummaryKeyModifiedOn",
                        key: "SummaryKeyModifiedOn",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.ModifiedOnValue));
                    // Create SummaryModifiedBy Key
                    var SummaryKeyModifiedBy = context.factory.createElement("LABEL", {
                        id: "SummaryKeyModifiedBy",
                        key: "SummaryKeyModifiedBy",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.ModifiedByValue));
                    // Create SummaryType Key
                    var SummaryKeyTypeCode = context.factory.createElement("LABEL", {
                        id: "SummaryKeyTypeCode",
                        key: "SummaryKeyTypeCode",
                        style: this._applyStyles.SummarySectionKeyTypeCode(),
                        title: this._context.resources.getString(ExcelWordTemplate.ResourceKeys.AssociatedEntityTypeCodeValue)
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.AssociatedEntityTypeCodeValue));
                    // Create SummaryCreatedBy Key
                    var SummaryKeyCreatedBy = context.factory.createElement("LABEL", {
                        id: "SummaryKeyCreatedBy",
                        key: "SummaryKeyCreatedBy",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.CreatedByValue));
                    // Create SummaryCreatedOn Key
                    var SummaryKeyCreatedOn = context.factory.createElement("LABEL", {
                        id: "SummaryKeyCreatedOn",
                        key: "SummaryKeyCreatedOn",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.CreatedOnValue));
                    // Create SummaryLanguage Key
                    var SummaryKeyLanguage = context.factory.createElement("LABEL", {
                        id: "SummaryKeyLanguage",
                        key: "SummaryKeyLanguage",
                        style: this._applyStyles.SummarySectionLeftSideLabelsStyle()
                    }, this._context.resources.getString(ExcelWordTemplate.ResourceKeys.LanguageValue));
                    // Right Side Items
                    // Create SummaryStatus Value
                    var SummaryValueStatus = context.factory.createElement("LABEL", {
                        id: "SummaryValueStatus",
                        key: "SummaryValueStatus",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["status@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryName Value
                    var SummaryValueName = context.factory.createElement("LABEL", {
                        id: "SummaryValueName",
                        key: "SummaryValueName",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["name"]);
                    // Create SummaryDescription Value
                    var SummaryValueDescription;
                    if (this.parsedResp["description"] == null || this.parsedResp["description"] == "") {
                        SummaryValueDescription = context.factory.createElement("LABEL", {
                            id: "SummaryValueDescription",
                            key: "SummaryValueDescription",
                            style: this._applyStyles.SummarySectionValueDescription()
                        }, "- - - - -");
                    }
                    else {
                        SummaryValueDescription = context.factory.createElement("LABEL", {
                            id: "SummaryValueDescription",
                            key: "SummaryValueDescription",
                            style: this._applyStyles.SummarySectionValueDescriptionElse()
                        }, this.parsedResp["description"]);
                    }
                    // Create SummaryType Value
                    var SummaryValueType = context.factory.createElement("LABEL", {
                        id: "SummaryValueType",
                        key: "SummaryValueType",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["documenttype@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryModifiedOn Value
                    var SummaryValueModifiedOn = context.factory.createElement("LABEL", {
                        id: "SummaryValueModifiedOn",
                        key: "SummaryValueModifiedOn",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["modifiedon@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryModifiedBy Value
                    var SummaryValueModifiedBy = context.factory.createElement("LABEL", {
                        id: "SummaryValueModifiedBy",
                        key: "SummaryValueModifiedBy",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["_modifiedby_value@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryType Value
                    var SummaryValueTypeCode = context.factory.createElement("LABEL", {
                        id: "SummaryValueTypeCode",
                        key: "SummaryValueTypeCode",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["associatedentitytypecode@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryCreatedBy Value
                    var SummaryValueCreatedBy = context.factory.createElement("LABEL", {
                        id: "SummaryValueCreatedBy",
                        key: "SummaryValueCreatedBy",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["_createdby_value@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryCreatedOn Value
                    var SummaryValueCreatedOn = context.factory.createElement("LABEL", {
                        id: "SummaryValueCreatedOn",
                        key: "SummaryValueCreatedOn",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this.parsedResp["createdon@OData.Community.Display.V1.FormattedValue"]);
                    // Create SummaryLanguage Value
                    var SummaryValueLanguage = context.factory.createElement("LABEL", {
                        id: "SummaryValueLanguage",
                        key: "SummaryValueLanguage",
                        style: this._applyStyles.SummarySectionRightSideLabelsStyle()
                    }, this._context.formatting.formatLanguage(this.parsedResp["languagecode"]));
                    // Left Side Container
                    var SummaryLeftContainer = context.factory.createElement("CONTAINER", {
                        id: "SummaryLeftContainer", key: "SummaryLeftContainer",
                        style: this._applyStyles.SummarySectionCombinedLabelContainersStyle()
                    }, [SummaryKeyStatus, SummaryKeyName, SummaryKeyDescription, SummaryKeyType, SummaryKeyModifiedOn,
                        SummaryKeyModifiedBy, SummaryKeyTypeCode, SummaryKeyCreatedBy, SummaryKeyCreatedOn, SummaryKeyLanguage]);
                    // Right Side Container
                    var SummaryRightContainer = context.factory.createElement("CONTAINER", {
                        id: "SummaryRightContainer", key: "SummaryRightContainer",
                        style: this._applyStyles.SummarySectionCombinedLabelContainersStyle()
                    }, [SummaryValueStatus, SummaryValueName, SummaryValueDescription, SummaryValueType, SummaryValueModifiedOn,
                        SummaryValueModifiedBy, SummaryValueTypeCode, SummaryValueCreatedBy, SummaryValueCreatedOn, SummaryValueLanguage]);
                    //Create combined container for left and right
                    var SummaryCombinedContainer = context.factory.createElement("CONTAINER", {
                        id: "SummaryCombinedContainer",
                        key: "SummaryCombinedContainer",
                        style: this._applyStyles.SummarySectionCombinedContainer()
                    }, [SummaryLeftContainer, SummaryRightContainer]);
                    //Create container
                    this.SummarySectionContainer = context.factory.createElement("CONTAINER", {
                        id: "SummarySectionContainer",
                        key: "SummarySectionContainer",
                        style: this._applyStyles.SummarySectionContainer()
                    }, [SummaryOfFileKey, SummaryCombinedContainer]);
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SummarySectionControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SummarySectionControl.prototype.destroy = function () {
                };
                SummarySectionControl.prototype.actionFailedCallback = function (error) {
                    // TODO: Add failure notification
                };
                SummarySectionControl.prototype.getSummaryValues = function () {
                    var _this = this;
                    var selectString = "?$select=status,name,description,documenttype,modifiedon,_modifiedby_value,associatedentitytypecode,createdon,_createdby_value,languagecode";
                    var recordGuid = this._filteringInput.replace(/[{}]/g, '');
                    this._context.webAPI.retrieveRecord("documenttemplate", recordGuid, selectString).then(function (retrieveResponse) {
                        _this.parsedResp = retrieveResponse;
                        _this.createSummaryContent(_this._context);
                        _this._context.utils.requestRender();
                    }, this.actionFailedCallback);
                };
                return SummarySectionControl;
            }());
            ExcelWordTemplate.SummarySectionControl = SummarySectionControl;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="control.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: LocalizeString is a wraper to the core API for getting the resource string. In case the core API fails the class will return the default string provided by the caller as the resurce string
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            'use strict';
            // This code is for localization and will be finally part of common utility
            var LocalizeString = (function () {
                function LocalizeString(context, webresource) {
                    this.context = context;
                    this.webresource = webresource;
                }
                /**
                * The function returns the key if resource is not found
                * @param key
                * @param value
                */
                LocalizeString.prototype.getResourceString = function (key, value) {
                    try {
                        if (this.webresource === null)
                            throw new Error("WebResource should be initialized, for fetching value corresponding to key");
                        if (this.context === null)
                            throw new Error("Context should not be NULL");
                        var _value = undefined;
                        //value=LocalizeString.context.utils.getResourceString(key, LocalizeString.webresource);
                        if (_value === undefined)
                            return value;
                    }
                    catch (e) {
                        if (e instanceof Error) {
                            console.log(e.message);
                        }
                    }
                };
                return LocalizeString;
            }());
            ExcelWordTemplate.LocalizeString = LocalizeString;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "SummaryOfFileValue", {
                    get: function () {
                        return "SummaryOfFileValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "StatusValue", {
                    get: function () {
                        return "StatusValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "NameValue", {
                    get: function () {
                        return "NameValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DescriptionValue", {
                    get: function () {
                        return "DescriptionValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "TypeValue", {
                    get: function () {
                        return "TypeValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ModifiedOnValue", {
                    get: function () {
                        return "ModifiedOnValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ModifiedByValue", {
                    get: function () {
                        return "ModifiedByValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AssociatedEntityTypeCodeValue", {
                    get: function () {
                        return "AssociatedEntityTypeCodeValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "CreatedByValue", {
                    get: function () {
                        return "CreatedByValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "CreatedOnValue", {
                    get: function () {
                        return "CreatedOnValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "LanguageValue", {
                    get: function () {
                        return "LanguageValue";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            ExcelWordTemplate.ResourceKeys = ResourceKeys;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            var SummarySectionStyles = (function () {
                function SummarySectionStyles(context) {
                    this._summarySectionLeftSideLabelsStyle = {};
                    this._summarySectionRightSideLabelsStyle = {};
                    this._summarySectionCombinedLabelContainersStyle = {};
                    this._summarySectionContainer = {};
                    this._summarySectionOfFileKey = {};
                    this._summarySectionKeyDescription = {};
                    this._summarySectionKeyTypeCode = {};
                    this._summarySectionValueDescription = {};
                    this._summarySectionValueDescriptionElse = {};
                    this._summarySectionCombinedContainer = {};
                    this._context = context;
                    this._summarySectionLeftSideLabelsStyle = null;
                    this._summarySectionRightSideLabelsStyle = null;
                    this._summarySectionCombinedLabelContainersStyle = null;
                    this._summarySectionContainer = null;
                    this._summarySectionOfFileKey = null;
                    this._summarySectionKeyDescription = null;
                    this._summarySectionKeyTypeCode = null;
                    this._summarySectionValueDescription = null;
                    this._summarySectionValueDescriptionElse = null;
                    this._summarySectionCombinedContainer = null;
                }
                SummarySectionStyles.prototype.SummarySectionLeftSideLabelsStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionLeftSideLabelsStyle)) {
                        this._summarySectionLeftSideLabelsStyle = {};
                        this._summarySectionLeftSideLabelsStyle["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionLeftSideLabelsStyle["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionLeftSideLabelsStyle["marginBottom"] = "0rem";
                        this._summarySectionLeftSideLabelsStyle["marginLeft"] = this._context.theming.measures.measure025;
                    }
                    return this._summarySectionLeftSideLabelsStyle;
                };
                SummarySectionStyles.prototype.SummarySectionRightSideLabelsStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionRightSideLabelsStyle)) {
                        this._summarySectionRightSideLabelsStyle = {};
                        this._summarySectionRightSideLabelsStyle["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._summarySectionRightSideLabelsStyle["color"] = "#000000";
                        this._summarySectionRightSideLabelsStyle["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionRightSideLabelsStyle["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionRightSideLabelsStyle["marginBottom"] = "0rem";
                        this._summarySectionRightSideLabelsStyle["marginLeft"] = this._context.theming.measures.measure025;
                    }
                    return this._summarySectionRightSideLabelsStyle;
                };
                SummarySectionStyles.prototype.SummarySectionCombinedLabelContainersStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionCombinedLabelContainersStyle)) {
                        this._summarySectionCombinedLabelContainersStyle = {};
                        this._summarySectionCombinedLabelContainersStyle["display"] = "flex";
                        this._summarySectionCombinedLabelContainersStyle["flexDirection"] = "column";
                        this._summarySectionCombinedLabelContainersStyle["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionCombinedLabelContainersStyle["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionCombinedLabelContainersStyle["marginBottom"] = "0rem";
                        this._summarySectionCombinedLabelContainersStyle["marginLeft"] = "0rem";
                    }
                    return this._summarySectionCombinedLabelContainersStyle;
                };
                SummarySectionStyles.prototype.SummarySectionContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionContainer)) {
                        this._summarySectionContainer = {};
                        this._summarySectionContainer["display"] = "flex";
                        this._summarySectionContainer["flexDirection"] = "column";
                    }
                    return this._summarySectionContainer;
                };
                SummarySectionStyles.prototype.SummarySectionOfFileKey = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionOfFileKey)) {
                        this._summarySectionOfFileKey = {};
                        this._summarySectionOfFileKey["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._summarySectionOfFileKey["color"] = "#000000";
                        this._summarySectionOfFileKey["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionOfFileKey["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionOfFileKey["marginBottom"] = "0rem";
                        this._summarySectionOfFileKey["marginLeft"] = this._context.theming.measures.measure025;
                    }
                    return this._summarySectionOfFileKey;
                };
                SummarySectionStyles.prototype.SummarySectionKeyDescription = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionKeyDescription)) {
                        this._summarySectionKeyDescription = {};
                        this._summarySectionKeyDescription["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionKeyDescription["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionKeyDescription["marginBottom"] = "0rem";
                        this._summarySectionKeyDescription["marginLeft"] = this._context.theming.measures.measure025;
                        this._summarySectionKeyDescription["maxHeight"] = "1rem";
                    }
                    return this._summarySectionKeyDescription;
                };
                SummarySectionStyles.prototype.SummarySectionKeyTypeCode = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionKeyTypeCode)) {
                        this._summarySectionKeyTypeCode = {};
                        this._summarySectionKeyTypeCode["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionKeyTypeCode["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionKeyTypeCode["marginBottom"] = "0rem";
                        this._summarySectionKeyTypeCode["marginLeft"] = this._context.theming.measures.measure025;
                        this._summarySectionKeyTypeCode["whiteSpace"] = "nowrap";
                        this._summarySectionKeyTypeCode["width"] = "8rem";
                        this._summarySectionKeyTypeCode["overflow"] = "hidden";
                        this._summarySectionKeyTypeCode["textOverflow"] = "ellipsis";
                        this._summarySectionKeyTypeCode["display"] = "inline-block";
                    }
                    return this._summarySectionKeyTypeCode;
                };
                SummarySectionStyles.prototype.SummarySectionValueDescription = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionValueDescription)) {
                        this._summarySectionValueDescription = {};
                        this._summarySectionValueDescription["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._summarySectionValueDescription["color"] = "#000000";
                        this._summarySectionValueDescription["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionValueDescription["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionValueDescription["marginBottom"] = "0rem";
                        this._summarySectionValueDescription["marginLeft"] = this._context.theming.measures.measure025;
                        this._summarySectionValueDescription["maxHeight"] = "1rem";
                    }
                    return this._summarySectionValueDescription;
                };
                SummarySectionStyles.prototype.SummarySectionValueDescriptionElse = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionValueDescriptionElse)) {
                        this._summarySectionValueDescriptionElse = {};
                        this._summarySectionValueDescriptionElse["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._summarySectionValueDescriptionElse["color"] = "#000000";
                        this._summarySectionValueDescriptionElse["marginTop"] = this._context.theming.measures.measure050;
                        this._summarySectionValueDescriptionElse["marginRight"] = this._context.theming.measures.measure025;
                        this._summarySectionValueDescriptionElse["marginBottom"] = "0rem";
                        this._summarySectionValueDescriptionElse["marginLeft"] = this._context.theming.measures.measure025;
                        this._summarySectionValueDescriptionElse["maxHeight"] = "1rem";
                        this._summarySectionValueDescriptionElse["maxWidth"] = "12rem";
                        this._summarySectionValueDescriptionElse["overflowY"] = "auto";
                    }
                    return this._summarySectionValueDescriptionElse;
                };
                SummarySectionStyles.prototype.SummarySectionCombinedContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._summarySectionCombinedContainer)) {
                        this._summarySectionCombinedContainer = {};
                        this._summarySectionCombinedContainer["display"] = "flex";
                        this._summarySectionCombinedContainer["flexDirection"] = "row";
                    }
                    return this._summarySectionCombinedContainer;
                };
                return SummarySectionStyles;
            }());
            ExcelWordTemplate.SummarySectionStyles = SummarySectionStyles;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SummarySection.js.map