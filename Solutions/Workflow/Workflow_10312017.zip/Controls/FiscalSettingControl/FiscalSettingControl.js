var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/external/TypeDefinitions/microsoft.ajax.d.ts" />
/// <reference path="privatereferences.ts"/>
/*Fiscal Setting class shows up a collection of controls required for update fiscal setting of the organization*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FiscalSetting;
        (function (FiscalSetting) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            var FiscalSettingControl = (function () {
                function FiscalSettingControl() {
                    this.MILLISECONDS_IN_SECOND = 6e4;
                    this.fiscalCalendarStartValue = null;
                    this._startDateFormat = "{0}-{1}-{2}T10:59:00Z";
                    this._applyStyles = null;
                    this._dateChangeHandler = this._startDateControlOnChange.bind(this);
                }
                FiscalSettingControl.Error = function (errorMessage, errorCode, alertType) {
                    if (errorCode == undefined)
                        console.error(errorMessage);
                    else {
                        console.error("ErrorCode:" + errorCode + "Error message:" + errorMessage);
                    }
                };
                /**
                * Previously, we are storing Fiscal start date as noon time and when user's timezone is set to either GMT+12 or GMT+13
                * then user views the Fiscal Year Settings the start date will be shown as one day past the actual date that was set originally.
                * So changing Fiscal Start date with Time 10:59 of the actual date,It will give same fiscal start date after retrieval for GMT+12,GMT+13
                * This fix won't work for Timezone GMT-12, GMT-11. Assumption made here that we don't have any client in those Timezones.
                * @param startDate
                */
                FiscalSettingControl.prototype.formatFiscalCalendarStartDate = function (startDate) {
                    var _startDateFormat = "{0}-{1}-{2}T10:59:00Z";
                    var formattedDate = "";
                    var year = startDate.getFullYear().toString();
                    var month = startDate.getMonth() + 1 < 10 ? "0" + (startDate.getMonth() + 1).toString() : (startDate.getMonth() + 1).toString();
                    var day = startDate.getDate() < 10 ? "0" + startDate.getDate().toString() : startDate.getDate().toString();
                    formattedDate = String.format(_startDateFormat, year, month, day);
                    return formattedDate;
                };
                /**
                 * Event triggered on clicking save button
                */
                FiscalSettingControl.prototype.onSaveButtonClicked = function () {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.FISCALYEAR, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "SaveButton", FiscalSetting.ResourceKeys.SAVEBUTTON.id, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "SaveButton Clicked", false);
                    if (this.isValidStartDate(this.fiscalCalendarStartValue)) {
                        this._jsonData.fiscalcalendarstart = this.formatFiscalCalendarStartDate(this.fiscalCalendarStartValue);
                        var data = this._jsonData;
                        // Updating integer to string.
                        data["fiscalyearperiodconnect"] = this._mapFiscalYearPeriodConnect[this._jsonData.fiscalyearperiodconnect];
                        var that = this;
                        this._context.webAPI.updateRecord(FiscalSetting.ENTITY.ORGANIZATION, this._jsonData.organizationid, data).then(function successCallback(successResponse) {
                            var saveNotificationMessage = that._context.resources.getString(FiscalSetting.FiscalSettingString.SaveNotificationResourceKey);
                            that._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, saveNotificationMessage, "", null).then(function (response) {
                                console.log("Notification successful.");
                                //Notification displayed successfully
                            }, function (error) {
                                console.error("Error displaying notification : " + error);
                            });
                        }, function errorCallback(errorResponse) {
                            SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.FISCALYEAR, errorResponse);
                            var alertMessage = {
                                text: that._context.resources.getString(FiscalSetting.ResourceKeys.FY_GENERIC_ERROR.key)
                            };
                            that._context.navigation.openAlertDialog(alertMessage);
                        });
                    }
                };
                /**
                 * Verifies if the datetime control has valid value
                 * @param datetime
                 */
                FiscalSettingControl.prototype.isValidStartDate = function (dateTimeCtrlValue) {
                    var year = dateTimeCtrlValue.getUTCFullYear();
                    var month = dateTimeCtrlValue.getUTCMonth() + 1;
                    var date = dateTimeCtrlValue.getUTCDate() + 1;
                    if (year > 2100) {
                        // We do not support a start year greater than 2100
                        var alertMessage = {
                            text: this._context.resources.getString(FiscalSetting.ResourceKeys.FSStartDateMaxValueError.key)
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                        return false;
                    }
                    if (year < 1753) {
                        // We do not support a start year less than 1753
                        var alertMessage = {
                            text: this._context.resources.getString(FiscalSetting.ResourceKeys.FSStartDateInvalidValueAlert.key)
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                        return false;
                    }
                    // We need to check this only if the fiscal calendar start on 2/29
                    if (month == 2 && date == 29) {
                        // Leap years are divisible by 4 and not divisible by 100 (except they are divisible by 400).
                        if (year % 4 == 0 && !(year % 100 == 0 && year % 400 != 0)) {
                            // Leap year
                            var alertMessage = {
                                text: this._context.resources.getString(FiscalSetting.ResourceKeys.FSStartDateLeapYear.key)
                            };
                            this._context.navigation.openAlertDialog(alertMessage);
                            return false;
                        }
                    }
                    return true;
                };
                /**
                 * Verifies if the date is valid
                 * @param datetime
                 */
                FiscalSettingControl.prototype.isValidDate = function (dateValue) {
                    if (isNaN(Date.parse(dateValue.toString()))) {
                        return false;
                    }
                    return true;
                };
                /**
                *Event triggered on selecting a new selectedOption in the select box
                * @param selectedOption: new selectedOption selected in the select box
                */
                FiscalSettingControl.prototype._startDateControlOnChange = function (change) {
                    var controlValue = change ? change : null;
                    if (controlValue.getTime() === this.fiscalCalendarStartValue.getTime()) {
                        return;
                    }
                    else if (this.isValidDate(controlValue)) {
                        this.fiscalCalendarStartValue = controlValue;
                    }
                    this._context.utils.requestRender();
                };
                FiscalSettingControl.prototype.InitializingFiscalPeriodTemplateControl = function () {
                    /*Initialzing the select box fpTemplateCmb*/
                    this._fiscalPeriodTemplateSB = new FiscalSetting.SelectBox(FiscalSetting.SelectBox.DEFAULTLISTID);
                    this._fiscalPeriodTemplateSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FPTEMPLATECMB.keys[0]), "2000");
                    this._fiscalPeriodTemplateSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FPTEMPLATECMB.keys[1]), "2001");
                    this._fiscalPeriodTemplateSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FPTEMPLATECMB.keys[2]), "2002");
                    this._fiscalPeriodTemplateSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FPTEMPLATECMB.keys[3]), "2003");
                    this._fiscalPeriodTemplateSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FPTEMPLATECMB.keys[4]), "2004");
                };
                FiscalSettingControl.prototype.FiscalPeriodTemplateControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalperiodtype = selectedOption.Value;
                    this._fiscalPeriodSB.changeCurrentListId(String(selectedOption.Value));
                    this._jsonData.fiscalperiodformatperiod = (this._fiscalPeriodSB.currentOptions[0].Value);
                    this._context.utils.requestRender();
                };
                FiscalSettingControl.prototype.InitializingPrefixControl = function () {
                    /*Initialzing the select box prefixCmb*/
                    this._prefixSB = new FiscalSetting.SelectBox(FiscalSetting.SelectBox.DEFAULTLISTID);
                    this._prefixSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.PREFIXCMB.keys[0]), "1");
                    this._prefixSB.addItems("", "2");
                };
                FiscalSettingControl.prototype.PrefixControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalyearformatprefix = selectedOption.Value;
                };
                FiscalSettingControl.prototype.InitializingYearFormatControl = function () {
                    /*Initialzing the select box yearFormatCmb*/
                    this._yearFormatSB = new FiscalSetting.SelectBox(FiscalSetting.SelectBox.DEFAULTLISTID);
                    this._yearFormatSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.YEARFORMATCMB.keys[0]), "1");
                    this._yearFormatSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.YEARFORMATCMB.keys[1]), "2");
                    this._yearFormatSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.YEARFORMATCMB.keys[2]), "3");
                };
                FiscalSettingControl.prototype.YearFormatControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalyearformatyear = selectedOption.Value;
                };
                FiscalSettingControl.prototype.InitialzingSuffixControl = function () {
                    /*Initialzing the select box postFixCmb*/
                    this._suffixSB = new FiscalSetting.SelectBox(FiscalSetting.SelectBox.DEFAULTLISTID);
                    this._suffixSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.SUFFIXCMB.keys[0]), "1");
                    this._suffixSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.SUFFIXCMB.keys[1]), "2");
                    this._suffixSB.addItems("", "3");
                };
                FiscalSettingControl.prototype.SuffixControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalyearformatsuffix = selectedOption.Value;
                };
                FiscalSettingControl.prototype.InitialzingFiscalPeriodControl = function () {
                    /*Initialzing the select box fiscalPeriodCmb*/
                    this._fiscalPeriodSB = new FiscalSetting.SelectBox(String(this._jsonData.fiscalperiodtype));
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[3]), "3", "2000");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[6]), "6", "2001");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[3]), "3", "2001");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[1]), "1", "2002");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[2]), "2", "2002");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[3]), "3", "2002");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[7]), "7", "2003");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[5]), "5", "2003");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[4]), "4", "2003");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[3]), "3", "2003");
                    this._fiscalPeriodSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODCMB.keys[3]), "3", "2004");
                };
                FiscalSettingControl.prototype.FiscalPeriodControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalperiodformatperiod = selectedOption.Value;
                };
                FiscalSettingControl.prototype.InitialzingNameBasedOnControl = function () {
                    /*Initialzing the select box nameBasedOnCmb*/
                    this._namedBasedOnSB = new FiscalSetting.SelectBox(FiscalSetting.SelectBox.DEFAULTLISTID);
                    this._namedBasedOnSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.NAMEBASEDONCMB.keys[0]), "1");
                    this._namedBasedOnSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.NAMEBASEDONCMB.keys[1]), "2");
                };
                FiscalSettingControl.prototype.NameBasedOnControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalyeardisplaycode = selectedOption.Value;
                };
                /**
                 * Create Fiscal Period Template Components
                 */
                FiscalSettingControl.prototype.CreateFiscalPeriodTemplateComponents = function () {
                    this._fpTemplateLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.FPTEMPLATELBL.id,
                        id: FiscalSetting.ResourceKeys.FPTEMPLATELBL.id,
                        forElementId: this._context.accessibility.getUniqueId(FiscalSetting.ResourceKeys.FPTEMPLATECMB.id),
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.FPTEMPLATELBL.key));
                    this._fiscalPeriodTemplateSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.FPTEMPLATECMB.id,
                        id: FiscalSetting.ResourceKeys.FPTEMPLATECMB.id,
                        freeTextMode: true,
                        value: { Value: this._jsonData.fiscalperiodtype, Color: null },
                        onChange: this.FiscalPeriodTemplateControlOnChange.bind(this),
                        options: this._fiscalPeriodTemplateSB.currentOptions,
                        style: this._applyStyles.selectStyle()
                    };
                    this._fiscalPeriodTemplateSB.component =
                        this._context.factory.createElement("SELECT", this._fiscalPeriodTemplateSB.controlProps, null);
                    var fptemplateSelectBoxContainer = this._context.factory.createElement("CONTAINER", {
                        id: FiscalSetting.ResourceKeys.FPTEMPLATECMB.id,
                        style: this._applyStyles.FYCmbContainer()
                    }, [this._fiscalPeriodTemplateSB.component]);
                    var fpTemplateDiv = this._context.factory.createElement("CONTAINER", { key: FiscalSetting.FiscalSettingString.FPTEMPLATEDIV, id: FiscalSetting.FiscalSettingString.FPTEMPLATEDIV }, [this._fpTemplateLbl, fptemplateSelectBoxContainer]);
                    return fpTemplateDiv;
                };
                /* Create Fiscal Year Subsection Components Prefix + Year format + Suffix */
                FiscalSettingControl.prototype.CreateFiscalYearFormatComponents = function () {
                    this._prefixLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.PREFIXLBL.id,
                        id: FiscalSetting.ResourceKeys.PREFIXLBL.id,
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.PREFIXLBL.key));
                    this._prefixSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.PREFIXCMB.id,
                        id: FiscalSetting.ResourceKeys.PREFIXCMB.id,
                        freeTextMode: true,
                        onChange: this.PrefixControlOnChange.bind(this),
                        value: { Value: this._jsonData.fiscalyearformatprefix, Color: null },
                        disabled: false,
                        options: this._prefixSB.currentOptions,
                        accessibilityLabel: this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARLBL.key) + ":" + this._context.resources.getString(FiscalSetting.ResourceKeys.PREFIXLBL.key),
                        style: this._applyStyles.selectStyle()
                    };
                    this._prefixSB.component = this._context.factory.createElement("SELECT", this._prefixSB.controlProps, null);
                    var prefixSelectorContainer = this._context.factory.createElement("CONTAINER", { style: this._applyStyles.FYSCmbContainer() }, [this._prefixSB.component]);
                    var prefixDiv = this._context.factory.createElement("CONTAINER", { key: FiscalSetting.FiscalSettingString.PREFIXDIV, id: FiscalSetting.FiscalSettingString.PREFIXDIV, style: this._applyStyles.FYLabelComboContainer() }, [this._prefixLbl, prefixSelectorContainer]);
                    this._yearFormatLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.YEARFROMATLBL.id,
                        id: FiscalSetting.ResourceKeys.YEARFROMATLBL.id,
                        style: this._applyStyles.FYYearFormatLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.YEARFROMATLBL.key));
                    this._yearFormatSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.YEARFORMATCMB.id,
                        id: FiscalSetting.ResourceKeys.YEARFORMATCMB.id,
                        freeTextMode: true,
                        value: { Value: this._jsonData.fiscalyearformatyear, Color: null },
                        onChange: this.YearFormatControlOnChange.bind(this),
                        options: this._yearFormatSB.currentOptions,
                        accessibilityLabel: this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARLBL.key) + ":" + this._context.resources.getString(FiscalSetting.ResourceKeys.YEARFROMATLBL.key),
                        style: this._applyStyles.selectStyle()
                    };
                    this._yearFormatSB.component = this._context.factory.createElement("SELECT", this._yearFormatSB.controlProps, null);
                    var yearSelectorContainer = this._context.factory.createElement("CONTAINER", { style: this._applyStyles.YearFormatFY_SCmbContainer() }, [this._yearFormatSB.component]);
                    var yearFormatDiv = this._context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.YEARFORMATDIV,
                        id: FiscalSetting.FiscalSettingString.YEARFORMATDIV,
                        style: this._applyStyles.FYLabelComboContainer()
                    }, [this._yearFormatLbl, yearSelectorContainer]);
                    this._postfixLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.POSTFIXLBL.id,
                        id: FiscalSetting.ResourceKeys.POSTFIXLBL.id,
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.POSTFIXLBL.key));
                    this._suffixSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.SUFFIXCMB.id,
                        id: FiscalSetting.ResourceKeys.SUFFIXCMB.id,
                        freeTextMode: true,
                        value: { Value: this._jsonData.fiscalyearformatsuffix, Color: null },
                        onChange: this.SuffixControlOnChange.bind(this),
                        options: this._suffixSB.currentOptions,
                        accessibilityLabel: this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARLBL.key) + ":" + this._context.resources.getString(FiscalSetting.ResourceKeys.POSTFIXLBL.key),
                        style: this._applyStyles.selectStyle()
                    };
                    this._suffixSB.component = this._context.factory.createElement("SELECT", this._suffixSB.controlProps, null);
                    var postfixSelectorContainer = this._context.factory.createElement("CONTAINER", { style: this._applyStyles.FYSCmbContainer() }, [this._suffixSB.component]);
                    var postfixDiv = this._context.factory.createElement("CONTAINER", { key: FiscalSetting.FiscalSettingString.POSTFIXDIV, id: FiscalSetting.FiscalSettingString.POSTFIXDIV, style: this._applyStyles.FYLabelComboContainer() }, [this._postfixLbl, postfixSelectorContainer]);
                    var prefixPostfixDivs = this._context.factory.createElement("CONTAINER", { key: FiscalSetting.FiscalSettingString.PREFIXPOSTFIXDIV, id: FiscalSetting.FiscalSettingString.PREFIXPOSTFIXDIV, style: this._applyStyles.FYPrefixPostfixContainer() }, [prefixDiv, yearFormatDiv, postfixDiv]);
                    return prefixPostfixDivs;
                };
                /* Create Fiscal Period Components */
                FiscalSettingControl.prototype.createFiscalPeriodComponents = function () {
                    this._fiscalPeriodLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.FISCALPERIODLBL.id,
                        id: FiscalSetting.ResourceKeys.FISCALPERIODLBL.id,
                        forElementId: this._context.accessibility.getUniqueId(FiscalSetting.ResourceKeys.FISCALPERIODCMB.id),
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALPERIODLBL.key));
                    this._fiscalPeriodSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.FISCALPERIODCMB.id,
                        id: FiscalSetting.ResourceKeys.FISCALPERIODCMB.id,
                        freeTextMode: true,
                        value: { Value: this._jsonData.fiscalperiodformatperiod, Color: null },
                        onChange: this.FiscalPeriodControlOnChange.bind(this),
                        options: this._fiscalPeriodSB.currentOptions,
                        style: this._applyStyles.selectStyle()
                    };
                    this._fiscalPeriodSB.component = this._context.factory.createElement("SELECT", this._fiscalPeriodSB.controlProps, null);
                    var fiscalPeriodSelectorContainer = this._context.factory.createElement("CONTAINER", { style: this._applyStyles.FYCmbContainer() }, [this._fiscalPeriodSB.component]);
                    var fiscalPeriodCntlDiv = this._context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.FISCALPERIODCNTLDIV, id: FiscalSetting.FiscalSettingString.FISCALPERIODCNTLDIV
                    }, [this._fiscalPeriodLbl, fiscalPeriodSelectorContainer]);
                    return fiscalPeriodCntlDiv;
                };
                /* Create Name Based on segment components */
                FiscalSettingControl.prototype.createNameBasedOnComponents = function () {
                    this._namedBasedOnLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.NAMEBASEDONLBL.id,
                        id: FiscalSetting.ResourceKeys.NAMEBASEDONLBL.id,
                        forElementId: this._context.accessibility.getUniqueId(FiscalSetting.ResourceKeys.NAMEBASEDONCMB.id),
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.NAMEBASEDONLBL.key));
                    this._namedBasedOnSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.NAMEBASEDONCMB.id,
                        id: FiscalSetting.ResourceKeys.NAMEBASEDONCMB.id,
                        freeTextMode: true,
                        value: { Value: this._jsonData.fiscalyeardisplaycode, Color: null },
                        onChange: this.NameBasedOnControlOnChange.bind(this),
                        options: this._namedBasedOnSB.currentOptions,
                        style: this._applyStyles.selectStyle()
                    };
                    this._namedBasedOnSB.component = this._context.factory.createElement("SELECT", this._namedBasedOnSB.controlProps, null);
                    var nameBasedOnSelectorContainer = this._context.factory.createElement("CONTAINER", { style: this._applyStyles.FYCmbContainer() }, [this._namedBasedOnSB.component]);
                    var namedBasedOnControlDiv = this._context.factory.createElement("CONTAINER", { key: FiscalSetting.FiscalSettingString.NAMEBASEDONCNTLDIV, id: FiscalSetting.FiscalSettingString.NAMEBASEDONCNTLDIV }, [this._namedBasedOnLbl, nameBasedOnSelectorContainer]);
                    return namedBasedOnControlDiv;
                };
                /* Create Display as segment components */
                FiscalSettingControl.prototype.createDisplayAsComponents = function () {
                    this._displayAsLbl = this._context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.DISPLAYASLBL.id,
                        id: FiscalSetting.ResourceKeys.DISPLAYASLBL.id,
                        forElementId: this._context.accessibility.getUniqueId(FiscalSetting.ResourceKeys.DISPLAYASCMB.id),
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASLBL.key));
                    this._displayAsSB.controlProps = {
                        key: FiscalSetting.ResourceKeys.DISPLAYASCMB.id,
                        id: FiscalSetting.ResourceKeys.DISPLAYASCMB.id,
                        freeTextMode: true,
                        value: { Value: this._jsonData.fiscalyearperiodconnect, Color: null },
                        onChange: this.DisplayAsControlOnChange.bind(this),
                        options: this._displayAsSB.currentOptions,
                        style: this._applyStyles.selectStyle()
                    };
                    this._displayAsSB.component = this._context.factory.createElement("SELECT", this._displayAsSB.controlProps, null);
                    var displayAsSelectorContainer = this._context.factory.createElement("CONTAINER", { style: this._applyStyles.FYCmbContainer() }, [this._displayAsSB.component]);
                    var displayAsCntlDiv = this._context.factory.createElement("CONTAINER", { key: FiscalSetting.FiscalSettingString.DISPLAYASCNTLDIV, id: FiscalSetting.FiscalSettingString.DISPLAYASCNTLDIV }, [this._displayAsLbl, displayAsSelectorContainer]);
                    return displayAsCntlDiv;
                };
                FiscalSettingControl.prototype.InitialzingDisplayAsControl = function () {
                    /*Initialzing the select box displayAsCmb*/
                    this._displayAsSB = new FiscalSetting.SelectBox(FiscalSetting.SelectBox.DEFAULTLISTID);
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[0]), "0");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[1]), "1");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[2]), "2");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[3]), "3");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[4]), "4");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[5]), "5");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[6]), "6");
                    this._displayAsSB.addItems(this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYASCMB.keys[7]), "7");
                };
                FiscalSettingControl.prototype.DisplayAsControlOnChange = function (selectedOption) {
                    this._jsonData.fiscalyearperiodconnect = selectedOption.Value;
                };
                /**
                    * This function should be used for any initial setup necessary for your control.
                    * @params context The "Input Bag" containing the parameters and other control metadata.
                    * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                    * @params state The user state for this control set from setState in the last session
                    * @params container The div element to draw this control in
                    */
                FiscalSettingControl.prototype.init = function (context, state) {
                    this._mapFiscalYearPeriodConnect = ["s", "Ns", "-", "/", "Rs", "R", "R-", "R/"];
                    this._context = context;
                    var title = this._context.resources.getString(FiscalSetting.ResourceKeys.AdvancedSettingsText.key) + " " + this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARSETTINGLBL.key) + " - " + this._context.resources.getString(FiscalSetting.ResourceKeys.MicrosoftDynamics365Text.key);
                    this._freShell = new FREShell(context, title);
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.FISCALYEAR, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "FiscalSettingPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Page Visited", false);
                    var orgsettings = this._context.client.orgSettings;
                    this._jsonData = {
                        fiscalperiodtype: orgsettings.fiscalPeriodType,
                        fiscalyearformatyear: orgsettings.fiscalYearFormatYear,
                        fiscalperiodformatperiod: orgsettings.fiscalPeriodFormat,
                        fiscalyearperiodconnect: this._mapFiscalYearPeriodConnect.indexOf(orgsettings.fiscalPeriodConnector),
                        fiscalyeardisplaycode: orgsettings.fiscalYearDisplayCode,
                        fiscalyearformatprefix: orgsettings.fiscalYearFormatPrefix,
                        fiscalyearformatsuffix: orgsettings.fiscalYearFormatSuffix,
                        fiscalcalendarstart: "",
                        organizationid: FiscalSetting.FiscalSettingString.EMPTY
                    };
                    this.fiscalCalendarStartValue = new Date();
                    // Initializing all the select box in fiscal setting page.
                    this.InitializingFiscalPeriodTemplateControl();
                    this.InitialzingDisplayAsControl();
                    this.InitialzingFiscalPeriodControl();
                    this.InitializingYearFormatControl();
                    this.InitialzingNameBasedOnControl();
                    this.InitializingPrefixControl();
                    this.InitialzingSuffixControl();
                    // Retreiveing data for all the select box TODO:To be removed when data retireval is fully from the metadata
                    this.RetreiveDataForFiscalSettingPage();
                    //register event to handle Ctrl + S keyboard event
                    this.controlPlusSEventHanlder();
                };
                FiscalSettingControl.prototype.RetreiveDataForFiscalSettingPage = function () {
                    var that = this;
                    var uri = this._context.utils.createCrmUri(FiscalSetting.FiscalSettingString.CRMURI);
                    //O-data call for getting options for ComboBox
                    var c = $.getJSON(uri + FiscalSetting.FiscalSettingString.ORGANIZATIONURI)
                        .done(function (data) {
                        that._jsonData.organizationid = data.value[0].organizationid;
                        that._jsonData.fiscalcalendarstart = data.value[0].fiscalcalendarstart;
                        that._jsonData.fiscalperiodformatperiod = data.value[0].fiscalperiodformatperiod;
                        that._jsonData.fiscalperiodtype = data.value[0].fiscalperiodtype;
                        that._jsonData.fiscalyeardisplaycode = data.value[0].fiscalyeardisplaycode;
                        that._jsonData.fiscalyearformatprefix = data.value[0].fiscalyearformatprefix;
                        that._jsonData.fiscalyearformatsuffix = data.value[0].fiscalyearformatsuffix;
                        that._jsonData.fiscalyearformatyear = data.value[0].fiscalyearformatyear;
                        if (!that._context.utils.isNullOrUndefined(data.value[0].fiscalyearperiodconnect)) {
                            that._jsonData.fiscalyearperiodconnect = that._mapFiscalYearPeriodConnect.indexOf(data.value[0].fiscalyearperiodconnect);
                        }
                        else {
                            that._jsonData.fiscalyearperiodconnect = 0;
                        }
                        that.fiscalCalendarStartValue = new Date(data.value[0].fiscalcalendarstart);
                        that._context.utils.requestRender();
                    })
                        .fail(function (data) {
                        var alertMessage = {
                            text: that._context.resources.getString(FiscalSetting.ResourceKeys.FY_GENERIC_ERROR.key)
                        };
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(this._context, SmbAppsTelemetryUtility.Controls_PageType.FISCALYEAR, data);
                        that._context.navigation.openAlertDialog(alertMessage);
                        FiscalSettingControl.Error(FiscalSetting.Notification.DATARETRIEVEFAILURE);
                    });
                };
                /**
                    * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                    * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                    * as well as resource, client, and theming info (see mscrm.d.ts)
                    * @params context The "Input Bag" as described above
                */
                FiscalSettingControl.prototype.updateView = function (context) {
                    return this._freShell.getVirtualComponents(this.getChildControls(context));
                };
                FiscalSettingControl.prototype.getChildControls = function (context) {
                    var _this = this;
                    this._context = context;
                    var params = {};
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new FiscalSetting.FiscalSettingControlStyles(context);
                    }
                    params.normalIconImagePath = FiscalSetting.FiscalSettingString.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = FiscalSetting.FiscalSettingString.HeaderHighContrastIconImagePath;
                    params.areaLabel = this._context.resources.getString(FiscalSetting.ResourceKeys.ORGANIZATIONSETUPLBL.key);
                    params.subAreaLabel = this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARSETTINGLBL.key);
                    params.addHeaderRightButtonLastInDom = true;
                    params.contentContainerStyle = this._applyStyles.FYSContentContainer();
                    /* Intializing all the Labels in the compound control */
                    this._organizationSetupLbl = context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.ORGANIZATIONSETUPLBL.id,
                        id: FiscalSetting.ResourceKeys.ORGANIZATIONSETUPLBL.id, style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.ORGANIZATIONSETUPLBL.key));
                    this._fiscalYearLbl = context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.FISCALYEARLBL.id,
                        id: FiscalSetting.ResourceKeys.FISCALYEARLBL.id, style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARLBL.key));
                    this._setTheFPLbl = context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.SETTHEFPLBL.id,
                        id: FiscalSetting.ResourceKeys.SETTHEFPLBL.id, style: this._applyStyles.FYSetTheFPLblFRESectionLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.SETTHEFPLBL.key));
                    this._startDateLbl = context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.STARTDATELBL.id,
                        id: FiscalSetting.ResourceKeys.STARTDATELBL.id,
                        forElementId: this._context.accessibility.getUniqueId(FiscalSetting.FiscalSettingString.STARTDATECONTROL),
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.STARTDATELBL.key));
                    this._displaySettingLbl = context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.DISPLAYSETTINGLBL.id,
                        id: FiscalSetting.ResourceKeys.DISPLAYSETTINGLBL.id,
                        style: this._applyStyles.FYDisplaySettingLblFRESectionLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.DISPLAYSETTINGLBL.key));
                    this._fiscalYearSettingsLbl = context.factory.createElement("LABEL", {
                        key: FiscalSetting.ResourceKeys.FISCALYEARSETTINGLBL.id,
                        id: FiscalSetting.ResourceKeys.FISCALYEARSETTINGLBL.id,
                        style: this._applyStyles.FYLabel()
                    }, this._context.resources.getString(FiscalSetting.ResourceKeys.FISCALYEARSETTINGLBL.key));
                    var outputValue;
                    var currentTimeZoneOffsetMillisec = this.fiscalCalendarStartValue.getTimezoneOffset() * this.MILLISECONDS_IN_SECOND;
                    //We need to do this becase Date Time Control adds currentTimeZoneOffsetMillisec
                    outputValue = new Date(this.fiscalCalendarStartValue.getTime() - currentTimeZoneOffsetMillisec);
                    var startDateControlProperties = {};
                    startDateControlProperties = {
                        "parameters": {
                            "value": {
                                Usage: 3 /*PropertyUsage.FalseBound*/,
                                Static: true,
                                Value: outputValue,
                                Callback: function (change) { return _this._dateChangeHandler(change); },
                                Type: "DateAndTime.DateOnly",
                                Attributes: {
                                    Format: "dateonly",
                                    Type: "datetime",
                                    Behavior: 3,
                                    RequiredLevel: 1
                                }
                            },
                            "deviceSizeMode": {
                                Usage: 1,
                                Static: true,
                                Value: 0,
                                Type: "Enum",
                                Primary: false
                            }
                        }
                    };
                    var startDateCustomControl = this._context.factory.createComponent("MscrmControls.FieldControls.DateTimeControl", FiscalSetting.FiscalSettingString.STARTDATECONTROL, startDateControlProperties);
                    var startDateControlDiv = context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.STARTDATECONTROLDIV, id: FiscalSetting.FiscalSettingString.STARTDATECONTROLDIV,
                        style: this._applyStyles.FYStartDateControlDiv()
                    }, [startDateCustomControl]);
                    var startDateControlContainer = this._context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.STARTDATECONTROLCONTAINER, id: FiscalSetting.FiscalSettingString.STARTDATECONTROLCONTAINER
                    }, [this._startDateLbl, startDateControlDiv]);
                    /* Create Fiscal period template segment components */
                    var fpTemplateDiv = this.CreateFiscalPeriodTemplateComponents();
                    /* Create Fiscal Year format segment Components */
                    var prefixPostfixDivs = this.CreateFiscalYearFormatComponents();
                    /* Create Fiscal Period segment Components */
                    var fiscalPeriodCntlDiv = this.createFiscalPeriodComponents();
                    /* Create Name based on segment components */
                    var namedBasedOnControlDiv = this.createNameBasedOnComponents();
                    /* Create Display As segment Components */
                    var displayAsCntlDiv = this.createDisplayAsComponents();
                    /*
                        * SubSection container is part of section Container
                    */
                    var subSectionContainerProps = {
                        id: FiscalSetting.FiscalSettingString.SUBSECTIONCONTAINERDIV, key: FiscalSetting.FiscalSettingString.SUBSECTIONCONTAINERDIV, style: this._applyStyles.FYSubsectionContainer()
                    };
                    var subSectionContainer = context.factory.createElement("CONTAINER", subSectionContainerProps, [this._setTheFPLbl, startDateControlContainer, fpTemplateDiv, this._displaySettingLbl, this._fiscalYearLbl, prefixPostfixDivs, fiscalPeriodCntlDiv, namedBasedOnControlDiv, displayAsCntlDiv]);
                    params.headerRightContainerChild = this.createHeaderRightContainer();
                    params.contentContainerChild = subSectionContainer;
                    this._freShell.stopPerformanceStopWatch();
                    return params;
                };
                /**
                    * Creates RightContainer for header
                */
                FiscalSettingControl.prototype.createHeaderRightContainer = function () {
                    var saveIconContainer = this._context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.SaveIconContainerKey, id: FiscalSetting.FiscalSettingString.SaveIconContainerKey, style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var saveButton = this._context.factory.createElement("BUTTON", {
                        key: FiscalSetting.ResourceKeys.SAVEBUTTON.id, id: FiscalSetting.ResourceKeys.SAVEBUTTON.id,
                        onClick: this.onSaveButtonClicked.bind(this),
                        title: this._context.resources.getString(FiscalSetting.ResourceKeys.SaveButtonToolTip.key),
                        tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [saveIconContainer, this._context.resources.getString(FiscalSetting.ResourceKeys.SAVEBUTTON.key)]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.HeaderSeparatorContainerKey, id: FiscalSetting.FiscalSettingString.HeaderSeparatorContainerKey, style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: FiscalSetting.FiscalSettingString.HeaderRightContainerKey, id: FiscalSetting.FiscalSettingString.HeaderRightContainerKey, style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, saveButton]);
                    return headerRightContainer;
                };
                FiscalSettingControl.prototype.getOutputs = function () {
                    return null;
                };
                FiscalSettingControl.prototype.destroy = function () {
                    delete this._fiscalPeriodTemplateSB;
                    delete this._fiscalPeriodSB;
                    delete this._prefixSB;
                    delete this._yearFormatSB;
                    delete this._suffixSB;
                    delete this._namedBasedOnSB;
                    delete this._displayAsSB;
                };
                /**
                * This function handles Ctrl+S keyboard event to trigger save event
                */
                FiscalSettingControl.prototype.controlPlusSEventHanlder = function () {
                    var that = this;
                    this._context.accessibility.registerShortcut([17 /* Ctrl */, 83 /* S */], function (event) {
                        event.preventDefault();
                        if (!event.ctrlKey || event.keyCode !== 83 /* S */) {
                            return;
                        }
                        that.onSaveButtonClicked();
                    }, true, "", "");
                };
                return FiscalSettingControl;
            }());
            FiscalSetting.FiscalSettingControl = FiscalSettingControl;
        })(FiscalSetting = AppCommon.FiscalSetting || (AppCommon.FiscalSetting = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="FiscalSettingControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FiscalSetting;
        (function (FiscalSetting) {
            'use strict';
            var FiscalSettingControlStyles = (function (_super) {
                __extends(FiscalSettingControlStyles, _super);
                function FiscalSettingControlStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._fyLabel = {};
                    _this._fyYearFormatLabel = {};
                    _this._fySubsectionContainer = {};
                    _this._fyDisplaySettingLblFRESectionLabel = {};
                    _this._fySetTheFPLblFRESectionLabel = {};
                    _this._fySCmbContainer = {};
                    _this._fyCmbContainer = {};
                    _this._fyPrefixPostfixContainer = {};
                    _this._yearFormatFY_SCmbContainer = {};
                    _this._fyStartDateControlDiv = {};
                    _this._appendAsterisk = {};
                    _this._fyLabelComboContainer = {};
                    _this._fYSContentContainer = {};
                    _this._context = context;
                    _this._fyLabel = null;
                    _this._fyYearFormatLabel = null;
                    _this._fySubsectionContainer = null;
                    _this._fyDisplaySettingLblFRESectionLabel = null;
                    _this._fySetTheFPLblFRESectionLabel = null;
                    _this._fySCmbContainer = null;
                    _this._fyCmbContainer = null;
                    _this._fyPrefixPostfixContainer = null;
                    _this._yearFormatFY_SCmbContainer = null;
                    _this._fyStartDateControlDiv = null;
                    _this._appendAsterisk = null;
                    _this._fyLabelComboContainer = null;
                    _this._fYSContentContainer = null;
                    return _this;
                }
                FiscalSettingControlStyles.prototype.FYLabel = function () {
                    this._fyLabel = {};
                    this._fyLabel = this.FREFieldLabel();
                    this._fyLabel["marginBottom"] = this._context.theming.measures.measure025;
                    return this._fyLabel;
                };
                FiscalSettingControlStyles.prototype.FYYearFormatLabel = function () {
                    this._fyYearFormatLabel = {};
                    this._fyYearFormatLabel = JSON.parse(JSON.stringify(this._fyLabel));
                    this._fyYearFormatLabel["marginLeft"] = this._context.theming.measures.measure050;
                    this._fyYearFormatLabel["marginRight"] = this._context.theming.measures.measure050;
                    return this._fyYearFormatLabel;
                };
                FiscalSettingControlStyles.prototype.AppendAsterisk = function () {
                    if (this._context.utils.isNullOrUndefined(this._appendAsterisk)) {
                        this._appendAsterisk = {};
                        this._appendAsterisk["color"] = this._context.theming.colors.basecolor.red;
                    }
                    return this._appendAsterisk;
                };
                FiscalSettingControlStyles.prototype.FYSubsectionContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._fySubsectionContainer)) {
                        this._fySubsectionContainer = {};
                        this._fySubsectionContainer["display"] = "flex";
                        this._fySubsectionContainer["flexDirection"] = "column";
                        this._fySubsectionContainer["background"] = this._context.theming.colors.basecolor.white;
                        this._fySubsectionContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._fySubsectionContainer["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._fySubsectionContainer;
                };
                FiscalSettingControlStyles.prototype.FYDisplaySettingLblFRESectionLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._fyDisplaySettingLblFRESectionLabel)) {
                        this._fyDisplaySettingLblFRESectionLabel = {};
                        this._fyDisplaySettingLblFRESectionLabel["marginBottom"] = this._context.theming.measures.measure075;
                        this._fyDisplaySettingLblFRESectionLabel["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._fyDisplaySettingLblFRESectionLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._fyDisplaySettingLblFRESectionLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._fyDisplaySettingLblFRESectionLabel["marginTop"] = this._context.theming.measures.measure075;
                    }
                    return this._fyDisplaySettingLblFRESectionLabel;
                };
                FiscalSettingControlStyles.prototype.FYSCmbContainer = function () {
                    this._fySCmbContainer = {};
                    this._fySCmbContainer["display"] = "flex";
                    this._fySCmbContainer["flex"] = "1 1 auto";
                    this._fySCmbContainer["flexDirection"] = "column";
                    this._fySCmbContainer["width"] = "6.33rem";
                    this._fySCmbContainer["marginBottom"] = this._context.theming.measures.measure075;
                    this._fySCmbContainer["marginTop"] = this._context.theming.measures.measure025;
                    return this._fySCmbContainer;
                };
                FiscalSettingControlStyles.prototype.FYLabelComboContainer = function () {
                    this._fyLabelComboContainer = {};
                    this._fyLabelComboContainer["display"] = "flex";
                    this._fyLabelComboContainer["flexDirection"] = "column";
                    return this._fyLabelComboContainer;
                };
                FiscalSettingControlStyles.prototype.FYSetTheFPLblFRESectionLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._fySetTheFPLblFRESectionLabel)) {
                        this._fySetTheFPLblFRESectionLabel = {};
                        this._fySetTheFPLblFRESectionLabel["marginBottom"] = this._context.theming.measures.measure075;
                        this._fySetTheFPLblFRESectionLabel["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._fySetTheFPLblFRESectionLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._fySetTheFPLblFRESectionLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._fySetTheFPLblFRESectionLabel["marginTop"] = this._context.theming.measures.measure075;
                    }
                    return this._fySetTheFPLblFRESectionLabel;
                };
                FiscalSettingControlStyles.prototype.FYCmbContainer = function () {
                    this._fyCmbContainer = {};
                    this._fyCmbContainer["display"] = "flex";
                    this._fyCmbContainer["flex"] = "1 1 auto";
                    this._fyCmbContainer["flexDirection"] = "column";
                    this._fyCmbContainer["width"] = "20rem";
                    this._fyCmbContainer["marginBottom"] = this._context.theming.measures.measure075;
                    this._fyCmbContainer["marginTop"] = this._context.theming.measures.measure025;
                    return this._fyCmbContainer;
                };
                FiscalSettingControlStyles.prototype.FYPrefixPostfixContainer = function () {
                    this._fyPrefixPostfixContainer = {};
                    this._fyPrefixPostfixContainer["display"] = "flex";
                    this._fyPrefixPostfixContainer["flex"] = "0 0 auto";
                    this._fyPrefixPostfixContainer["flexDirection"] = "row";
                    return this._fyPrefixPostfixContainer;
                };
                FiscalSettingControlStyles.prototype.YearFormatFY_SCmbContainer = function () {
                    this._yearFormatFY_SCmbContainer = {};
                    this._yearFormatFY_SCmbContainer = this.FYSCmbContainer();
                    this._yearFormatFY_SCmbContainer["marginLeft"] = this._context.theming.measures.measure050;
                    this._yearFormatFY_SCmbContainer["marginRight"] = this._context.theming.measures.measure050;
                    return this._yearFormatFY_SCmbContainer;
                };
                FiscalSettingControlStyles.prototype.FYStartDateControlDiv = function () {
                    if (this._context.utils.isNullOrUndefined(this._fyStartDateControlDiv)) {
                        this._fyStartDateControlDiv = {};
                        this._fyStartDateControlDiv["marginBottom"] = this._context.theming.measures.measure075;
                    }
                    return this._fyStartDateControlDiv;
                };
                FiscalSettingControlStyles.prototype.FYSContentContainer = function () {
                    this._fYSContentContainer = {};
                    this._fYSContentContainer["display"] = "flex";
                    this._fYSContentContainer["flex"] = "1";
                    this._fYSContentContainer["backgroundColor"] = "#FFFFFF";
                    this._fYSContentContainer["maxWidth"] = "100%";
                    this._fYSContentContainer["minHeight"] = "500px";
                    return this._fYSContentContainer;
                };
                return FiscalSettingControlStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            FiscalSetting.FiscalSettingControlStyles = FiscalSettingControlStyles;
        })(FiscalSetting = AppCommon.FiscalSetting || (AppCommon.FiscalSetting = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FiscalSetting;
        (function (FiscalSetting) {
            /**
            * A select box can contain multiple list. At a time, only one list can be rendered by the select box.
            * On an event, we can change list pointer to the list which need to be rendered by select box.
            */
            var SelectBox = (function () {
                /**
                *
                * @param currentListId:creates a list and make it as current list.
                */
                function SelectBox(currentListId) {
                    //It contains set of list to be rendered in select box.
                    this._optionsList = {};
                    this._currentListId = currentListId;
                    this._optionsList[currentListId] = new Array();
                    this.currentOptions = new Array();
                    this.currentOptions = this._optionsList[currentListId];
                }
                Object.defineProperty(SelectBox, "DEFAULTLISTID", {
                    get: function () {
                        return "defaultId";
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                * This function changes the listPointer of select box to the new list @currentListId
                * @param currentListId: The new listId which is to be rendered in the select box
                */
                SelectBox.prototype.changeCurrentListId = function (currentListId) {
                    this._currentListId = currentListId;
                    this.currentOptions = this._optionsList[currentListId];
                };
                /**
                * It creates element displayed in select box.
                * Each element in select box is composed of text and value
                * @param _text:The text rendered in the select box on the screen
                * @param _value:The value corresponding to the text
                */
                SelectBox.prototype.createOption = function (_text, _value) {
                    // Converting _value to Number datatype.
                    var x = +_value;
                    return { Label: _text, Value: x };
                };
                /**
                *If list doesnot exist, then it creates new list, adds the element in list and returns true
                *else simply adds the value and text in the list and return false.
                *If listId not specified, it takes currentListId.
                * @param id use to identify the list from collection of list
                * @param key by which resource will be fetched from resource file
                * @param value value used by select box
                */
                SelectBox.prototype.addItems = function (text, value, listId) {
                    var b = false;
                    if (listId === undefined)
                        listId = this._currentListId;
                    if (this._optionsList[listId] === undefined) {
                        this._optionsList[listId] = new Array();
                        b = true;
                    }
                    this._optionsList[listId].push(this.createOption(text, value));
                    return b;
                };
                return SelectBox;
            }());
            FiscalSetting.SelectBox = SelectBox;
        })(FiscalSetting = AppCommon.FiscalSetting || (AppCommon.FiscalSetting = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: FiscalSettingConstantString class contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var FiscalSetting;
        (function (FiscalSetting) {
            ;
            ;
            var Notification = (function () {
                function Notification() {
                }
                Object.defineProperty(Notification, "DATARETRIEVEFAILURE", {
                    get: function () {
                        return "Unable to retrieve the data for Fiscal Setting Page";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Notification;
            }());
            FiscalSetting.Notification = Notification;
            var ENTITY = (function () {
                function ENTITY() {
                }
                Object.defineProperty(ENTITY, "ORGANIZATION", {
                    get: function () {
                        return "organization";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ENTITY;
            }());
            FiscalSetting.ENTITY = ENTITY;
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "ORGANIZATIONSETUPLBL", {
                    /*Defining all the label strings*/
                    get: function () {
                        return { id: "FY_organizationSetupLblFREAreaLabel", key: "FSOrganization" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FISCALYEARLBL", {
                    get: function () {
                        return { id: "FY_fiscalYearLblFREFieldLabel", key: "FSFiscalYear" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SETTHEFPLBL", {
                    get: function () {
                        return { id: "FY_setTheFPLblFRESectionLabel", key: "FSFiscalPeriod" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "STARTDATELBL", {
                    get: function () {
                        return { id: "FY_startDateLblFRERequiredFREFieldLabel", key: "FSStartDate" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FPTEMPLATELBL", {
                    get: function () {
                        return { id: "FY_fpTemplateFREFieldLabel", key: "FSFiscalPeriodTemplate" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DISPLAYSETTINGLBL", {
                    get: function () {
                        return { id: "FY_displaySettingLblFRESectionLabel", key: "FSDisplaySettings" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FISCALYEARSETTINGLBL", {
                    get: function () {
                        return { id: "FY_fiscalYearSettingsLblFRESubareaLabel", key: "FSFiscalYear" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PREFIXLBL", {
                    get: function () {
                        return { id: "FY_prefix1LblFREFieldLabel", key: "FSPrefix" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "YEARFROMATLBL", {
                    get: function () {
                        return { id: "FY_YearFormatLblFREFieldLabel", key: "FSYearFormat" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "POSTFIXLBL", {
                    get: function () {
                        return { id: "FY_postfixLblFREFieldLabel", key: "FSPostfix" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FISCALPERIODLBL", {
                    get: function () {
                        return { id: "FY_fiscalPeriodLblFREFieldLabel", key: "FSFiscalPeriodComboName" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "NAMEBASEDONLBL", {
                    get: function () {
                        return { id: "FY_namedBasedOnLblFREFieldLabel", key: "FSNameBasedOn" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DISPLAYASLBL", {
                    get: function () {
                        return { id: "FY_displayAsLblFREFieldLabel", key: "FSDisplayAs" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return { id: "AdvancedSettingsText", key: "AdvancedSettingsText" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return { id: "MicrosoftDynamics365Text", key: "MicrosoftDynamics365Text" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SAVEBUTTON", {
                    /*Declaring Button Strings*/
                    get: function () {
                        return { id: "FY_save", key: "FSSave" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SaveButtonToolTip", {
                    get: function () {
                        return { id: "SaveButtonToolTip", key: "SaveButtonToolTip" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FSStartDateInvalidValueAlert", {
                    get: function () {
                        return { id: "FSStartDateInvalidValueAlert", key: "FSStartDateInvalidValueAlert" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FSStartDateInvalidValueAlertwithFormat", {
                    get: function () {
                        return { id: "FSStartDateInvalidValueAlertwithFormat", key: "FSStartDateInvalidValueAlertwithFormat" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FSStartDateLeapYear", {
                    get: function () {
                        return { id: "FSStartDateLeapYear", key: "FSStartDateLeapYear" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FSStartDateMaxValueError", {
                    get: function () {
                        return { id: "FSStartDateMaxValueError", key: "FSStartDateMaxValueError" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FY_GENERIC_ERROR", {
                    get: function () {
                        return { id: "FY_GenericErrorOccurred", key: "FSGenericErrorOccurred" };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FPTEMPLATECMB", {
                    /*Declaring all the select box strings*/
                    get: function () {
                        return { id: "FY_fptemplateCmb", keys: ["FSCMBAnually", "FSCMBSemianually", "FSCMBQuarterly", "FSCMBMonthly", "FSCMB4WeekPeriod"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "FISCALPERIODCMB", {
                    get: function () {
                        return { id: "FY_fiscalPeriodCmb", keys: ["", "FSCMBPeriodQuarterOne", "FSCMBPeriodQOne", "FSCMBPeriodPOne", "FSCMBPeriodMonthOne", "FSCMBPeriodMonthMOne", "FSCMBPeriodSemesterOne", "FSCMBPeriodMonthName"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PREFIXCMB", {
                    get: function () {
                        return { id: "FY_prefixCmb", keys: ["FSCMBPrefix"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "YEARFORMATCMB", {
                    get: function () {
                        return { id: "FY_yearFormatCmb", keys: ["FSCMBYearFormatYYYY", "FSCMBYearFormatYY", "FSCMBYearFormatGGYY"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SUFFIXCMB", {
                    get: function () {
                        return { id: "FY_postfixCmb", keys: ["FSCMBPrefix", "FSFiscalYear"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "NAMEBASEDONCMB", {
                    get: function () {
                        return { id: "FY_namedBasedOnCmb", keys: ["FSCMBStartDate", "FSCMBEndDate"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DISPLAYASCMB", {
                    get: function () {
                        return { id: "FY_displayAsCmb", keys: ["FSFPSFY", "FSFPFY", "FSFPHFY", "FSFPDFY", "FSFYSFP", "FSFYFP", "FSFYHFP", "FSFYDFP"] };
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            FiscalSetting.ResourceKeys = ResourceKeys;
            var FiscalSettingString = (function () {
                function FiscalSettingString() {
                }
                Object.defineProperty(FiscalSettingString, "EMPTY", {
                    get: function () {
                        return "EMPTY";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "STARTDATECONTROL", {
                    /*Declaring start date control string*/
                    get: function () {
                        return "FY_startDateControl";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "STARTDATECONTROLDIV", {
                    /*Declaring date container strings*/
                    get: function () {
                        return "FY_startDateContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "FPTEMPLATEDIV", {
                    /*Declaring all select box container*/
                    get: function () {
                        return "fpTemplateFY_CmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "PREFIXDIV", {
                    get: function () {
                        return "prefixFY_SCmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "YEARFORMATDIV", {
                    get: function () {
                        return "yearFormatFY_SCmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "POSTFIXDIV", {
                    get: function () {
                        return "postfixFY_SCmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "FISCALPERIODCNTLDIV", {
                    get: function () {
                        return "fiscalPeriodCntlFY_CmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "SaveNotificationResourceKey", {
                    get: function () {
                        return "FSSaveNotification";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "NAMEBASEDONCNTLDIV", {
                    get: function () {
                        return "namedBasedOnCntlFY_CmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "DISPLAYASCNTLDIV", {
                    get: function () {
                        return "displayAsCntlFY_CmbContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "PREFIXPOSTFIXDIV", {
                    /*Declaring all other containers*/
                    get: function () {
                        return "FY_prefixPostfixContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "SUBSECTIONCONTAINERDIV", {
                    get: function () {
                        return "FY_subsectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "HeaderSeparatorContainerKey", {
                    get: function () {
                        return "FY_FREHeaderSeparatorContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "HeaderRightContainerKey", {
                    get: function () {
                        return "FY_FREHeaderRightContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "SaveIconContainerKey", {
                    get: function () {
                        return "FY_SaveIconContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "CRMURI", {
                    get: function () {
                        return "/api/data/v9.0";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "ORGANIZATIONURI", {
                    get: function () {
                        return "/organizations?$select=fiscalcalendarstart,fiscalperiodtype,fiscalyearformatprefix,fiscalyearformatyear,fiscalyearformatsuffix,fiscalyeardisplaycode,fiscalperiodformatperiod,fiscalyearperiodconnect";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/FiscalYear.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/FiscalYear_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(FiscalSettingString, "STARTDATECONTROLCONTAINER", {
                    get: function () {
                        return "FY_startDateControlContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                return FiscalSettingString;
            }());
            FiscalSetting.FiscalSettingString = FiscalSettingString;
        })(FiscalSetting = AppCommon.FiscalSetting || (AppCommon.FiscalSetting = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=FiscalSettingControl.js.map