/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var RelationshipSelector;
        (function (RelationshipSelector) {
            'use strict';
            var RelationshipSelectorControl = (function () {
                /**
                 * Empty constructor.
                 */
                function RelationshipSelectorControl() {
                    this.selectEntityDialogUrlPrefix = "/_forms/Template/dlg_SelectEntitiesDialog.aspx?EntityTypeCode=";
                    this.selectEntityDialogUrlSuffix = "&dType=1&HideButtons=1";
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                RelationshipSelectorControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this.height = window.top.document.body.offsetHeight; //ToDO: Assigning this statically for now, because of an issue with MDDs hosting CC while flowing height.
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                RelationshipSelectorControl.prototype.updateView = function (context) {
                    this._templateInfo = this._context.parameters.templateInfo.raw;
                    var parsedTemplateInfo = JSON.parse(this._templateInfo);
                    this.entity_otc = parsedTemplateInfo.EntityTypeCode;
                    this.relationUrl = this.selectEntityDialogUrlPrefix + this.entity_otc + this.selectEntityDialogUrlSuffix;
                    this.url = this._context.utils.createCrmUri(this.relationUrl);
                    this.RelationshipSelectionFrame = context.factory.createElement("IFRAME", {
                        id: "RelationshipSelectionFrame",
                        key: "RelationshipSelectionFrame",
                        src: this.url,
                        style: {
                            width: "100%",
                            height: this.height
                        }
                    });
                    return this.RelationshipSelectionFrame;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                RelationshipSelectorControl.prototype.getOutputs = function () {
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                RelationshipSelectorControl.prototype.destroy = function () {
                };
                return RelationshipSelectorControl;
            }());
            RelationshipSelector.RelationshipSelectorControl = RelationshipSelectorControl;
        })(RelationshipSelector = AppCommon.RelationshipSelector || (AppCommon.RelationshipSelector = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="RelationshipSelector.ts" /> 
//# sourceMappingURL=RelationshipSelector.js.map