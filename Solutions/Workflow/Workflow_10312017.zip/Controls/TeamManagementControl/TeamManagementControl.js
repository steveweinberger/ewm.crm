var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/external/TypeDefinitions/jquery.d.ts" />
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* Team management control main class.
* contains lifecycle methods for control.
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var TeamManagement;
        (function (TeamManagement) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var RetrieveUserPrivilegesRequest = ODataContract.RetrieveUserPrivilegesRequest;
            var TeamManagementControl = (function () {
                /**
                * Constructor
                */
                function TeamManagementControl() {
                    this._context = null;
                    this._freShell = null;
                    this._applyStyles = null;
                    this._refreshCounter = 0;
                    this._hasCreateTeamPermission = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                TeamManagementControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    var title = this._context.resources.getString(TeamManagement.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(TeamManagement.ResourceKeys.SubAreaText) + " - " + this._context.resources.getString(TeamManagement.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(context, title);
                    this._applyStyles = new TeamManagement.TeamManagementControlStyles(context);
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.TEAMMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "TeamManagementPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                    this.callRetrieveUserPrivilegesRequestAPI();
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                TeamManagementControl.prototype.updateView = function (context) {
                    this._context = context;
                    return this._freShell.getVirtualComponents(this.getChildControls());
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                TeamManagementControl.prototype.getChildControls = function () {
                    var params = {};
                    params["areaLabel"] = this._context.resources.getString(TeamManagement.ResourceKeys.AreaText);
                    params["subAreaLabel"] = this._context.resources.getString(TeamManagement.ResourceKeys.SubAreaText);
                    //icon content
                    params["normalIconImagePath"] = TeamManagement.Constants.HeaderNormalIconImagePath;
                    params["highContrastIconImagePath"] = TeamManagement.Constants.HeaderHighContrastIconImagePath;
                    if (this._hasCreateTeamPermission) {
                        params["headerRightContainerChild"] = this.createHeaderRightContainer();
                    }
                    /*
                    Structure of controls:
                    bodyContainer
                    |----headerContainer
                        |----headerIconContainer
                        |----headerLeftContainer
                            |----areaLabel
                            |----subAreaLabel
                        |----headerCenterContainer
                        |----headerSeparatorContainer
                        |----headerRightContainer
                            |----addTeamButton
                                |----addTeamButtonLabel
                                |----addTeamIconContainer
                    |----sectionContainer
                        |----overlayContainer
                        |----teamSectionContainer
                            |----teamGrid
                    */
                    //-----Section container-----
                    var teamSectionContainer = this.createTeamSectionContainer();
                    //-----bodyContainer-----
                    params["contentContainerChild"] = teamSectionContainer;
                    this._freShell.stopPerformanceStopWatch();
                    return params;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                TeamManagementControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                TeamManagementControl.prototype.destroy = function () {
                };
                /**
                 * Creates RightContainer for header
                 */
                TeamManagementControl.prototype.createHeaderRightContainer = function () {
                    var addTeamIconContainer = this._context.factory.createElement("CONTAINER", {
                        key: TeamManagement.Constants.AddTeamIconContainerKey, id: TeamManagement.Constants.AddTeamIconContainerKey, style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var addTeamButton = this._context.factory.createElement("BUTTON", {
                        key: TeamManagement.Constants.AddTeamButtonKey, id: TeamManagement.Constants.AddTeamButtonKey,
                        onClick: this.onAddTeamButtonClicked.bind(this),
                        title: this._context.resources.getString(TeamManagement.ResourceKeys.AddTeamButtonToolTip), tabindex: "0", style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [addTeamIconContainer, this._context.resources.getString(TeamManagement.ResourceKeys.AddTeamButtonText)]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: TeamManagement.Constants.HeaderSeparatorContainerKey, id: TeamManagement.Constants.HeaderSeparatorContainerKey, style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: TeamManagement.Constants.HeaderRightContainerKey, id: TeamManagement.Constants.HeaderRightContainerKey, style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, addTeamButton]);
                    return headerRightContainer;
                };
                /**
                 * Creates section container for Team Management page
                 */
                TeamManagementControl.prototype.createTeamSectionContainer = function () {
                    var gridProps = {
                        parameters: {
                            Grid: {
                                Type: "Grid",
                                TargetEntityType: "team",
                                ViewId: "E89C1160-4C80-4186-A7F1-5E682F17874B",
                                DataSetHostProps: {
                                    commandBarEnabled: true,
                                    jumpBarEnabled: true,
                                    quickFindEnabled: true,
                                    viewSelectorEnabled: false
                                }, RefreshInput: {
                                    Static: true,
                                    Value: this._refreshCounter
                                },
                            },
                            EnableGroupBy: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            },
                            EnableFiltering: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            },
                            EnableEditing: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            }
                        }
                    };
                    var teamGrid = this._context.factory.createComponent("MscrmControls.Grid.GridControl", "teamGrid", gridProps);
                    //Grid container
                    var teamGridContainer = this._context.factory.createElement("CONTAINER", {
                        key: TeamManagement.Constants.TeamGridContainer, id: TeamManagement.Constants.TeamGridContainer,
                        style: this._applyStyles.FREGridContainer()
                    }, [teamGrid]);
                    var teamSectionContainer = this._context.factory.createElement("CONTAINER", {
                        key: TeamManagement.Constants.SectionContainerKey, id: TeamManagement.Constants.SectionContainerKey,
                        style: this._applyStyles.FRESectionContainer()
                    }, [teamGridContainer]);
                    return teamSectionContainer;
                };
                /**
                 * onClick handler for AddTeam button
                 */
                TeamManagementControl.prototype.onAddTeamButtonClicked = function () {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.TEAMMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "AddTeamButton", TeamManagement.Constants.AddTeamButtonKey, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "AddTeam Button Clicked", false);
                    var dialogParams = {};
                    dialogParams[TeamManagement.Constants.AddTeam_MDD_SAVESUCCESS_PARAM] = "false";
                    var dialogOpt = {};
                    dialogOpt.position = TeamManagement.Constants.MDD_Dialog_Position_Right;
                    var that = this;
                    this._context.navigation.openDialog(TeamManagement.Constants.AddTeam_MDD_Name, dialogOpt, dialogParams).then(function (response) {
                        var isSaveSuccessful = response.parameters.save_success; //parameter passed by MDD if New Team was added successfully
                        if (isSaveSuccessful) {
                            that._refreshCounter = that._refreshCounter + 1;
                            var successNoticationMessage = that._context.resources.getString(TeamManagement.ResourceKeys.AddTeam_Successful_Notification);
                            that._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, successNoticationMessage, "", null).then(function (response) {
                                //Notification displayed successfully
                            }, function (error) {
                                SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.TEAMMANAGEMENT, error);
                                console.error("Error displaying notification : " + error);
                            });
                            that._context.utils.requestRender();
                        }
                        that._context.accessibility.focusElementById(TeamManagement.Constants.AddTeamButtonKey);
                    }, function (error) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.TEAMMANAGEMENT, error);
                        console.error(error);
                        that.showGenericError(that._context);
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.accessibility.focusElementById(TeamManagement.Constants.AddTeamButtonKey);
                    });
                };
                /**
                 * Shows generic error message to user
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 */
                TeamManagementControl.prototype.showGenericError = function (context) {
                    var alertMessage = {
                        text: context.resources.getString(TeamManagement.ResourceKeys.Error_GenericErrorOccurred),
                        confirmButtonLabel: context.resources.getString(TeamManagement.ResourceKeys.ConfirmButtonText)
                    };
                    context.navigation.openAlertDialog(alertMessage);
                };
                //
                TeamManagementControl.prototype.callRetrieveUserPrivilegesRequestAPI = function () {
                    var userId = this._context.userSettings.userId;
                    userId = userId.replace(/[{}]/g, '');
                    var sourceEntity = { id: userId, entityType: "systemuser" };
                    var that = this;
                    var retrieveUserPrivilegesRequest = new RetrieveUserPrivilegesRequest(sourceEntity);
                    this._context.webAPI.execute(retrieveUserPrivilegesRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                /*
                                Sample format of JSON retrived by the OData call
                                {
                                "@odata.context":"http://<machine>/<org>/api/data/v9.0/$metadata#Microsoft.Dynamics.CRM.RetrieveUserPrivilegesResponse",
                                "RolePrivileges":
                                    [
                                        {"Depth":"Global","PrivilegeId":"0011cc28-36a4-4b1c-8c25-d0c516ddb4bc","BusinessUnitId":"45fd3737-274d-e711-80ea-00155d36101c"},
                                        {"Depth":"Global","PrivilegeId":"003d8a0f-c230-411c-a993-cc0a8aeaac96","BusinessUnitId":"45fd3737-274d-e711-80ea-00155d36101c"},
                                        ...
                                    ]
                                }
                                */
                                try {
                                    if (jsonResponse) {
                                        var rolePrivileges = jsonResponse.RolePrivileges;
                                        for (var index in rolePrivileges) {
                                            var permissionObject = rolePrivileges[index];
                                            //check if user has create permission on team entity
                                            //"4807b998-6b4f-4d57-9cf6-515f50e43d79" is for prvCreateTeam permission
                                            var privilegeID = permissionObject["PrivilegeId"];
                                            if (privilegeID == "4807b998-6b4f-4d57-9cf6-515f50e43d79") {
                                                that._hasCreateTeamPermission = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                                catch (e) {
                                    that.showGenericError(that._context);
                                }
                                finally {
                                    that._context.utils.requestRender();
                                }
                            });
                        }
                    }, function (error) {
                        console.error(error);
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, error);
                        that.showGenericError(that._context);
                        that._context.utils.requestRender();
                    });
                };
                /**
                 * Checks if object is undefined or null using context utils
                 * @param object : any object
                 */
                TeamManagementControl.prototype.IsNullOrUndefined = function (object) {
                    return this._context.utils.isNullOrUndefined(object);
                };
                return TeamManagementControl;
            }());
            TeamManagement.TeamManagementControl = TeamManagementControl;
        })(TeamManagement = AppCommon.TeamManagement || (AppCommon.TeamManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="TeamManagementControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: Constants contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var TeamManagement;
        (function (TeamManagement) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                Object.defineProperty(Constants, "AreaKey", {
                    get: function () {
                        return "teamManagement_FREHeaderAreaLabelStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "SubAreaKey", {
                    get: function () {
                        return "teamManagement_FREHeaderSubareaLabelStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderLeftContainerKey", {
                    get: function () {
                        return "teamManagement_FREHeaderLeft";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderCenterContainerKey", {
                    get: function () {
                        return "teamManagement_FREHeaderCenterContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderRightContainerKey", {
                    get: function () {
                        return "teamManagement_FREHeaderRightContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AddTeamIconContainerKey", {
                    get: function () {
                        return "teamManagement_AddTeamIconContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AddTeamButtonKey", {
                    get: function () {
                        return "teamManagement_AddTeamButtonHeader_FREHeaderRightButtonStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderSeparatorContainerKey", {
                    get: function () {
                        return "teamManagement_FREHeaderSeparatorContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderContainerKey", {
                    get: function () {
                        return "teamManagement_FREHeaderContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/TeamManagement.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/TeamManagement_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "SectionContainerKey", {
                    get: function () {
                        return "teamManagement_FRESectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "BodyContainerKey", {
                    get: function () {
                        return "teamManagement_FREBodyContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "TeamGridContainer", {
                    get: function () {
                        return "teamManagement_TeamGridContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "MDD_Dialog_Position_Right", {
                    //Constants related to MDD
                    get: function () {
                        return 2;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AddTeam_MDD_Name", {
                    get: function () {
                        return "SMBAddNewTeam";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AddTeam_MDD_SAVESUCCESS_PARAM", {
                    get: function () {
                        return "save_success";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Constants;
            }());
            TeamManagement.Constants = Constants;
        })(TeamManagement = AppCommon.TeamManagement || (AppCommon.TeamManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 * Description: contains style objects needed by control
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var TeamManagement;
        (function (TeamManagement) {
            'use strict';
            var TeamManagementControlStyles = (function (_super) {
                __extends(TeamManagementControlStyles, _super);
                function TeamManagementControlStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._teamManagementSectionContainerStyle = {};
                    _this._context = context;
                    _this._teamManagementSectionContainerStyle = null;
                    return _this;
                }
                TeamManagementControlStyles.prototype.TeamManagementSectionContainerStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._teamManagementSectionContainerStyle)) {
                        this._teamManagementSectionContainerStyle = {};
                        this._teamManagementSectionContainerStyle["display"] = "flex";
                        this._teamManagementSectionContainerStyle["flex"] = "1 1 auto";
                        this._teamManagementSectionContainerStyle["overflow"] = "hidden";
                        this._teamManagementSectionContainerStyle["margin"] = this._context.theming.measures.measure075;
                    }
                    return this._teamManagementSectionContainerStyle;
                };
                return TeamManagementControlStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            TeamManagement.TeamManagementControlStyles = TeamManagementControlStyles;
        })(TeamManagement = AppCommon.TeamManagement || (AppCommon.TeamManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var TeamManagement;
        (function (TeamManagement) {
            /**
             * Class refers to the path of all the keys for localization
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "AreaText", {
                    get: function () {
                        return "AreaText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SubAreaText", {
                    get: function () {
                        return "SubAreaText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AddTeamButtonText", {
                    get: function () {
                        return "AddTeamButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AddTeamButtonToolTip", {
                    get: function () {
                        return "AddTeamButtonToolTip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AddTeam_Successful_Notification", {
                    get: function () {
                        return "AddTeam_Successful_Notification";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Error_GenericErrorOccurred", {
                    get: function () {
                        return "Error_GenericErrorOccurred";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            TeamManagement.ResourceKeys = ResourceKeys;
        })(TeamManagement = AppCommon.TeamManagement || (AppCommon.TeamManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=TeamManagementControl.js.map