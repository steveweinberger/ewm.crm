var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ClickToCallSetup;
        (function (ClickToCallSetup) {
            var AdvancedClickToCallSetupStyles = (function (_super) {
                __extends(AdvancedClickToCallSetupStyles, _super);
                function AdvancedClickToCallSetupStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._adClicktoCallSetupPage = {};
                    _this._adClicktoCallSetupAttributeServiceIcon = {};
                    _this._adClicktoCallSetupAttributeServiceStatus = {};
                    _this._adClicktoCallSetupAttributeServiceName = {};
                    _this._adClicktoCallSetupAttributeService = {};
                    _this._adClicktoCallSetupAttributeServiceList = {};
                    _this._adClicktoCallSetupAttributeNoteLabel = {};
                    _this._adClicktoCallSetupAttributeNoteMessage = {};
                    _this._adClicktoCallSetupAttributeNote = {};
                    _this._adClicktoCallSetupAttributeStatusIcon = {};
                    _this._adClicktoCallSetupAttributeStatusMessage = {};
                    _this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked = {};
                    _this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked = {};
                    _this._adClicktoCallSetupAttributeIMPresenceLabel = {};
                    _this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer = {};
                    _this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel = {};
                    _this._adClicktoCallSetupAttributeActivateDeactivateButton = {};
                    _this._adClicktoCallSetupSectionBody = {};
                    _this._adClicktoCallSetupContentContainerStyle = {};
                    _this._adClicktoCallSetupGetExchangeServiceIcon = {};
                    _this._adClicktoCallSetupReadMoreLink = {};
                    _this._context = context;
                    _this._adClicktoCallSetupPage = null;
                    _this._adClicktoCallSetupAttributeServiceIcon = null;
                    _this._adClicktoCallSetupAttributeServiceStatus = null;
                    _this._adClicktoCallSetupAttributeServiceName = null;
                    _this._adClicktoCallSetupAttributeService = null;
                    _this._adClicktoCallSetupAttributeServiceList = null;
                    _this._adClicktoCallSetupAttributeNoteLabel = null;
                    _this._adClicktoCallSetupAttributeNoteMessage = null;
                    _this._adClicktoCallSetupAttributeNote = null;
                    _this._adClicktoCallSetupAttributeStatusIcon = null;
                    _this._adClicktoCallSetupAttributeStatusMessage = null;
                    _this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked = null;
                    _this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked = null;
                    _this._adClicktoCallSetupAttributeIMPresenceLabel = null;
                    _this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer = null;
                    _this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel = null;
                    _this._adClicktoCallSetupAttributeActivateDeactivateButton = null;
                    _this._adClicktoCallSetupSectionBody = null;
                    _this._adClicktoCallSetupGetExchangeServiceIcon = null;
                    _this._adClicktoCallSetupReadMoreLink = null;
                    return _this;
                }
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupPage = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupPage)) {
                        this._adClicktoCallSetupPage = {};
                        this._adClicktoCallSetupPage["flexDirection"] = "column";
                        this._adClicktoCallSetupPage["justifyContent"] = "flexStart";
                        this._adClicktoCallSetupPage["backgroundColor"] = this._context.theming.colors.basecolor.white;
                        this._adClicktoCallSetupPage["flex"] = "1 1 auto";
                        this._adClicktoCallSetupPage["width"] = "100%";
                    }
                    return this._adClicktoCallSetupPage;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeServiceIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeServiceIcon)) {
                        this._adClicktoCallSetupAttributeServiceIcon = {};
                        this._adClicktoCallSetupAttributeServiceIcon["height"] = "32px";
                        this._adClicktoCallSetupAttributeServiceIcon["width"] = "32px";
                        this._adClicktoCallSetupAttributeServiceIcon["marginRight"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupAttributeServiceIcon["marginLeft"] = this._context.theming.measures.measure075;
                    }
                    return this._adClicktoCallSetupAttributeServiceIcon;
                };
                /**
                * Style for small icon in Tab Container
                */
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeServiceStatus = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeServiceStatus)) {
                        this._adClicktoCallSetupAttributeServiceStatus = {};
                        this._adClicktoCallSetupAttributeServiceStatus["height"] = this._context.theming.measures.measure100;
                        this._adClicktoCallSetupAttributeServiceStatus["width"] = this._context.theming.measures.measure100;
                        this._adClicktoCallSetupAttributeServiceStatus["marginLeft"] = this._context.theming.measures.measure075;
                    }
                    return this._adClicktoCallSetupAttributeServiceStatus;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeServiceList = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeServiceList)) {
                        this._adClicktoCallSetupAttributeServiceList = {};
                        this._adClicktoCallSetupAttributeServiceList["width"] = "100%";
                        this._adClicktoCallSetupAttributeServiceList["height"] = this._context.theming.measures.measure550;
                        this._adClicktoCallSetupAttributeServiceList["marginBottom"] = this._context.theming.measures.measure050;
                    }
                    return this._adClicktoCallSetupAttributeServiceList;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeNoteLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeNoteLabel)) {
                        this._adClicktoCallSetupAttributeNoteLabel = {};
                        this._adClicktoCallSetupAttributeNoteLabel["margin"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupAttributeNoteLabel["display"] = "inline-block";
                    }
                    return this._adClicktoCallSetupAttributeNoteLabel;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeNoteMessage = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeNoteMessage)) {
                        this._adClicktoCallSetupAttributeNoteMessage = {};
                        this._adClicktoCallSetupAttributeNoteMessage["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._adClicktoCallSetupAttributeNoteMessage["fontSize"] = this._context.theming.fontsizes.font100;
                        this._adClicktoCallSetupAttributeNoteMessage["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._adClicktoCallSetupAttributeNoteMessage;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeNote = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeNote)) {
                        this._adClicktoCallSetupAttributeNote = {};
                        this._adClicktoCallSetupAttributeNote["border"] = this._context.theming.borders.border02;
                        this._adClicktoCallSetupAttributeNote["opacity"] = "0.89";
                        this._adClicktoCallSetupAttributeNote["marginTop"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupAttributeNote["marginLeft"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupAttributeNote["marginRight"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupAttributeNote["flexDirection"] = "column";
                        this._adClicktoCallSetupAttributeNote["display"] = "inline-block";
                    }
                    return this._adClicktoCallSetupAttributeNote;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeStatusIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeStatusIcon)) {
                        this._adClicktoCallSetupAttributeStatusIcon = {};
                        this._adClicktoCallSetupAttributeStatusIcon["display"] = "flex";
                        this._adClicktoCallSetupAttributeStatusIcon["marginTop"] = "8.7rem";
                        this._adClicktoCallSetupAttributeStatusIcon["marginLeft"] = "33.9rem";
                        this._adClicktoCallSetupAttributeStatusIcon["marginRight"] = "33.9rem";
                        this._adClicktoCallSetupAttributeStatusIcon["height"] = "4.6rem";
                        this._adClicktoCallSetupAttributeStatusIcon["width"] = "4.6rem";
                        this._adClicktoCallSetupAttributeStatusIcon["alignSelf"] = "center";
                    }
                    return this._adClicktoCallSetupAttributeStatusIcon;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeStatusMessage = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeStatusMessage)) {
                        this._adClicktoCallSetupAttributeStatusMessage = {};
                        this._adClicktoCallSetupAttributeStatusMessage["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._adClicktoCallSetupAttributeStatusMessage["fontSize"] = this._context.theming.fontsizes.font100;
                        this._adClicktoCallSetupAttributeStatusMessage["marginTop"] = this._context.theming.measures.measure150;
                        this._adClicktoCallSetupAttributeStatusMessage["alignSelf"] = "center";
                        this._adClicktoCallSetupAttributeStatusMessage["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._adClicktoCallSetupAttributeStatusMessage;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeIMPresenceCheckBoxChecked = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked)) {
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked = {};
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked["borderRadius"] = "3px";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked["marginLeft"] = "0.7rem";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked["marginRight"] = "0.7rem";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked["width"] = "1.1rem";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked["height"] = "1.1rem";
                    }
                    return this._adClicktoCallSetupAttributeIMPresenceCheckBoxChecked;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked)) {
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked = {};
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked["borderRadius"] = "3px";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked["backgroundColor"] = "#0063B1";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked["marginLeft"] = "0.7rem";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked["marginRight"] = "0.7rem";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked["width"] = "1.1rem";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked["height"] = "1.1rem";
                    }
                    return this._adClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeIMPresenceLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeIMPresenceLabel)) {
                        this._adClicktoCallSetupAttributeIMPresenceLabel = {};
                        this._adClicktoCallSetupAttributeIMPresenceLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._adClicktoCallSetupAttributeIMPresenceLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._adClicktoCallSetupAttributeIMPresenceLabel["color"] = "#4A4A4A";
                    }
                    return this._adClicktoCallSetupAttributeIMPresenceLabel;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeIMPresenceCheckBoxContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer)) {
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer = {};
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer["alignSelf"] = "center";
                        this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer["marginTop"] = this._context.theming.measures.measure075;
                    }
                    return this._adClicktoCallSetupAttributeIMPresenceCheckBoxContainer;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeActivateDeactivateButtonLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel)) {
                        this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel = {};
                        this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel["color"] = this._context.theming.colors.basecolor.white;
                        this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel["marginRight"] = this._context.theming.measures.measure150;
                        this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel["marginLeft"] = this._context.theming.measures.measure150;
                    }
                    return this._adClicktoCallSetupAttributeActivateDeactivateButtonLabel;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupAttributeActivateDeactivateButton = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupAttributeActivateDeactivateButton)) {
                        this._adClicktoCallSetupAttributeActivateDeactivateButton = {};
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["backgroundColor"] = "#0063B1";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["height"] = "30px";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["marginTop"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["justifyContent"] = "center";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["alignSelf"] = "center";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["alignItems"] = "center";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["borderStyle"] = "solid";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["borderWidth"] = "1px";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["borderColor"] = "#0063B1";
                        this._adClicktoCallSetupAttributeActivateDeactivateButton["shadow"] = "none";
                    }
                    return this._adClicktoCallSetupAttributeActivateDeactivateButton;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupSectionBody = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupSectionBody)) {
                        this._adClicktoCallSetupSectionBody = {};
                        this._adClicktoCallSetupSectionBody["marginLeft"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupSectionBody["marginRight"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupSectionBody["marginTop"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupSectionBody["marginBottom"] = this._context.theming.measures.measure075;
                        this._adClicktoCallSetupSectionBody["borderWidth"] = "1px";
                        this._adClicktoCallSetupSectionBody["borderColor"] = this._context.theming.colors.basecolor.grey.grey2;
                        this._adClicktoCallSetupSectionBody["borderStyle"] = "solid";
                        this._adClicktoCallSetupSectionBody["flexGrow"] = "1";
                        this._adClicktoCallSetupSectionBody["flexShrink"] = "1";
                        this._adClicktoCallSetupSectionBody["flexBasis"] = "auto";
                        this._adClicktoCallSetupSectionBody["position"] = "relative";
                        this._adClicktoCallSetupSectionBody["flexDirection"] = "column";
                    }
                    return this._adClicktoCallSetupSectionBody;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupContentContainerStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupContentContainerStyle)) {
                        this._adClicktoCallSetupContentContainerStyle = {};
                        this._adClicktoCallSetupContentContainerStyle["height"] = "100%";
                    }
                    return this._adClicktoCallSetupContentContainerStyle;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupGetExchangeServiceIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupGetExchangeServiceIcon)) {
                        this._adClicktoCallSetupGetExchangeServiceIcon = {};
                        this._adClicktoCallSetupGetExchangeServiceIcon["height"] = "16px";
                    }
                    return this._adClicktoCallSetupGetExchangeServiceIcon;
                };
                AdvancedClickToCallSetupStyles.prototype.AdClicktoCallSetupReadMoreLink = function () {
                    if (this._context.utils.isNullOrUndefined(this._adClicktoCallSetupReadMoreLink)) {
                        this._adClicktoCallSetupReadMoreLink = {};
                        this._adClicktoCallSetupReadMoreLink["color"] = "#0063B1";
                        this._adClicktoCallSetupReadMoreLink["marginLeft"] = "5px";
                    }
                    return this._adClicktoCallSetupReadMoreLink;
                };
                return AdvancedClickToCallSetupStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            ClickToCallSetup.AdvancedClickToCallSetupStyles = AdvancedClickToCallSetupStyles;
        })(ClickToCallSetup = AppCommon.ClickToCallSetup || (AppCommon.ClickToCallSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ClickToCallSetup;
        (function (ClickToCallSetup) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var AdvancedClickToCallSetup = (function () {
                /**
                 * Empty constructor.
                 */
                function AdvancedClickToCallSetup() {
                    /**
                     * Event Handlers for this custom control
                     */
                    this.onClickSkypeForBusinessServiceHandler = function () {
                        this._view = ViewType.SkypeForBusinessView;
                        this._context.utils.requestRender();
                    };
                    this.onClickSkypeServiceHandler = function () {
                        this._view = ViewType.SkypeView;
                        this._context.utils.requestRender();
                    };
                    this.onKeyDownSkypeForBusinessServiceHandler = function () {
                        if (!((event).shiftKey || (event).ctrlKey || (event).altKey)) {
                            // If arrow is pressed, move the focus between services
                            // Left: 37, Up: 38, Right: 39, Down:40
                            if ((event).keyCode == 39) {
                                event.preventDefault();
                                this._context.accessibility.focusElementById(AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ID_SEED);
                                this._view = ViewType.SkypeView;
                                this._context.utils.requestRender();
                            }
                            // If tab is pressed move to Read More hyperlink of the Note section
                            if ((event).keyCode == 9) {
                                event.preventDefault();
                                this._context.accessibility.focusElementById(AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_HYPERLINK_ID_SEED);
                            }
                        }
                    };
                    this.onKeyDownSkypeServiceHandler = function () {
                        if (!((event).shiftKey || (event).ctrlKey || (event).altKey)) {
                            // If arrow is pressed, move the focus between services
                            // Left: 37, Up: 38, Right: 39, Down:40
                            if ((event).keyCode == 37) {
                                event.preventDefault();
                                this._context.accessibility.focusElementById(AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ID_SEED);
                                this._view = ViewType.SkypeForBusinessView;
                                this._context.utils.requestRender();
                            }
                            // If tab is pressed move to Read More hyperlink of the Note section
                            if ((event).keyCode == 9) {
                                event.preventDefault();
                                this._context.accessibility.focusElementById(AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_HYPERLINK_ID_SEED);
                            }
                        }
                    };
                    this.onClickIMPresence = function () {
                        var that = this;
                        this._imPresenceFlag = !this._imPresenceFlag;
                        $.ajax({
                            type: "PATCH",
                            url: this._context.utils.createCrmUri("/api/data/v9.0/organizations(" + this._organizationId + ")"),
                            data: '{ "ispresenceenabled": ' + this._imPresenceFlag + '}',
                            success: function (data) {
                            },
                            contentType: "application/json",
                            dataType: "application/json"
                        });
                    };
                    this.onClickServiceActivationHandler = function () {
                        var that = this;
                        this._isLoading = true;
                        if (this._view == ViewType.SkypeForBusinessView) {
                            that._defaultSkypeForBusiness = true;
                        }
                        if (this._view == ViewType.SkypeView) {
                            that._defaultSkypeForBusiness = false;
                        }
                        $.ajax({
                            type: "PATCH",
                            url: this._context.utils.createCrmUri("/api/data/v8.2/organizations(" + this._organizationId + ")"),
                            data: '{ "useskypeprotocol": ' + !this._defaultSkypeForBusiness + '}',
                            success: function (data) {
                                that._isLoading = false;
                                that._context.utils.requestRender();
                            },
                            contentType: "application/json",
                            dataType: "application/json"
                        });
                        this._context.utils.requestRender();
                    };
                    this._view = ViewType.SkypeForBusinessView;
                    this._applyStyles = null;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                AdvancedClickToCallSetup.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._imPresenceFlag = false;
                    this._defaultSkypeForBusiness = false;
                    this._isLoading = true;
                    this._activeTab = 1;
                    var that = this;
                    var title = this._context.resources.getString(ClickToCallSetup.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(ClickToCallSetup.ResourceKeys.ClickToCall) + " - " + this._context.resources.getString(ClickToCallSetup.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(context, title);
                    this._applyStyles = new ClickToCallSetup.AdvancedClickToCallSetupStyles(context);
                    $.getJSON(this._context.utils.createCrmUri("/api/data/v9.0/organizations?$select=useskypeprotocol,ispresenceenabled"))
                        .done(function (data) {
                        that._defaultSkypeForBusiness = !data.value[0].useskypeprotocol;
                        that._imPresenceFlag = data.value[0].ispresenceenabled;
                        that._isLoading = false;
                        that._organizationId = data.value[0].organizationid;
                        that._context.utils.requestRender();
                    });
                    // All jQuery ajax calls will be converted to xRM webAPI calls.
                    // this._context.webAPI.updateRecord("organizations", "9ec0f23d-d2c2-41d3-a881-ed1efdc480d5", { "useskypeprotocol": true });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * The structure of components in the control:
                 * bodyContainer
                 * |----headerContainer
                 *          |----headerIconContainer
                 *          |----headerTextContainer
                 *                      |----GroupLabel
                 *                      |----HeaderLabel
                 *          |----listingContainer
                 *                     |----ServiceIcon
                 *                     |----ServiceLabel
                 *                     |----ServiceStatusIcon
                 *          |----bodyContainer
                 *                     |----noteContainer
                 *                     |----statusIconContainer
                 *                     |----statusContainer
                 *                     |----IMContainer
                 *
                 * @params context The "Input Bag" as described above
                 */
                AdvancedClickToCallSetup.prototype.updateView = function (context) {
                    this._context = context;
                    return this._freShell.getVirtualComponents(this.getChildControls());
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                AdvancedClickToCallSetup.prototype.getChildControls = function () {
                    var params = {};
                    params.areaLabel = this._context.resources.getString(ClickToCallSetup.ResourceKeys.CommunicationCollaboration);
                    params.subAreaLabel = this._context.resources.getString(ClickToCallSetup.ResourceKeys.ClickToCall);
                    //icon content
                    params.normalIconImagePath = ClickToCallSetup.ResourcePath.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = ClickToCallSetup.ResourcePath.HeaderHighContrastIconImagePath;
                    var containerList = [];
                    if (!this._isLoading) {
                        containerList.push(this._containerAttrServiceList());
                        containerList.push(this._containerBody());
                        this._freShell.stopPerformanceStopWatch();
                    }
                    params.contentContainerChild = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ADVANCE_CLICKTOCALL_ID_SEED,
                        key: AdvancedClickToCallSetup.ADVANCE_CLICKTOCALL_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupPage()
                    }, containerList);
                    return params;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                AdvancedClickToCallSetup.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                AdvancedClickToCallSetup.prototype.destroy = function () {
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeForBusinessIcon = function () {
                    var s4Business = this._context.factory.createElement("IMG", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ICON_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ICON_ID_SEED,
                        source: this._getSkypeForBussinessIconPath(),
                        altText: this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype4Business),
                        style: this._applyStyles.AdClicktoCallSetupAttributeServiceIcon()
                    }, []);
                    return s4Business;
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeForBusinessName = function () {
                    var service = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_NAME_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_NAME_ID_SEED,
                        style: this._applyStyles.FRETabContainerNameStyle()
                    }, this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype4Business));
                    return service;
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeForBusinessStatus = function () {
                    var statusIcon = this._context.factory.createElement("IMG", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_STATUS_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_STATUS_ID_SEED,
                        source: this._getSuccessIconPath(),
                        altText: this._context.resources.getString(ClickToCallSetup.ResourceKeys.SuccessMessageText),
                        style: this._applyStyles.AdClicktoCallSetupAttributeServiceStatus()
                    });
                    return statusIcon;
                };
                /**
                 * Returns the Success Icon Path for skype for business based on High Contrast Settings
                 */
                AdvancedClickToCallSetup.prototype._getSuccessIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return ClickToCallSetup.ResourcePath.SuccessIconHC;
                    }
                    else {
                        return ClickToCallSetup.ResourcePath.SuccessIcon;
                    }
                };
                /**
                 * Returns the Icon Path for Exchange based on High Contrast Settings
                 */
                AdvancedClickToCallSetup.prototype._getSkypeForBussinessIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return ClickToCallSetup.ResourcePath.SkypeForBusinessIconHC;
                    }
                    else {
                        return ClickToCallSetup.ResourcePath.SkypeForBusinessIcon;
                    }
                };
                /**
                 * Returns the Icon Path for Exchange based on High Contrast Settings
                 */
                AdvancedClickToCallSetup.prototype._getSkypeIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return ClickToCallSetup.ResourcePath.SkypeIconHC;
                    }
                    else {
                        return ClickToCallSetup.ResourcePath.SkypeIcon;
                    }
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeForBusiness = function () {
                    var s4BusinessList = [];
                    s4BusinessList.push(this._containerAttrServiceSkypeForBusinessIcon());
                    s4BusinessList.push(this._containerAttrServiceSkypeForBusinessName());
                    if (this._defaultSkypeForBusiness)
                        s4BusinessList.push(this._containerAttrServiceSkypeForBusinessStatus());
                    var skypeForeBusinessService = this._context.factory.createElement("BUTTON", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ID_SEED,
                        style: (this._view == ViewType.SkypeForBusinessView) ? this._applyStyles.FRETabContainerStyle() : this._applyStyles.FREContainerStyleForNonSelectedTab(),
                        tabIndex: 0,
                        role: "tab",
                        onClick: this.onClickSkypeForBusinessServiceHandler.bind(this),
                        onKeyDown: this.onKeyDownSkypeForBusinessServiceHandler.bind(this)
                    }, s4BusinessList);
                    return skypeForeBusinessService;
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeIcon = function () {
                    var skype = this._context.factory.createElement("IMG", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ICON_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ICON_ID_SEED,
                        source: this._getSkypeIconPath(),
                        altText: this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype),
                        style: this._applyStyles.AdClicktoCallSetupAttributeServiceIcon()
                    }, []);
                    return skype;
                };
                AdvancedClickToCallSetup.prototype._setActiveTab = function (activeTab) {
                    this._activeTab = activeTab;
                };
                AdvancedClickToCallSetup.prototype._getTabIndex = function (tabNumber) {
                    if (this._activeTab == tabNumber) {
                        return "0";
                    }
                    return "-1";
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeName = function () {
                    var service = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_NAME_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_NAME_ID_SEED,
                        style: this._applyStyles.FRETabContainerNameStyle()
                    }, this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype));
                    return service;
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkypeStatus = function () {
                    var statusIcon = this._context.factory.createElement("IMG", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_STATUS_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_STATUS_ID_SEED,
                        source: ClickToCallSetup.ResourcePath.SuccessIcon,
                        altText: this._context.resources.getString(ClickToCallSetup.ResourceKeys.SuccessMessageText),
                        style: this._applyStyles.AdClicktoCallSetupAttributeServiceStatus()
                    });
                    return statusIcon;
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceSkype = function () {
                    var skypeList = [];
                    skypeList.push(this._containerAttrServiceSkypeIcon());
                    skypeList.push(this._containerAttrServiceSkypeName());
                    if (!this._defaultSkypeForBusiness)
                        skypeList.push(this._containerAttrServiceSkypeStatus());
                    var skypeService = this._context.factory.createElement("BUTTON", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ID_SEED,
                        style: (this._view == ViewType.SkypeView) ? this._applyStyles.FRETabContainerStyle() : this._applyStyles.FREContainerStyleForNonSelectedTab(),
                        tabIndex: 0,
                        role: "tab",
                        onClick: this.onClickSkypeServiceHandler.bind(this),
                        onKeyDown: this.onKeyDownSkypeServiceHandler.bind(this)
                    }, skypeList);
                    return skypeService;
                };
                AdvancedClickToCallSetup.prototype._containerAttrServiceList = function () {
                    var servicelist = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ATTR_SERVICES_LIST_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_SERVICES_LIST_ID_SEED,
                        role: "tablist",
                        style: this._applyStyles.AdClicktoCallSetupAttributeServiceList()
                    }, [this._containerAttrServiceSkypeForBusiness(), this._containerAttrServiceSkype()]);
                    return servicelist;
                };
                AdvancedClickToCallSetup.prototype._containerAttrBodyNoteMessage = function () {
                    var text = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_NOTE_MESSAGE_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_NOTE_MESSAGE_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeNoteMessage()
                    }, this.getResourceNote());
                    var readMore = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_TEXT_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_TEXT_ID_SEED,
                        style: {}
                    }, this._context.resources.getString(ClickToCallSetup.ResourceKeys.ReadMoreText));
                    var link = this._context.factory.createElement("HYPERLINK", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_HYPERLINK_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_HYPERLINK_ID_SEED,
                        tabIndex: 0,
                        href: "https://go.microsoft.com/fwlink/p/?linkid=842889",
                        target: "_blank",
                        accessibilityLabel: this.ReadMoreLinkText(),
                        style: this._applyStyles.AdClicktoCallSetupReadMoreLink()
                    }, readMore);
                    var note = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeNoteLabel()
                    }, [text, link]);
                    return note;
                };
                AdvancedClickToCallSetup.prototype._containerAttrBodyNote = function () {
                    var noteContainer = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_NOTE_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_NOTE_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeNote()
                    }, [this._containerAttrBodyNoteMessage()]);
                    return noteContainer;
                };
                AdvancedClickToCallSetup.prototype._containerAttrBodyStatusIcon = function () {
                    var enableContainer = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_STATUS_ICON_ENABLE_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_STATUS_ICON_ENABLE_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeStatusIcon()
                    }, []);
                    var disableContainer = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_STATUS_ICON_DISABLE_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_STATUS_ICON_DISABLE_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeStatusIcon()
                    }, []);
                    var statusContainer = disableContainer;
                    if ((this._view == ViewType.SkypeForBusinessView && this._defaultSkypeForBusiness)
                        || (this._view == ViewType.SkypeView && !this._defaultSkypeForBusiness))
                        statusContainer = enableContainer;
                    return statusContainer;
                };
                AdvancedClickToCallSetup.prototype._containerAttrBodyStatusMessage = function () {
                    var statusMessage = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_STATUS_MESSAGE_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_STATUS_MESSAGE_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeStatusMessage()
                    }, this.getResourceStatusMessage());
                    return statusMessage;
                };
                AdvancedClickToCallSetup.prototype._containerAttrBodyIMCheckBox = function () {
                    var imCheckBox = this._context.factory.createElement("BOOLEAN", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CHECKBOX_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CHECKBOX_ID_SEED,
                        type: "checkbox",
                        tagname: "INPUT",
                        value: this._imPresenceFlag,
                        tabIndex: 0,
                        onValueChange: this.onClickIMPresence.bind(this),
                        style: this._imPresenceFlag
                            ? this._applyStyles.AdClicktoCallSetupAttributeIMPresenceCheckBoxChecked() : this._applyStyles.AdClicktoCallSetupAttributeIMPresenceCheckBoxUnchecked()
                    });
                    var imLabel = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_LABEL_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_LABEL_ID_SEED,
                        forElementId: this._context.accessibility.getUniqueId(AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CHECKBOX_ID_SEED),
                        style: this._applyStyles.AdClicktoCallSetupAttributeIMPresenceLabel()
                    }, this._context.resources.getString(ClickToCallSetup.ResourceKeys.IMPresence));
                    var imCheckContainer = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CONTAINER_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CONTAINER_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeIMPresenceCheckBoxContainer()
                    }, [imCheckBox, imLabel]);
                    return imCheckContainer;
                };
                AdvancedClickToCallSetup.prototype._containerAttrBodyServiceEnableButton = function () {
                    var buttonText = this._context.factory.createElement("LABEL", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_ENABLE_BUTTON_TEXT_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_ENABLE_BUTTON_TEXT_ID_SEED,
                        style: this._applyStyles.AdClicktoCallSetupAttributeActivateDeactivateButtonLabel()
                    }, this._context.resources.getString(ClickToCallSetup.ResourceKeys.Enable));
                    var enableButton = this._context.factory.createElement("BUTTON", {
                        id: AdvancedClickToCallSetup.ATTR_BODY_ENABLE_BUTTON_ID_SEED,
                        key: AdvancedClickToCallSetup.ATTR_BODY_ENABLE_BUTTON_ID_SEED,
                        tabIndex: 0,
                        onClick: this.onClickServiceActivationHandler.bind(this),
                        style: this._applyStyles.AdClicktoCallSetupAttributeActivateDeactivateButton()
                    }, [buttonText]);
                    return enableButton;
                };
                AdvancedClickToCallSetup.prototype._containerBody = function () {
                    var childComponents = [this._containerAttrBodyNote(), this._containerAttrBodyStatusIcon(), this._containerAttrBodyStatusMessage()];
                    if ((this._view == ViewType.SkypeView && this._defaultSkypeForBusiness)
                        || (this._view == ViewType.SkypeForBusinessView && !this._defaultSkypeForBusiness)) {
                        childComponents.push(this._containerAttrBodyServiceEnableButton());
                    }
                    if (this._view == ViewType.SkypeForBusinessView && this._defaultSkypeForBusiness)
                        childComponents.push(this._containerAttrBodyIMCheckBox());
                    var body = null;
                    if (this._view == ViewType.SkypeForBusinessView) {
                        if (this._context.userSettings.isRTL) {
                            body = this._context.factory.createElement("CONTAINER", {
                                id: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_RTL_ID_SEED_ONE,
                                key: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_RTL_ID_SEED_ONE,
                                role: "tabpanel",
                                style: this._applyStyles.AdClicktoCallSetupSectionBody()
                            }, childComponents);
                        }
                        else {
                            body = this._context.factory.createElement("CONTAINER", {
                                id: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_ID_SEED_ONE,
                                key: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_ID_SEED_ONE,
                                role: "tabpanel",
                                style: this._applyStyles.AdClicktoCallSetupSectionBody()
                            }, childComponents);
                        }
                    }
                    else {
                        if (this._context.userSettings.isRTL) {
                            body = this._context.factory.createElement("CONTAINER", {
                                id: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_RTL_ID_SEED_TWO,
                                key: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_RTL_ID_SEED_TWO,
                                role: "tabpanel",
                                style: this._applyStyles.AdClicktoCallSetupSectionBody()
                            }, childComponents);
                        }
                        else {
                            body = this._context.factory.createElement("CONTAINER", {
                                id: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_ID_SEED_TWO,
                                key: AdvancedClickToCallSetup.ATTR_BODY_DETAILS_ID_SEED_TWO,
                                role: "tabpanel",
                                style: this._applyStyles.AdClicktoCallSetupSectionBody()
                            }, childComponents);
                        }
                    }
                    return body;
                };
                AdvancedClickToCallSetup.prototype.getResourceNote = function () {
                    var message = "";
                    if (this._view == ViewType.SkypeForBusinessView) {
                        if (this._defaultSkypeForBusiness) {
                            message = this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype4BusinessEnabledToolTip);
                        }
                        else {
                            message = this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype4BusinessTooltip);
                        }
                    }
                    else if (this._view == ViewType.SkypeView) {
                        if (!this._defaultSkypeForBusiness) {
                            message = this._context.resources.getString(ClickToCallSetup.ResourceKeys.SkypeEnabledToolTip);
                        }
                        else {
                            message = this._context.resources.getString(ClickToCallSetup.ResourceKeys.SkypeToolTip);
                        }
                    }
                    return message;
                };
                AdvancedClickToCallSetup.prototype.getResourceStatusMessage = function () {
                    if (this._view == ViewType.SkypeForBusinessView && this._defaultSkypeForBusiness)
                        return this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype4BusinessEnabledText);
                    if (this._view == ViewType.SkypeForBusinessView && !this._defaultSkypeForBusiness)
                        return this._context.resources.getString(ClickToCallSetup.ResourceKeys.Skype4BusinessDisabledText);
                    if (this._view == ViewType.SkypeView && !this._defaultSkypeForBusiness)
                        return this._context.resources.getString(ClickToCallSetup.ResourceKeys.SkypeEnabledText);
                    return this._context.resources.getString(ClickToCallSetup.ResourceKeys.SkypeDisabledText);
                };
                AdvancedClickToCallSetup.prototype.ReadMoreLinkText = function () {
                    var readMoreLinkText = "";
                    if (this._view == ViewType.SkypeView) {
                        readMoreLinkText = this._context.resources.getString(ClickToCallSetup.ResourceKeys.ReadMoreTextForSkype);
                    }
                    if (this._view == ViewType.SkypeForBusinessView) {
                        readMoreLinkText = this._context.resources.getString(ClickToCallSetup.ResourceKeys.ReadMoreTextForSkype4Business);
                    }
                    return readMoreLinkText;
                };
                return AdvancedClickToCallSetup;
            }());
            /**
            * Seed string for page.
            **/
            AdvancedClickToCallSetup.ADVANCE_CLICKTOCALL_ID_SEED = "advanced_clicktocall";
            /**
            * Seed string for page.
            **/
            AdvancedClickToCallSetup.ADVANCE_CLICKTOCALL_LOADING_SCREEN_ID_SEED = "clicktocall-loading";
            /**
            * Seed string for header section.
            **/
            AdvancedClickToCallSetup.ADVANCED_CLICKTOCALL_SECTION_HEADER_ID_SEED = "clicktocall.section-header";
            /**
            * Seed string for text sections in headers.
            **/
            AdvancedClickToCallSetup.ADVANCED_CLICKTOCALL_SECTION_HEADER_TEXT_ID_SEED = "clicktocall.header-text";
            /**
            * Seed string for group name in header.
            **/
            AdvancedClickToCallSetup.ADVANCED_CLICKTOCALL_SECTION_HEADER_TEXT_GROUP_ID_SEED = "clicktocall.header-group";
            /**
            * Seed string for page name in header.
            **/
            AdvancedClickToCallSetup.ADVANCED_CLICKTOCALL_SECTION_HEADER_TEXT_NAME_ID_SEED = "clicktocall.header-name";
            /**
            * Seed string for body section.
            **/
            AdvancedClickToCallSetup.ADVANCED_CLICKTOCALL_SECTION_BODY_ID_SEED = "clicktocall.section-body";
            /**
            * Seed string for body attribute: List of email service providers.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LIST_ID_SEED = "clicktocall.body-listing";
            /**
            * Seed string for body attribute: Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ID_SEED = "clicktocall.body.listing-skype";
            /**
            * Seed string for bosy attribute: Icon of Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_ICON_ID_SEED = "clicktocall.body.listing.skype-icon";
            /**
            * Seed string for bosy attribute: Name of Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_NAME_ID_SEED = "clicktocall.body.listing.skype-name";
            /**
            * Seed string for bosy attribute: Status of the Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_STATUS_ID_SEED = "clicktocall.body.listing.skype-status";
            /**
            * Seed string for body attribute: Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ID_SEED = "clicktocall.body.listing-s4business";
            /**
            * Seed string for bosy attribute: Icon of Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_ICON_ID_SEED = "clicktocall.body.listing.s4business-icon";
            /**
            * Seed string for bosy attribute: Name of Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_NAME_ID_SEED = "clicktocall.body.listing.s4business-name";
            /**
            * Seed string for bosy attribute: Status of the Email Provider Service.
            **/
            AdvancedClickToCallSetup.ATTR_SERVICES_LISTING_SERVICE_SKYPE_BUSINESS_STATUS_ID_SEED = "clicktocall.body.listing.s4business-status";
            AdvancedClickToCallSetup.ATTR_BODY_DETAILS_ID_SEED_ONE = "body-details1";
            AdvancedClickToCallSetup.ATTR_BODY_DETAILS_ID_SEED_TWO = "body-details2";
            AdvancedClickToCallSetup.ATTR_BODY_DETAILS_RTL_ID_SEED_ONE = "body-rtl-details1";
            AdvancedClickToCallSetup.ATTR_BODY_DETAILS_RTL_ID_SEED_TWO = "body-rtl-details2";
            AdvancedClickToCallSetup.ATTR_BODY_NOTE_ID_SEED = "clicktocall.body.details-note";
            AdvancedClickToCallSetup.ATTR_BODY_NOTE_LABEL_ID_SEED = "clicktocall.body.details.note-label";
            AdvancedClickToCallSetup.ATTR_BODY_NOTE_MESSAGE_ID_SEED = "clicktocall.body.details.note-message";
            AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_ID_SEED = "clicktocall.body.details.note-link";
            AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_TEXT_ID_SEED = "clicktocall.body.details.note.link-text";
            AdvancedClickToCallSetup.ATTR_BODY_NOTE_LINK_HYPERLINK_ID_SEED = "clicktocall.body.details.note.link-hyperlink";
            AdvancedClickToCallSetup.ATTR_BODY_STATUS_ICON_ENABLE_ID_SEED = "clicktocall-body-details-enable-icon";
            AdvancedClickToCallSetup.ATTR_BODY_STATUS_ICON_DISABLE_ID_SEED = "clicktocall-body-details-disable-icon";
            AdvancedClickToCallSetup.ATTR_BODY_STATUS_MESSAGE_ID_SEED = "clicktocall.body.details-message";
            AdvancedClickToCallSetup.ATTR_BODY_ENABLE_BUTTON_ID_SEED = "clicktocall.body.details.button-enable";
            AdvancedClickToCallSetup.ATTR_BODY_ENABLE_BUTTON_TEXT_ID_SEED = "clicktocall.body.details.button.enable-text";
            AdvancedClickToCallSetup.ATTR_BODY_DISABLE_BUTTON_ID_SEED = "clicktocall.body.details.button-disable";
            AdvancedClickToCallSetup.ATTR_BODY_DISABLE_BUTTON_TEXT_ID_SEED = "clicktocall.body.details.button.disable-text";
            AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CHECKBOX_ID_SEED = "clicktocall.body.details.im-checkbox";
            AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_LABEL_ID_SEED = "clicktocall.body.details.im-message";
            AdvancedClickToCallSetup.ATTR_BODY_INSTANT_MESSAGING_CONTAINER_ID_SEED = "clicktocall.body.details.im-container";
            AdvancedClickToCallSetup.ATTR_BODY_CHECKBOX_TEXT_ID_SEED = "clicktocall.body.details.button.im-text";
            ClickToCallSetup.AdvancedClickToCallSetup = AdvancedClickToCallSetup;
            var ViewType;
            (function (ViewType) {
                ViewType[ViewType["SkypeForBusinessView"] = 0] = "SkypeForBusinessView";
                ViewType[ViewType["SkypeView"] = 1] = "SkypeView";
            })(ViewType = ClickToCallSetup.ViewType || (ClickToCallSetup.ViewType = {}));
            var ResourceType;
            (function (ResourceType) {
                ResourceType[ResourceType["HeaderIcon"] = 0] = "HeaderIcon";
                ResourceType[ResourceType["HeaderGroupName"] = 1] = "HeaderGroupName";
                ResourceType[ResourceType["HeaderName"] = 2] = "HeaderName";
                ResourceType[ResourceType["SkypeForBusinessService"] = 3] = "SkypeForBusinessService";
                ResourceType[ResourceType["SkypeService"] = 4] = "SkypeService";
            })(ResourceType = ClickToCallSetup.ResourceType || (ClickToCallSetup.ResourceType = {}));
            var ServiceType;
            (function (ServiceType) {
                ServiceType[ServiceType["SkypeForBusiness"] = 0] = "SkypeForBusiness";
                ServiceType[ServiceType["Skype"] = 1] = "Skype";
            })(ServiceType = ClickToCallSetup.ServiceType || (ClickToCallSetup.ServiceType = {}));
        })(ClickToCallSetup = AppCommon.ClickToCallSetup || (AppCommon.ClickToCallSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="AdvancedClickToCallSetup.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ClickToCallSetup;
        (function (ClickToCallSetup) {
            /**
             * Class refers to the path of all the string resources in localization resx file.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "CommunicationCollaboration", {
                    get: function () {
                        return "CommunicationCollaboration";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ClickToCall", {
                    get: function () {
                        return "ClickToCall";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Skype4Business", {
                    get: function () {
                        return "Skype4Business";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Skype", {
                    get: function () {
                        return "Skype";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Note", {
                    get: function () {
                        return "Note";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Skype4BusinessTooltip", {
                    get: function () {
                        return "Skype4BusinessTooltip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Skype4BusinessEnabledToolTip", {
                    get: function () {
                        return "Skype4BusinessEnabledTooltip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SkypeToolTip", {
                    get: function () {
                        return "SkypeTooltip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SkypeEnabledToolTip", {
                    get: function () {
                        return "SkypeEnabledTooltip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Enable", {
                    get: function () {
                        return "Enable";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Skype4BusinessDisabledText", {
                    get: function () {
                        return "Skype4BusinessDisabledText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Skype4BusinessEnabledText", {
                    get: function () {
                        return "Skype4BusinessEnabledText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "IMPresence", {
                    get: function () {
                        return "IMPresence";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SkypeDisabledText", {
                    get: function () {
                        return "SkypeDisabledText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SkypeEnabledText", {
                    get: function () {
                        return "SkypeEnabledText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ReadMoreTextForSkype", {
                    get: function () {
                        return "ReadMoreTextForSkype";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SuccessMessageText", {
                    get: function () {
                        return "SuccessMessageText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ReadMoreTextForSkype4Business", {
                    get: function () {
                        return "ReadMoreTextForSkype4Business";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ReadMoreText", {
                    get: function () {
                        return "ReadMoreText";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            ClickToCallSetup.ResourceKeys = ResourceKeys;
        })(ClickToCallSetup = AppCommon.ClickToCallSetup || (AppCommon.ClickToCallSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ClickToCallSetup;
        (function (ClickToCallSetup) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourcePath = (function () {
                function ResourcePath() {
                }
                Object.defineProperty(ResourcePath, "SkypeForBusinessIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/ClickToCall/SkypeforBusiness.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SkypeForBusinessIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/ClickToCall/SkypeBusiness_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SkypeIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/ClickToCall/Skype.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SkypeIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/ClickToCall/Skype_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SuccessIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/ClickToCall/SuccessX16.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ClickToCall.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ClickToCall_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SuccessIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/ClickToCall/SuccessX16_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourcePath;
            }());
            ClickToCallSetup.ResourcePath = ResourcePath;
        })(ClickToCallSetup = AppCommon.ClickToCallSetup || (AppCommon.ClickToCallSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=ClickToCall.js.map