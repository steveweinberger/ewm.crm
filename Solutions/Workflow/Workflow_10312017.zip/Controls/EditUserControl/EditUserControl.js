/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EditUser;
        (function (EditUser) {
            'use strict';
            var RetrieveCurrentOrganizationRequest = ODataContract.RetrieveCurrentOrganizationRequest;
            var EndpointAccessType = ODataContract.EndpointAccessType;
            var CommonUtils = Mscrm.AppCommon.Common.Utility;
            var WEBAPPLICATION = "WebApplication";
            var EditUserControl = (function () {
                /**
                 * constructor.
                 */
                function EditUserControl() {
                    this._context = null;
                    this._heightIFrame = null;
                    this._userDomainName = null;
                    this._userOrganizationId = null;
                    this._crmUrl = null;
                    this._gladosEditUserUrl = null;
                    this._isAsyncFunctionsCalled = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                EditUserControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._context.client.trackContainerResize(true);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                EditUserControl.prototype.updateView = function (context) {
                    this._context = context;
                    var userId = null;
                    if (!this._isAsyncFunctionsCalled) {
                        if (this._context.parameters.user_id) {
                            userId = this._context.parameters.user_id.raw;
                            this._setCrmUrl();
                            this._getUserDomainName(userId);
                            this._isAsyncFunctionsCalled = true;
                        }
                    }
                    if (!CommonUtils.isNullOrUndefined(this._userDomainName)
                        && !CommonUtils.isNullOrUndefined(this._userOrganizationId)
                        && !CommonUtils.isNullOrUndefined(this._crmUrl)) {
                        var lcid = this._context.userSettings.languageId;
                        this._gladosEditUserUrl = "https://port." + this._crmUrl + "/G/Users/UpdateUser.aspx?organizationId=" + this._userOrganizationId + "&upn=" + this._userDomainName + "&lcid=" + lcid;
                        this._heightIFrame = this._getAvailableHeight();
                        var dialogIFrame = this._context.factory.createElement("IFRAME", {
                            key: EditUser.Constants.IFrameKey, id: EditUser.Constants.IFrameKey,
                            title: this._context.resources.getString(EditUser.ResourceKeys.IFrameTitle),
                            src: this._gladosEditUserUrl,
                            style: {
                                width: "100%",
                                height: this._heightIFrame
                            }
                        });
                        return dialogIFrame;
                    }
                    var loadingLabel = this._context.factory.createElement("LABEL", {
                        key: EditUser.Constants.LoadingLabelKey, id: EditUser.Constants.LoadingLabelKey
                    }, this._context.resources.getString(EditUser.ResourceKeys.LoadingText));
                    var blankContainer = this._context.factory.createElement("CONTAINER", {
                        key: EditUser.Constants.BlankContainerKey, id: EditUser.Constants.BlankContainerKey,
                        style: {
                            display: "flex",
                            flex: "1 1 auto",
                            alignItems: "center",
                            justifyContent: "center"
                        }
                    }, [loadingLabel]);
                    return blankContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                EditUserControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                EditUserControl.prototype.destroy = function () {
                };
                /**
                 * Get available height for Iframe
                 */
                EditUserControl.prototype._getAvailableHeight = function () {
                    var height = 700;
                    try {
                        height = (window.top.document.body.offsetHeight - 90);
                        height = (height < 100) ? 100 : height;
                    }
                    catch (e) {
                        console.error(e);
                    }
                    return height;
                };
                /**
                 * Shows generic error message to user
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 */
                EditUserControl.prototype.showGenericError = function (context) {
                    var alertMessage = {
                        text: context.resources.getString(EditUser.ResourceKeys.Error_GenericErrorOccurred),
                        confirmButtonLabel: context.resources.getString(EditUser.ResourceKeys.ConfirmButtonText)
                    };
                    context.navigation.openAlertDialog(alertMessage);
                };
                /**
                 * Retrieves DomainName and organizationid of the user
                 */
                EditUserControl.prototype._getUserDomainName = function (userId) {
                    var that = this;
                    this._context.webAPI.retrieveRecord("systemuser", userId, "?$select=domainname,organizationid&$filter=systemuserid eq " + userId).then(function (response) {
                        that._userDomainName = response.domainname;
                        that._userOrganizationId = response.organizationid;
                        that._context.utils.requestRender();
                    }, function (error) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, error);
                        console.error(error);
                        that.showGenericError(that._context);
                    });
                };
                /**
                 * Generates part of URL needed for EditUser iframe
                 */
                EditUserControl.prototype._setCrmUrl = function () {
                    var that = this;
                    var retrieveCurrentOrganizationRequest = new RetrieveCurrentOrganizationRequest(EndpointAccessType.Default);
                    this._context.webAPI.execute(retrieveCurrentOrganizationRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                /*
                                Sample format of JSON retrived by the OData call
                                {
                                    "Detail": {
                                        "Endpoints": {
                                            "Count": 3,
                                            "IsReadOnly": false,
                                            "Keys": [
                                                "WebApplication",
                                                "OrganizationService",
                                                "OrganizationDataService"
                                            ],
                                            "Values": [
                                                "https://someorg.crmx.something.com/",
                                                "https://someorg.crmx.something.com/XRMServices/2011/Organization.svc",
                                                "https://someorg.crmx.something.com/XRMServices/2011/OrganizationData.svc"
                                            ]
                                        }
                                    }
                                }
                                */
                                try {
                                    var index = jsonResponse.Detail.Endpoints.Keys.indexOf(WEBAPPLICATION);
                                    if (index != -1) {
                                        var webApplicationEndpoint = jsonResponse.Detail.Endpoints.Values[index];
                                        that._crmUrl = CommonUtils.GetCrmHostName(webApplicationEndpoint);
                                    }
                                    else {
                                        that.showGenericError(that._context);
                                    }
                                }
                                catch (e) {
                                    console.error(e);
                                    that.showGenericError(that._context);
                                }
                                finally {
                                    that._context.utils.requestRender();
                                }
                            });
                        }
                    }, function (error) {
                        that._gladosEditUserUrl = null;
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, error);
                        console.error(error);
                        that.showGenericError(that._context);
                    });
                };
                return EditUserControl;
            }());
            EditUser.EditUserControl = EditUserControl;
        })(EditUser = AppCommon.EditUser || (AppCommon.EditUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="EditUserControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: Constants contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EditUser;
        (function (EditUser) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                Object.defineProperty(Constants, "IFrameKey", {
                    get: function () {
                        return "editUser_IFrame";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "LoadingLabelKey", {
                    get: function () {
                        return "editUser_LoadingLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "BlankContainerKey", {
                    get: function () {
                        return "editUser_BlankContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Constants;
            }());
            EditUser.Constants = Constants;
        })(EditUser = AppCommon.EditUser || (AppCommon.EditUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EditUser;
        (function (EditUser) {
            /**
             * Class refers to the path of all the keys for localization
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "WebApiRequestFailed", {
                    get: function () {
                        return "WebApiRequestFailed";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "WebApplicationEnpointNotFound", {
                    get: function () {
                        return "WebApplicationEnpointNotFound";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "IFrameTitle", {
                    get: function () {
                        return "IFrameTitle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "LoadingText", {
                    get: function () {
                        return "LoadingText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Error_GenericErrorOccurred", {
                    get: function () {
                        return "Error_GenericErrorOccurred";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            EditUser.ResourceKeys = ResourceKeys;
        })(EditUser = AppCommon.EditUser || (AppCommon.EditUser = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=EditUserControl.js.map