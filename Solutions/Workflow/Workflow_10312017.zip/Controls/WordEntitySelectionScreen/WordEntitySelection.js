var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            'use strict';
            var Utility = Mscrm.AppCommon.Common.Utility;
            var WordEntitySelectionScreen = (function () {
                /**
                 * Empty constructor.
                 */
                function WordEntitySelectionScreen() {
                    this._etnToEtcMap = {};
                    this._templateInfo = {
                        DisplayName: "",
                        EntityTypeCode: -1,
                        SelectedEntities: {
                            oneToMany: null,
                            manyToOne: null,
                            manyToMany: null
                        }
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                WordEntitySelectionScreen.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    this._applyStyles = new ExcelWordTemplate.WordEntitySelectionStyles(context);
                    this._currentEntitySelected = { Value: 0, Label: "", Id: "" };
                    this._etnToEtcMap[""] = { otc: -1, displayName: "" };
                    this.getEntities();
                    this._localizeString = new ExcelWordTemplate.LocalizeString(context, "webresource");
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                WordEntitySelectionScreen.prototype.updateView = function (context) {
                    // custom code goes here
                    // Create Select Related Entities Link
                    var SelectRelatedEntitiesButton = context.factory.createElement("HYPERLINK", {
                        id: "SelectRelatedEntitiesButton",
                        key: "SelectRelatedEntitiesButton",
                        style: {},
                        onClick: this.onHyperLinkClicked.bind(this)
                    }, this._context.resources.getString("WordEntitySelection_RelatedEntitiesLabel"));
                    //Create container
                    var WordEntitySelectionScreenContainer = context.factory.createElement("CONTAINER", {
                        id: "WordEntitySelectionScreenContainer",
                        key: "WordEntitySelectionScreenContainer",
                        style: this._applyStyles.WordEntitySelectionScreenContainer(),
                    }, [this.createEntitySelectorControl(), SelectRelatedEntitiesButton]);
                    return WordEntitySelectionScreenContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                WordEntitySelectionScreen.prototype.getOutputs = function () {
                    return {
                        templateInfo: JSON.stringify(this._templateInfo)
                    };
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                WordEntitySelectionScreen.prototype.destroy = function () {
                };
                /**
                * Generates the control with the entity selection combobox
                */
                WordEntitySelectionScreen.prototype.createEntitySelectorControl = function () {
                    // create the entitySelect combobox
                    this._entitiesProps = {
                        id: 'entitySelectorContainer',
                        key: "entitySelector",
                        freeTextMode: false,
                        onChange: this._onChangeHandlerEntity.bind(this),
                        value: { Value: this._currentEntitySelected.Value },
                        options: this._entityList,
                        style: this._applyStyles.selectStyle()
                    };
                    var entitiesSelector = this._context.factory.createElement("SELECT", this._entitiesProps, null);
                    var fontColor = this._currentEntitySelected.Id == "" ? "#bcbcbc" : "#202200";
                    var selectEntityLabel = this._context.factory.createElement("LABEL", {
                        key: "selectEntityLabel",
                        id: "selectEntityLabel",
                        forElementId: this._context.accessibility.getUniqueId("entitySelectorContainer"),
                        style: { color: fontColor } && this._applyStyles.WordEntitySelectEntityLabel()
                    }, this._context.resources.getString("WordEntitySelection_EntityFilterLabel"));
                    return this._context.factory.createElement("CONTAINER", {
                        style: this._applyStyles.WordEntitySelectorContainer(),
                        key: "entitySelectorDivContainer",
                        id: "entitySelectorDivContainer"
                    }, [selectEntityLabel, entitiesSelector]);
                };
                /**
                * Gets the list of the entity names.
                */
                WordEntitySelectionScreen.prototype.getEntities = function () {
                    if ((this._entitiesJsonData == null || this._entitiesJsonData == undefined) || (this._entitiesJsonData != null && this._entitiesJsonData.value == null)) {
                        this._entitiesJsonData = this._context.parameters.EntityList.raw;
                        this._createEntitiesList();
                    }
                };
                WordEntitySelectionScreen.prototype.renderControl = function (render, callback) {
                    if (render === void 0) { render = false; }
                    if (callback === void 0) { callback = null; }
                    if (render) {
                        this._context.utils.requestRender(callback);
                    }
                };
                /**
                 * Button Handler
                 */
                WordEntitySelectionScreen.prototype.onHyperLinkClicked = function () {
                    if (this._templateInfo.EntityTypeCode != -1) {
                        var dialogOptions = {};
                        var dialogParameters = {};
                        dialogOptions.width = "100%";
                        dialogOptions.height = "100%";
                        dialogParameters["template_info"] = this._context.parameters.templateInfo.raw;
                        var that_1 = this;
                        this._context.navigation.openDialog("RelationshipSelectionWordTemplate", dialogOptions, dialogParameters).then(function (closeResponse) {
                            if (!Utility.isNullOrUndefined(closeResponse.parameters)) {
                                var jsonString = closeResponse.parameters.template_info;
                                var parameters = JSON.parse(jsonString);
                                that_1._templateInfo.SelectedEntities = parameters.SelectedEntities;
                                that_1._notifyOutputChanged();
                            }
                        });
                        event.preventDefault();
                    }
                    else {
                        var alertStrings = {
                            text: this._context.resources.getString("WordEntitySelection_EntityAlertLabel"),
                            confirmButtonLabel: this._context.resources.getString("WordEntitySelection_ConfirmButtonLabel")
                        };
                        this._context.navigation.openAlertDialog(alertStrings);
                        event.preventDefault();
                    }
                };
                /**
                 * OnChangeHandler for Entity Dropdown
                .* It retrieves views related to an entity
                 * @param selectedEntity: Entity selected in dropdown
                 */
                WordEntitySelectionScreen.prototype._onChangeHandlerEntity = function (selectedEntity) {
                    if (!this.EqualsIgnoreCase(this._currentEntitySelected.Id, selectedEntity.Id)) {
                        this._currentEntitySelected = selectedEntity;
                        if (!Utility.isNullOrUndefined(selectedEntity.Id)) {
                            this._templateInfo.EntityTypeCode = this._etnToEtcMap[selectedEntity.Id].otc;
                            this._templateInfo.DisplayName = this._etnToEtcMap[selectedEntity.Id].displayName;
                        }
                        this._notifyOutputChanged();
                    }
                };
                /**
                    * Forms an array of the Combobox options.
                    * @returns The virtual component array of options
                */
                WordEntitySelectionScreen.prototype._createEntitiesList = function () {
                    var defaultValue = [
                        { Value: 0, Label: this._context.resources.getString("WordEntitySelection_EntityLabel"), Id: "" }
                    ];
                    if ((this._entitiesJsonData == null || this._entitiesJsonData == undefined)) {
                        return defaultValue;
                    }
                    var i;
                    var entitiesOptions = [];
                    for (i = 0; i < this._entitiesJsonData.length; i++) {
                        entitiesOptions = entitiesOptions.concat(this._createOption(i + 1, this._entitiesJsonData[i].UserLocalizedName, this._entitiesJsonData[i].LogicalName));
                        this._etnToEtcMap[this._entitiesJsonData[i].LogicalName] =
                            {
                                otc: this._entitiesJsonData[i].OTC,
                                displayName: this._entitiesJsonData[i].UserLocalizedName
                            };
                    }
                    entitiesOptions.sort(function (firstOption, secondOption) {
                        if (firstOption.Label != secondOption.Label) {
                            if (firstOption.Label < secondOption.Label)
                                return -1;
                            else if (firstOption.Label > secondOption.Label)
                                return 1;
                        }
                        return 0;
                    });
                    this._entityList = defaultValue.concat(entitiesOptions);
                };
                /**
                * Creates an option for the given value.
                */
                WordEntitySelectionScreen.prototype._createOption = function (key, value, text) {
                    return { Value: key, Label: value, Id: text };
                };
                /**
                 * Utility Function
                 * @param string1
                 * @param string2
                 */
                WordEntitySelectionScreen.prototype.EqualsIgnoreCase = function (string1, string2) {
                    var isString1Null = string1 == null;
                    var isString2Null = string2 == null;
                    var isString1Undefined = string1 == undefined;
                    var isString2Undefined = string2 == undefined;
                    if (isString1Null && isString2Null || isString1Undefined && isString2Undefined) {
                        return true;
                    }
                    if (isString1Null != isString2Null || isString1Undefined != isString2Undefined) {
                        return false;
                    }
                    return string1.toUpperCase() === string2.toUpperCase();
                };
                return WordEntitySelectionScreen;
            }());
            ExcelWordTemplate.WordEntitySelectionScreen = WordEntitySelectionScreen;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="control.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: LocalizeString is a wraper to the core API for getting the resource string. In case the core API fails the class will return the default string provided by the caller as the resurce string
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            'use strict';
            // This code is for localization and will be finally part of common utility
            var LocalizeString = (function () {
                function LocalizeString(context, webresource) {
                    this.context = context;
                    this.webresource = webresource;
                }
                /**
                * The function returns the key if resource is not found
                * @param key
                * @param value
                */
                LocalizeString.prototype.getResourceString = function (key, value) {
                    try {
                        if (this.webresource === null)
                            throw new Error("WebResource should be initialized, for fetching value corresponding to key");
                        if (this.context === null)
                            throw new Error("Context should not be NULL");
                        var _value = undefined;
                        //value=LocalizeString.context.utils.getResourceString(key, LocalizeString.webresource);
                        if (_value === undefined)
                            return value;
                    }
                    catch (e) {
                        if (e instanceof Error) {
                            console.log(e.message);
                        }
                    }
                };
                return LocalizeString;
            }());
            ExcelWordTemplate.LocalizeString = LocalizeString;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            var WordEntitySelectionStyles = (function (_super) {
                __extends(WordEntitySelectionStyles, _super);
                function WordEntitySelectionStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._wordEntitySelectionScreenContainer = {};
                    _this._wordEntitySelectEntityLabel = {};
                    _this._wordEntitySelectorContainer = {};
                    _this._context = context;
                    _this._wordEntitySelectionScreenContainer = null;
                    _this._wordEntitySelectEntityLabel = null;
                    _this._wordEntitySelectorContainer = null;
                    return _this;
                }
                WordEntitySelectionStyles.prototype.WordEntitySelectionScreenContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._wordEntitySelectionScreenContainer)) {
                        this._wordEntitySelectionScreenContainer = {};
                        this._wordEntitySelectionScreenContainer["flexDirection"] = "column";
                    }
                    return this._wordEntitySelectionScreenContainer;
                };
                WordEntitySelectionStyles.prototype.WordEntitySelectEntityLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._wordEntitySelectEntityLabel)) {
                        this._wordEntitySelectEntityLabel = {};
                        this._wordEntitySelectEntityLabel["paddingBottom"] = "3px";
                        this._wordEntitySelectEntityLabel["paddingLeft"] = "1px";
                        this._wordEntitySelectEntityLabel["float"] = "left";
                    }
                    return this._wordEntitySelectEntityLabel;
                };
                WordEntitySelectionStyles.prototype.WordEntitySelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._wordEntitySelectorContainer)) {
                        this._wordEntitySelectorContainer = {};
                        this._wordEntitySelectorContainer["alignItems"] = "left";
                        this._wordEntitySelectorContainer["borderBottomColor"] = "#bbbbbb";
                        this._wordEntitySelectorContainer["borderStyle"] = "solid";
                        this._wordEntitySelectorContainer["paddingTop"] = "10px";
                        this._wordEntitySelectorContainer["paddingLeft"] = "10px";
                        this._wordEntitySelectorContainer["float"] = "left";
                        this._wordEntitySelectorContainer["paddingBottom"] = "5px";
                        this._wordEntitySelectorContainer["width"] = 235;
                        this._wordEntitySelectorContainer["flexDirection"] = "column";
                    }
                    return this._wordEntitySelectorContainer;
                };
                return WordEntitySelectionStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            ExcelWordTemplate.WordEntitySelectionStyles = WordEntitySelectionStyles;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=WordEntitySelection.js.map