var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../../FREShell/libs/frecommon-lib.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            'use strict';
            var Utility = Mscrm.AppCommon.Common.Utility;
            var ExportToExcelRequest = ODataContract.ExportToExcelRequest;
            var ExportExcelTemplateCommand = (function () {
                function ExportExcelTemplateCommand(context) {
                    this._fileExtension = ".xlsx";
                    this._mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    this._context = context;
                }
                ExportExcelTemplateCommand.prototype.Execute = function (commandData) {
                    if (Utility.isNullOrEmptyString(commandData)) {
                        throw new Error("Command data cannot be null");
                    }
                    var parsedData = JSON.parse(commandData);
                    this._displayName = parsedData.DisplayName;
                    var exportToExcelRequest = new ExportToExcelRequest(parsedData.view, parsedData.fetchXml, parsedData.layoutXml, parsedData.queryApi, parsedData.queryParameters);
                    var that = this;
                    this._context.webAPI.execute(exportToExcelRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                that.SuccessCallback(jsonResponse);
                            });
                        }
                    });
                };
                ExportExcelTemplateCommand.prototype.SuccessCallback = function (response) {
                    var fileName = this._displayName + this._fileExtension;
                    var fileContent = response.ExcelFile;
                    var fileBlob = Utility.Base64ToBlob(fileContent, this._mimeType);
                    if (window.navigator.msSaveOrOpenBlob) {
                        window.navigator.msSaveOrOpenBlob(fileBlob, fileName);
                    }
                    else {
                        var blobUrl = window.URL.createObjectURL(fileBlob);
                        Utility.clickOnTempAnchor(blobUrl, fileName);
                        window.URL.revokeObjectURL(blobUrl);
                    }
                };
                return ExportExcelTemplateCommand;
            }());
            DownloadTemplate.ExportExcelTemplateCommand = ExportExcelTemplateCommand;
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/// <reference path="../../FREShell/libs/frecommon-lib.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            'use strict';
            var Utility = Mscrm.AppCommon.Common.Utility;
            var ExportTemplateToWordRequest = ODataContract.ExportTemplateToWordRequest;
            var ExportWordTemplateCommand = (function () {
                function ExportWordTemplateCommand(context) {
                    this._fileExtension = ".docx";
                    this._mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                    this._context = context;
                }
                ExportWordTemplateCommand.prototype.Execute = function (commandData) {
                    if (Utility.isNullOrEmptyString(commandData)) {
                        throw new Error("Command data cannot be null");
                    }
                    var parsedData = JSON.parse(commandData);
                    this._displayName = parsedData.DisplayName;
                    var exportWordTemplateRequest = new ExportTemplateToWordRequest(parsedData.EntityTypeCode, JSON.stringify(parsedData.SelectedEntities).replace(/"/g, "'") // replace all double quotes with single quotes
                    );
                    var that = this;
                    this._context.webAPI.execute(exportWordTemplateRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                that.SuccessCallback(jsonResponse);
                            });
                        }
                    });
                };
                ExportWordTemplateCommand.prototype.SuccessCallback = function (response) {
                    var fileName = this._displayName + this._fileExtension;
                    var fileContent = response.WordFile;
                    var fileBlob = Utility.Base64ToBlob(fileContent, this._mimeType);
                    if (window.navigator.msSaveOrOpenBlob) {
                        window.navigator.msSaveOrOpenBlob(fileBlob, fileName);
                    }
                    else {
                        var blobUrl = window.URL.createObjectURL(fileBlob);
                        Utility.clickOnTempAnchor(blobUrl, fileName);
                        window.URL.revokeObjectURL(blobUrl);
                    }
                };
                return ExportWordTemplateCommand;
            }());
            DownloadTemplate.ExportWordTemplateCommand = ExportWordTemplateCommand;
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            'use strict';
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            'use strict';
            var Utility = Mscrm.AppCommon.Common.Utility;
            var DocType = Mscrm.AppCommon.Common.DocumentTemplateType;
            var $;
            var DownloadTemplateControl = (function () {
                /**
                 * Empty constructor.
                 */
                function DownloadTemplateControl() {
                    this._templateType = DocType.None;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                DownloadTemplateControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._applyStyles = new DownloadTemplate.DownloadTemplateControlStyles(context);
                    this.updateTemplateLaterCheckbox = false;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                DownloadTemplateControl.prototype.updateView = function (context) {
                    // No template selected. Return, since the UI will not be in consistent state.
                    // If neither excel or word template params are configured return.
                    if (!this._context.parameters.templateType
                        || !(this._context.parameters.entity_id || this._context.parameters.templateInfo)) {
                        return;
                    }
                    this._templateType = this.getTemplateType(this._context.parameters.templateType.raw);
                    if (this._templateType == DocType.Excel) {
                        this.controlname = "DownloadTemplateExcelTemplatePage.Icon";
                    }
                    else if (this._templateType == DocType.Word) {
                        this.controlname = "DownloadTemplateWordTemplatePage.Icon";
                    }
                    if (this._context.parameters.entity_id) {
                        this.entityName = this._context.parameters.entity_id.raw;
                    }
                    if (this._context.parameters.templateInfo) {
                        this._templateInfo = this._context.parameters.templateInfo.raw;
                        this.entityName = JSON.parse(this._templateInfo).DisplayName;
                    }
                    //TODO: The entityName is logical name. Use display name instead.
                    this.fileName = this.entityName + "." + Utility.GetFileExtensionForDocument(this._templateType);
                    if (this._context.parameters.view_id) {
                        this.viewName = this._context.parameters.view_id.raw;
                    }
                    var DownloadTemplateScreenLabel = context.factory.createElement("LABEL", {
                        id: "DownloadTemplateScreenLabel",
                        key: "DownloadTemplateScreenLabel",
                        style: this._applyStyles.DownloadTemplateScreenLabel()
                    }, this._context.resources.getString("DowloadTemplateControl_LabelName"));
                    var stepOneLabel = "";
                    if (this._templateType == DocType.Excel) {
                        stepOneLabel = "DowloadTemplateControl_StepOneLabel_Excel";
                    }
                    else if (this._templateType == DocType.Word) {
                        stepOneLabel = "DowloadTemplateControl_StepOneLabel_Word";
                    }
                    var StepOneDownloadTemplateScreenLabel = context.factory.createElement("LABEL", {
                        id: "StepOneDownloadTemplateScreenLabel",
                        key: "StepOneDownloadTemplateScreenLabel",
                        style: this._applyStyles.DownloadTemplateStepOneScreenLabel()
                    }, this._context.resources.getString(stepOneLabel));
                    var StepTwoDownloadTemplateScreenLabel = context.factory.createElement("LABEL", {
                        id: "StepTwoDownloadTemplateScreenLabel",
                        key: "StepTwoDownloadTemplateScreenLabel",
                        style: this._applyStyles.DownloadTemplateStepTwoScreenLabel()
                    }, this._context.resources.getString("DowloadTemplateControl_StepTwoLabel"));
                    var templateGeneratedLabel = "";
                    if (this._templateType == DocType.Excel) {
                        templateGeneratedLabel = "DowloadTemplateControl_TemplateGeneratedLabel_Excel";
                    }
                    else if (this._templateType == DocType.Word) {
                        templateGeneratedLabel = "DowloadTemplateControl_TemplateGeneratedLabel_Word";
                    }
                    var TemplateGeneratedLabel = context.factory.createElement("LABEL", {
                        id: "TemplateGeneratedLabel",
                        key: "TemplateGeneratedLabel",
                        style: this._applyStyles.DownloadTemplateGeneratedLabel()
                    }, this._context.resources.getString(templateGeneratedLabel));
                    var ExcelButton = context.factory.createElement("LABEL", {
                        key: this.controlname,
                        id: this.controlname,
                        style: this._applyStyles.DownloadTemplateExcelButton()
                    });
                    var ExcelLabel = context.factory.createElement("LABEL", {
                        id: "ExcelLabel",
                        key: "ExcelLabel",
                        style: this._applyStyles.DownloadTemplateExcelLabel()
                    }, this.fileName);
                    var ExcelContainer = context.factory.createElement("CONTAINER", {
                        key: "ExcelContainer", id: "ExcelContainer", style: this._applyStyles.DownloadTemplateExcelContainerStyle()
                    }, [ExcelButton, ExcelLabel]);
                    var DownloadLabel = context.factory.createElement("BUTTON", {
                        id: "DownloadLabel",
                        key: "DownloadLabel",
                        style: this._applyStyles.DownloadTemplateButtonLabel()
                    }, this._context.resources.getString("DownloadTemplateControl_DownloadLabel"));
                    var DownloadContainer = context.factory.createElement("CONTAINER", {
                        key: "DownloadContainer", id: "DownloadContainer", style: this._applyStyles.DownloadTemplateContainer(), onClick: this.onDownloadButtonClicked.bind(this)
                    }, [DownloadLabel]);
                    var uploadTemplateLater = context.factory.createElement("LABEL", {
                        key: "crmFieldsLabel",
                        id: "crmFieldsLabel",
                        forElementId: this._context.accessibility.getUniqueId("uploadlater_checkbox"),
                        style: this._applyStyles.DownloadTemplateUploadLater()
                    }, this._context.resources.getString(DownloadTemplate.ResourceKeys.UploadLater));
                    var checkBox = context.factory.createElement("BOOLEAN", {
                        type: "checkbox",
                        id: "uploadlater_checkbox",
                        key: "uploadlater_checkbox",
                        tagname: "INPUT",
                        value: false || this.updateTemplateLaterCheckbox,
                        onValueChange: this._onClickHandlerCheckbox.bind(this),
                    }, null);
                    // return the container with the entitySelect combobox
                    var checkboxContainer = context.factory.createElement("CONTAINER", {
                        style: this._applyStyles.DownloadTemplateCheckboxContainer(),
                        key: "checkboxContainer",
                        id: "checkboxContainer"
                    }, [checkBox, uploadTemplateLater]);
                    var TemplatePageContainer = context.factory.createElement("CONTAINER", {
                        id: "TemplatePageContainer",
                        key: "TemplatePageContainer",
                        style: this._applyStyles.DownloadTemplatePageContainer()
                    }, [DownloadTemplateScreenLabel,
                        StepOneDownloadTemplateScreenLabel,
                        StepTwoDownloadTemplateScreenLabel,
                        TemplateGeneratedLabel,
                        ExcelContainer,
                        DownloadContainer,
                        checkboxContainer]);
                    // custom code goes here
                    return TemplatePageContainer;
                };
                DownloadTemplateControl.prototype.AddFilterToFetchXml = function (fetchXml) {
                    //ALL JS
                    //Deserialize the fetchXml and Serialize it further
                    //Perf test using string manipulation
                    var parser = new DOMParser();
                    var fetchXmlParsed = parser.parseFromString(fetchXml, "text/xml");
                    var filter = fetchXmlParsed.getElementsByTagName('filter')[0];
                    if (filter === undefined) {
                        fetchXmlParsed.getElementsByTagName('entity')[0].appendChild(document.createElement('filter'));
                    }
                    var condition = document.createElement('condition');
                    condition.setAttribute("attribute", "ownerid");
                    condition.setAttribute("operator", "eq");
                    condition.setAttribute("value", "{00000000-0000-0000-0000-000000000000}");
                    fetchXmlParsed.getElementsByTagName('filter')[0].appendChild(condition);
                    var newFetchXml = fetchXmlParsed.getElementsByTagName('fetch');
                    return '<fetch version="1.0" output-format="xml- platform" mapping="logical">' + newFetchXml[0].innerHTML + "</fetch>";
                };
                DownloadTemplateControl.prototype._onClickHandlerCheckbox = function (value) {
                    this.updateTemplateLaterCheckbox = value;
                    this._notifyOutputChanged();
                };
                DownloadTemplateControl.prototype.onDownloadButtonClicked = function (event) {
                    if (this._templateType == DocType.Word) {
                        var command = new DownloadTemplate.ExportWordTemplateCommand(this._context);
                        command.Execute(this._templateInfo);
                        return;
                    }
                    //Do not export as no entity selected
                    if (this.isNullUndefinedOrWhitespace(this.entityName)) {
                        //TODO: Select entity to export flag 
                        return;
                    }
                    else if (this.isNullUndefinedOrWhitespace(this.viewName)) {
                        var theurl = this._context.utils.createCrmUri("/tools/importwizard/createtemplate.aspx?entityName=");
                        theurl = theurl + this.entityName;
                        this._context.navigation.openUrl(theurl);
                        return;
                    }
                    else {
                        var viewId = this.viewName;
                        var fetchXmlStatic = this._context.parameters.entityview_fetchxml.raw;
                        fetchXmlStatic = this.AddFilterToFetchXml(fetchXmlStatic);
                        var layoutXmlStatic = this._context.parameters.entityview_layoutxml.raw;
                        var viewType = DownloadTemplate.Constants.Form.SAVED_QUERY_VIEW_TYPE;
                        var exportType = DownloadTemplate.Constants.EXPORT_TYPE_XLSX;
                        var printAllPages = "1";
                        //"<fetch distinct=\"false\" no-lock=\"false\" mapping=\"logical\"> < entity name=\"account\"> < filter type=\"and\">	< condition attribute=\"accountid\" operator=\"eq\" value=\"{00000000-0000-0000-0000-000000000000}\" />	< /filter>< /entity></fetch>";
                        var formAttributes = {};
                        formAttributes["action"] = this._context.utils.createCrmUri("/_grid/print/print_data.aspx");
                        formAttributes["method"] = "POST";
                        formAttributes["target"] = "exportIFrame";
                        formAttributes["id"] = "exportTemplateForm";
                        var form = this.createFormElement(formAttributes, exportType, fetchXmlStatic, layoutXmlStatic, viewId, viewType, printAllPages);
                        //TODO: Change this JS code
                        document.getElementsByTagName('body')[0].appendChild(form);
                        form.submit();
                    }
                };
                /**
                 *  Create a form for making a call to action
                 * @param formAttributes: contains action, method, target and id of the form
                 * @param exportType: Export template or Data
                 * @param fetchXmlString: fetchXml string
                 * @param layoutXmlString: layoutXml
                 * @param viewId: Id of the view for which export has to be done
                 * @param viewType: Constant in our case as export is based on savedqueryid
                 * @param printAllPages: PrintAll Pages when exporting the data
                 */
                DownloadTemplateControl.prototype.createFormElement = function (formAttributes, exportType, fetchXmlString, layoutXmlString, viewId, viewType, printAllPages) {
                    var form = document.createElement('form');
                    form.action = formAttributes["action"];
                    form.method = formAttributes["method"];
                    form.target = formAttributes["target"];
                    form.id = formAttributes["id"];
                    var exportTypeInput = document.createElement('input');
                    exportTypeInput.type = "hidden";
                    exportTypeInput.name = "exportType";
                    exportTypeInput.value = exportType;
                    form.appendChild(exportTypeInput);
                    var fetchXml = document.createElement('input');
                    fetchXml.type = "hidden";
                    fetchXml.name = "fetchXml";
                    fetchXml.value = fetchXmlString;
                    form.appendChild(fetchXml);
                    var layoutXml = document.createElement('input');
                    layoutXml.type = "hidden";
                    layoutXml.name = "layoutXml";
                    layoutXml.value = layoutXmlString;
                    form.appendChild(layoutXml);
                    var viewIdInput = document.createElement('input');
                    viewIdInput.type = "hidden";
                    viewIdInput.name = "viewid";
                    viewIdInput.value = viewId;
                    form.appendChild(viewIdInput);
                    var viewTypeInput = document.createElement('input');
                    viewTypeInput.type = "hidden";
                    viewTypeInput.name = "viewtype";
                    viewTypeInput.value = viewType;
                    form.appendChild(viewTypeInput);
                    var exportAllPages = document.createElement('input');
                    exportAllPages.type = "hidden";
                    exportAllPages.name = "printAllPages";
                    exportAllPages.value = printAllPages;
                    form.appendChild(exportAllPages);
                    return form;
                };
                DownloadTemplateControl.prototype.EqualsIgnoreCase = function (string1, string2) {
                    var isString1Null = string1 == null;
                    var isString2Null = string2 == null;
                    var isString1Undefined = string1 == undefined;
                    var isString2Undefined = string2 == undefined;
                    if (isString1Null && isString2Null || isString1Undefined && isString2Undefined) {
                        return true;
                    }
                    if (isString1Null != isString2Null || isString1Undefined != isString2Undefined) {
                        return false;
                    }
                    return string1.toUpperCase() === string2.toUpperCase();
                };
                DownloadTemplateControl.prototype.isNullUndefinedOrWhitespace = function (s) {
                    return s == null || s == undefined || s.trim().length === 0;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                DownloadTemplateControl.prototype.getOutputs = function () {
                    var result = {
                        upload_later: this.updateTemplateLaterCheckbox
                    };
                    return result;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                DownloadTemplateControl.prototype.destroy = function () {
                };
                DownloadTemplateControl.prototype.getTemplateType = function (templateType) {
                    switch (templateType) {
                        case "1":
                            return DocType.Excel;
                        case "2":
                            return DocType.Word;
                    }
                    return DocType.None;
                };
                return DownloadTemplateControl;
            }());
            DownloadTemplate.DownloadTemplateControl = DownloadTemplateControl;
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="DownloadTemplateControl.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            var Constants;
            (function (Constants) {
                Constants.DATA_SELECTOR = "1";
                Constants.TEMPLATE_SELECTOR = "0";
                Constants.EXPORT_TYPE_XLSX = "xlsx";
                Constants.UPLOAD_CHECKBOX = "I will upload the template later";
                var Form;
                (function (Form) {
                    Form.SAVED_QUERY_VIEW_TYPE = "1039";
                    Form.FORM_TAG = "form";
                    Form.PRINT_DATA_ASPX = "/_grid/print/print_data.aspx";
                    Form.FORM_POST = "POST";
                    Form.FORM_TARGET = "exportIFrame";
                })(Form = Constants.Form || (Constants.Form = {}));
            })(Constants = DownloadTemplate.Constants || (DownloadTemplate.Constants = {}));
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            var DownloadTemplateControlStyles = (function (_super) {
                __extends(DownloadTemplateControlStyles, _super);
                function DownloadTemplateControlStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._downloadTemplateExcelContainerStyle = {};
                    _this._downloadTemplateScreenLabel = {};
                    _this._downloadTemplateStepOneScreenLabel = {};
                    _this._downloadTemplateStepTwoScreenLabel = {};
                    _this._downloadTemplateGeneratedLabel = {};
                    _this._downloadTemplateExcelButton = {};
                    _this._downloadTemplateExcelLabel = {};
                    _this._downloadTemplateButtonLabel = {};
                    _this._downloadTemplateContainer = {};
                    _this._downloadTemplateUploadLater = {};
                    _this._downloadTemplateCheckboxContainer = {};
                    _this._downloadTemplatePageContainer = {};
                    _this._context = context;
                    _this._downloadTemplateExcelContainerStyle = null;
                    _this._downloadTemplateScreenLabel = null;
                    _this._downloadTemplateStepOneScreenLabel = null;
                    _this._downloadTemplateStepTwoScreenLabel = null;
                    _this._downloadTemplateGeneratedLabel = null;
                    _this._downloadTemplateExcelButton = null;
                    _this._downloadTemplateExcelLabel = null;
                    _this._downloadTemplateButtonLabel = null;
                    _this._downloadTemplateContainer = null;
                    _this._downloadTemplateUploadLater = null;
                    _this._downloadTemplateCheckboxContainer = null;
                    _this._downloadTemplatePageContainer = null;
                    return _this;
                }
                DownloadTemplateControlStyles.prototype.DownloadTemplateExcelContainerStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateExcelContainerStyle)) {
                        this._downloadTemplateExcelContainerStyle = {};
                        this._downloadTemplateExcelContainerStyle["flexDirection"] = "column";
                        this._downloadTemplateExcelContainerStyle["justifyContent"] = "space-between";
                        this._downloadTemplateExcelContainerStyle["cursor"] = "pointer";
                        this._downloadTemplateExcelContainerStyle["width"] = "150px";
                        this._downloadTemplateExcelContainerStyle["height"] = "150px";
                        this._downloadTemplateExcelContainerStyle["borderWidth"] = "0.1rem";
                        this._downloadTemplateExcelContainerStyle["borderStyle"] = "solid";
                        this._downloadTemplateExcelContainerStyle["borderColor"] = "#BFC5C6";
                        this._downloadTemplateExcelContainerStyle["margin"] = "8px";
                        this._downloadTemplateExcelContainerStyle["boxShadow"] = "1px 1px 2px 0px #BFC5C6";
                        this._downloadTemplateExcelContainerStyle["backgroundColor"] = this._context.theming.colors.basecolor.white;
                        this._downloadTemplateExcelContainerStyle["alignSelf"] = "center";
                    }
                    return this._downloadTemplateExcelContainerStyle;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateScreenLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateScreenLabel)) {
                        this._downloadTemplateScreenLabel = {};
                        this._downloadTemplateScreenLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._downloadTemplateScreenLabel["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._downloadTemplateScreenLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._downloadTemplateScreenLabel;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateStepOneScreenLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateStepOneScreenLabel)) {
                        this._downloadTemplateStepOneScreenLabel = {};
                        this._downloadTemplateStepOneScreenLabel["fontSize"] = "1.00rem";
                        this._downloadTemplateStepOneScreenLabel["fontFamily"] = "SegoeUI-Semibold";
                        this._downloadTemplateStepOneScreenLabel["color"] = "#333333";
                        this._downloadTemplateStepOneScreenLabel["whiteSpace"] = "Normal";
                    }
                    return this._downloadTemplateStepOneScreenLabel;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateStepTwoScreenLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateStepTwoScreenLabel)) {
                        this._downloadTemplateStepTwoScreenLabel = {};
                        this._downloadTemplateStepTwoScreenLabel["marginBottom"] = this._context.theming.measures.measure150;
                        this._downloadTemplateStepTwoScreenLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._downloadTemplateStepTwoScreenLabel["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._downloadTemplateStepTwoScreenLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._downloadTemplateStepTwoScreenLabel;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateGeneratedLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateGeneratedLabel)) {
                        this._downloadTemplateGeneratedLabel = {};
                        this._downloadTemplateGeneratedLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._downloadTemplateGeneratedLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._downloadTemplateGeneratedLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._downloadTemplateGeneratedLabel["marginBottom"] = "10px";
                    }
                    return this._downloadTemplateGeneratedLabel;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateExcelButton = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateExcelButton)) {
                        this._downloadTemplateExcelButton = {};
                        this._downloadTemplateExcelButton["alignSelf"] = "center";
                        this._downloadTemplateExcelButton["marginTop"] = this._context.theming.measures.measure225;
                        this._downloadTemplateExcelButton["marginBottom"] = "22px";
                    }
                    return this._downloadTemplateExcelButton;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateExcelLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateExcelLabel)) {
                        this._downloadTemplateExcelLabel = {};
                        this._downloadTemplateExcelLabel["alignSelf"] = "center";
                        this._downloadTemplateExcelLabel["marginBottom"] = this._context.theming.measures.measure075;
                    }
                    return this._downloadTemplateExcelLabel;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateButtonLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateButtonLabel)) {
                        this._downloadTemplateButtonLabel = {};
                        this._downloadTemplateButtonLabel["alignSelf"] = "center";
                        this._downloadTemplateButtonLabel["borderWidth"] = "0px";
                        this._downloadTemplateButtonLabel["backgroundColor"] = this._context.theming.colors.basecolor.white;
                        this._downloadTemplateButtonLabel["color"] = "#0063B1";
                        this._downloadTemplateButtonLabel["cursor"] = "pointer";
                    }
                    return this._downloadTemplateButtonLabel;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateContainer)) {
                        this._downloadTemplateContainer = {};
                        this._downloadTemplateContainer["alignSelf"] = "center";
                    }
                    return this._downloadTemplateContainer;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateUploadLater = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateUploadLater)) {
                        this._downloadTemplateUploadLater = {};
                        this._downloadTemplateUploadLater["fontSize"] = "#202200";
                        this._downloadTemplateUploadLater["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._downloadTemplateUploadLater["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._downloadTemplateUploadLater;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplateCheckboxContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplateCheckboxContainer)) {
                        this._downloadTemplateCheckboxContainer = {};
                        this._downloadTemplateCheckboxContainer["display"] = "flex";
                        this._downloadTemplateCheckboxContainer["flexDirection"] = "row";
                        this._downloadTemplateCheckboxContainer["justifyContent"] = "flex-start";
                        this._downloadTemplateCheckboxContainer["bottom"] = "4.5rem";
                        this._downloadTemplateCheckboxContainer["marginTop"] = "100%";
                        this._downloadTemplateCheckboxContainer["position"] = "absolute";
                    }
                    return this._downloadTemplateCheckboxContainer;
                };
                DownloadTemplateControlStyles.prototype.DownloadTemplatePageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._downloadTemplatePageContainer)) {
                        this._downloadTemplatePageContainer = {};
                        this._downloadTemplatePageContainer["flexDirection"] = "column";
                        this._downloadTemplatePageContainer["flex"] = "1 1 auto";
                        this._downloadTemplatePageContainer["margin"] = "0px";
                    }
                    return this._downloadTemplatePageContainer;
                };
                return DownloadTemplateControlStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            DownloadTemplate.DownloadTemplateControlStyles = DownloadTemplateControlStyles;
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DownloadTemplate;
        (function (DownloadTemplate) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "UploadLater", {
                    get: function () {
                        return "UploadLater";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            DownloadTemplate.ResourceKeys = ResourceKeys;
        })(DownloadTemplate = AppCommon.DownloadTemplate || (AppCommon.DownloadTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=DownloadTemplateControl.js.map