var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/microsoft.ajax.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var PersonalSettings;
        (function (PersonalSettings) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            var TimeOptionsUtility = (function () {
                function TimeOptionsUtility() {
                }
                /* Utility function used by createTimeOptionsList */
                TimeOptionsUtility.prototype.zeroFill = function (number, width) {
                    width -= number.toString().length;
                    if (width > 0) {
                        var values;
                        values = new Array(width + (/\./.test(number) ? 2 : 1)).join('0') + number;
                        return values;
                    }
                    return number + ""; // always return a string
                };
                /* Utility function used by createTimeOptionsList to convert 24 Hour Format to 12 Hour Format */
                TimeOptionsUtility.prototype.convert24HrTo12Hr = function (time24Hr, amDesignator, pmDesignator) {
                    var hourEnd = time24Hr.indexOf(":");
                    var hourSubstring = +time24Hr.substr(0, hourEnd);
                    var hourIn12Hour = hourSubstring % 12 || 12;
                    var ampm = hourSubstring < 12 ? amDesignator : pmDesignator;
                    var time12Hr = hourIn12Hour + time24Hr.substr(hourEnd, 3) + " " + ampm;
                    return time12Hr;
                };
                return TimeOptionsUtility;
            }());
            PersonalSettings.TimeOptionsUtility = TimeOptionsUtility;
            var PersonalSettingsControl = (function () {
                /**
                 * Empty constructor.
                 */
                function PersonalSettingsControl() {
                    this._timeZoneList = [];
                    this._calendarOptionsList = [];
                    this._viewOptionsList = [];
                    this._timeOptionsList = [];
                    this._requestsInitiated = 0;
                    this._requestsFulfilled = 0;
                    this._applyStyles = null;
                }
                PersonalSettingsControl.prototype.createSelectorOption = function (key, text) {
                    return { Value: key, Label: text };
                };
                ;
                /* Event Handlers For All Controls*/
                PersonalSettingsControl.prototype.onSaveButtonClicked = function () {
                    this.setUserSettings();
                };
                PersonalSettingsControl.prototype.ontimeZoneChangeHandler = function (response) {
                    this._usersettings.timezonecode = response.Value;
                };
                ;
                PersonalSettingsControl.prototype.onCalendarOptionChangeHandler = function (response) {
                    this._usersettings.defaultcalendarview = response.Value;
                };
                ;
                PersonalSettingsControl.prototype.onPagingValueChangeHandler = function (response) {
                    this._usersettings.paginglimit = response.Value;
                };
                ;
                PersonalSettingsControl.prototype.onStarttimeChangeHandler = function (response) {
                    this._usersettings.workdaystarttime = this._timeOptionsList[response.Value].Time24Hr;
                };
                ;
                PersonalSettingsControl.prototype.onEndtimeChangeHandler = function (response) {
                    this._usersettings.workdaystoptime = this._timeOptionsList[response.Value].Time24Hr;
                };
                ;
                /*
                Time Zone Selection Pick List Options creation
                */
                PersonalSettingsControl.prototype.createTimeZoneList = function () {
                    this._requestsInitiated++;
                    var that = this;
                    var lcid = this._context.userSettings.languageId;
                    if (lcid == null || lcid == undefined) {
                        lcid = 1033;
                    }
                    var timezoneQueryWithLcid = String.format(PersonalSettings.Constants.PersonalSettingsElements.TimezoneFetchQuery, lcid);
                    var c = $.getJSON(this._context.utils.createCrmUri(timezoneQueryWithLcid))
                        .done(function (data) {
                        var timeZoneData = data.value;
                        if (timeZoneData == null || timeZoneData == undefined) {
                            return;
                        }
                        timeZoneData.sort(function (firstOption, secondOption) {
                            if (firstOption.bias != secondOption.bias) {
                                if (firstOption.bias > secondOption.bias)
                                    return -1;
                                else if (firstOption.bias < secondOption.bias)
                                    return 1;
                            }
                            if (firstOption.timezonecode != secondOption.timezonecode) {
                                if (firstOption.timezonecode > secondOption.timezonecode)
                                    return 1;
                                else if (firstOption.timezonecode < secondOption.timezonecode)
                                    return -1;
                            }
                            return 0;
                        });
                        var i;
                        for (i = 0; i < timeZoneData.length; i++) {
                            that._timeZoneList = that._timeZoneList.concat(that.createSelectorOption(timeZoneData[i].timezonecode, String(timeZoneData[i].userinterfacename)));
                        }
                        that._requestsFulfilled++;
                        that._context.utils.requestRender();
                    })
                        .fail(function (data) {
                        console.error(data);
                    });
                };
                /* Time Zone selector in Time Zone section */
                PersonalSettingsControl.prototype.createTimeZoneSelector = function () {
                    var className = PersonalSettings.Constants.PersonalSettingsElements.TimezoneSelectorControlKey;
                    this._timeZoneSelectorProps = {
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimezoneSelectorControlKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimezoneSelectorControlKey,
                        freeTextMode: false,
                        value: { Value: this._usersettings.timezonecode, Color: null },
                        onChange: this.ontimeZoneChangeHandler.bind(this),
                        options: this._timeZoneList,
                        style: this._applyStyles.selectStyle()
                    };
                    this._timeZoneSelector = this._context.factory.createElement("SELECT", this._timeZoneSelectorProps, null);
                };
                PersonalSettingsControl.prototype.createCalendarOptionsList = function () {
                    this._calendarOptionsList.push(this.createSelectorOption(0, this._context.resources.getString(PersonalSettings.ResourceKeys.Day)));
                    this._calendarOptionsList.push(this.createSelectorOption(1, this._context.resources.getString(PersonalSettings.ResourceKeys.Week)));
                    this._calendarOptionsList.push(this.createSelectorOption(2, this._context.resources.getString(PersonalSettings.ResourceKeys.Month)));
                };
                /* Calendar View Selector Picklist */
                PersonalSettingsControl.prototype.createCalendarOptionSelector = function () {
                    var calendarSelectorProps = {
                        id: PersonalSettings.Constants.PersonalSettingsElements.CalendarSelectorControlKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.CalendarSelectorControlKey,
                        freeTextMode: false,
                        onChange: this.onCalendarOptionChangeHandler.bind(this),
                        value: { Value: this._usersettings.defaultcalendarview },
                        options: this._calendarOptionsList,
                        style: this._applyStyles.selectStyle()
                    };
                    this._calendarViewSelector = this._context.factory.createElement("SELECT", calendarSelectorProps, null);
                };
                ;
                PersonalSettingsControl.prototype.getMappedValueForUserTime = function (userTime) {
                    var index;
                    for (index = 0; index < this._timeOptionsList.length; index++) {
                        if (this._timeOptionsList[index].Time24Hr === userTime)
                            return this._timeOptionsList[index].Value;
                    }
                };
                /* This function generates all the options for StartTimeOptions Control and EndTimeOptions Control.
                Options are stored as key value pair of 24 hour format and 12 Hour format*/
                PersonalSettingsControl.prototype.createTimeOptionsList = function () {
                    var is24HourFormat = false;
                    var amDesignator = this._context.userSettings.dateFormattingInfo.AMDesignator;
                    var pmDesignator = this._context.userSettings.dateFormattingInfo.PMDesignator;
                    is24HourFormat = (this._context.userSettings.dateFormattingInfo.ShortTimePattern.charAt(0) == "H") ? true : false;
                    for (var i = 0, index = 0; i < 24; i++) {
                        var hourOption24Hr1 = this._timeOptionsUtility.zeroFill(i, 2) + ":00";
                        var hourOption12Hr1 = this._timeOptionsUtility.convert24HrTo12Hr(hourOption24Hr1, amDesignator, pmDesignator);
                        var optionParameter = {
                            Label: is24HourFormat ? hourOption24Hr1 : hourOption12Hr1,
                            Value: index,
                            Time24Hr: hourOption24Hr1
                        };
                        this._timeOptionsList.push(optionParameter);
                        index++;
                        var hourOption24Hr2 = this._timeOptionsUtility.zeroFill(i, 2) + ":30";
                        var hourOption12Hr2 = this._timeOptionsUtility.convert24HrTo12Hr(hourOption24Hr2, amDesignator, pmDesignator);
                        var optionParameter2 = {
                            Label: is24HourFormat ? hourOption24Hr2 : hourOption12Hr2,
                            Value: index++,
                            Time24Hr: hourOption24Hr2
                        };
                        this._timeOptionsList.push(optionParameter2);
                    }
                };
                /* start Time Selector in calendar Section */
                PersonalSettingsControl.prototype.createStartTimeSelector = function () {
                    var className = PersonalSettings.Constants.PersonalSettingsElements.StartTimeSelectorControlKey;
                    var startTimeSelectorProps = {
                        id: PersonalSettings.Constants.PersonalSettingsElements.StartTimeSelectorControlKey,
                        className: className,
                        freeTextMode: false,
                        onChange: this.onStarttimeChangeHandler.bind(this),
                        value: { Value: this.getMappedValueForUserTime(this._usersettings.workdaystarttime) },
                        options: this._timeOptionsList,
                        style: this._applyStyles.selectStyle(),
                        accessibilityLabel: this._context.resources.getString(PersonalSettings.ResourceKeys.TimeSubHeader) + ":" +
                            this._context.resources.getString(PersonalSettings.ResourceKeys.StartTime)
                    };
                    this._startTimeSelector = this._context.factory.createElement("SELECT", startTimeSelectorProps);
                };
                /* End Time Selector in Calendar Section */
                PersonalSettingsControl.prototype.createEndTimeSelector = function () {
                    var className = PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorControlKey;
                    var endTimeSelectorProps = {
                        id: PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorControlKey,
                        className: className,
                        freeTextMode: false,
                        onChange: this.onEndtimeChangeHandler.bind(this),
                        value: { Value: this.getMappedValueForUserTime(this._usersettings.workdaystoptime) },
                        options: this._timeOptionsList,
                        style: this._applyStyles.selectStyle(),
                        accessibilityLabel: this._context.resources.getString(PersonalSettings.ResourceKeys.TimeSubHeader) + ":" +
                            this._context.resources.getString(PersonalSettings.ResourceKeys.EndTime)
                    };
                    this._stopTimeSelector = this._context.factory.createElement("SELECT", endTimeSelectorProps);
                };
                PersonalSettingsControl.prototype.createViewOptionsList = function () {
                    this._viewOptionsList.push(this.createSelectorOption(25, "25"));
                    this._viewOptionsList.push(this.createSelectorOption(50, "50"));
                    this._viewOptionsList.push(this.createSelectorOption(75, "75"));
                    this._viewOptionsList.push(this.createSelectorOption(100, "100"));
                    this._viewOptionsList.push(this.createSelectorOption(250, "250"));
                };
                /* Paging Control in Record/List View Section*/
                PersonalSettingsControl.prototype.createPagingSelector = function () {
                    var pagingSelectorProps = {
                        id: PersonalSettings.Constants.PersonalSettingsElements.PagingSelectorControlKey,
                        className: PersonalSettings.Constants.PersonalSettingsElements.PagingSelectorControlKey,
                        freeTextMode: false,
                        value: { Value: this._usersettings.paginglimit },
                        onChange: this.onPagingValueChangeHandler.bind(this),
                        options: this._viewOptionsList,
                        style: this._applyStyles.selectStyle()
                    };
                    this._pagingSelector = this._context.factory.createElement("SELECT", pagingSelectorProps);
                };
                /* Save Button, Icon and Separatot creation */
                PersonalSettingsControl.prototype.createSaveButtonContainer = function () {
                    var saveButtonLabel = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.SaveButtonLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.SaveButtonLabelKey,
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.Save));
                    var saveIconContainer = this._context.factory.createElement("CONTAINER", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.SaveIconContainerKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.SaveIconContainerKey,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var saveButton = this._context.factory.createElement("BUTTON", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.SaveButtonKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.SaveButtonKey,
                        tabIndex: 0,
                        style: this._applyStyles.PS_saveButton_FREHeaderRightButtonStyle(),
                        onClick: this.onSaveButtonClicked.bind(this)
                    }, [saveIconContainer, saveButtonLabel]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.HeaderSeparatorContainerKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.HeaderSeparatorContainerKey,
                        style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.SaveButtonContainerKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.SaveButtonContainerKey,
                        style: this._applyStyles.PS_FRESaveButtonContainer()
                    }, [headerSeparatorContainer, saveButton]);
                    return headerRightContainer;
                };
                PersonalSettingsControl.prototype.actionFailedCallback = function (error) {
                    this._requestsFulfilled++;
                    // TODO: Add failure notification
                };
                PersonalSettingsControl.prototype.updateActionFailedCallback = function (error) {
                    this._requestsFulfilled++;
                    // TODO: Add failure notification
                };
                PersonalSettingsControl.prototype.retrieveUserSettings = function () {
                    var _this = this;
                    this._requestsInitiated++;
                    this._currentUserId = this._context.userSettings.userId;
                    this._currentUserId = this._currentUserId.replace(/[{}]/g, '');
                    var selectString = "?$select=paginglimit,defaultcalendarview,workdaystarttime,workdaystoptime,timezonecode";
                    this._context.webAPI.retrieveRecord("usersettings", this._currentUserId, selectString).then(function (retrieveResponse) {
                        _this._usersettings.timezonecode = retrieveResponse.timezonecode;
                        _this._usersettings.paginglimit = retrieveResponse.paginglimit;
                        _this._usersettings.defaultcalendarview = retrieveResponse.defaultcalendarview;
                        _this._usersettings.workdaystarttime = retrieveResponse.workdaystarttime;
                        _this._usersettings.workdaystoptime = retrieveResponse.workdaystoptime;
                        _this._requestsFulfilled++;
                        _this._context.utils.requestRender();
                    }, this.actionFailedCallback);
                };
                PersonalSettingsControl.prototype.setUserSettings = function () {
                    var that = this;
                    this._context.webAPI.updateRecord("usersettings", this._currentUserId, {
                        timezonecode: this._usersettings.timezonecode,
                        paginglimit: this._usersettings.paginglimit,
                        defaultcalendarview: this._usersettings.defaultcalendarview,
                        workdaystarttime: this._usersettings.workdaystarttime,
                        workdaystoptime: this._usersettings.workdaystoptime
                    }).then(function (retrieveResponse) {
                        //all ok - settings saved successfully.
                        var successNoticationMessage = that._context.resources.getString(PersonalSettings.ResourceKeys.Save_Successful_Notification);
                        that._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, successNoticationMessage, "", null).then(function (response) {
                            //Notification displayed successfully
                        }, function (error) {
                            console.error("Error displaying notification : " + error);
                        });
                        that._context.utils.requestRender();
                    }, this.updateActionFailedCallback);
                };
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params _context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                PersonalSettingsControl.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    var title = this._context.resources.getString(PersonalSettings.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(PersonalSettings.ResourceKeys.PersonalisationSettingHeader) + " - " + this._context.resources.getString(PersonalSettings.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(this._context, title); //Needed only for perf marker
                    this._applyStyles = new PersonalSettings.PersonalSettingStyles(this._context);
                    this._timeOptionsUtility = new TimeOptionsUtility();
                    this._usersettings = {
                        paginglimit: PersonalSettings.Constants.PersonalSettingsElements.EMPTYNUMBER,
                        defaultcalendarview: PersonalSettings.Constants.PersonalSettingsElements.EMPTYNUMBER,
                        workdaystarttime: PersonalSettings.Constants.PersonalSettingsElements.EMPTY,
                        workdaystoptime: PersonalSettings.Constants.PersonalSettingsElements.EMPTY,
                        timezonecode: PersonalSettings.Constants.PersonalSettingsElements.EMPTYNUMBER
                    };
                    this.createTimeZoneList();
                    this.createTimeOptionsList();
                    this.createCalendarOptionsList();
                    this.createViewOptionsList();
                    this.retrieveUserSettings();
                    //register event to handle Ctrl + S keyboard event
                    this.controlPlusSEventHanlder();
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                PersonalSettingsControl.prototype.updateView = function (_context) {
                    /* Code Structure
                    |----personalSettingsPageContainer
                        |----headerContainer
                            |----settingsHeader
                        |----saveButtonConatiner
                            |----headerSeparatorContainer
                            |----saveButton
                        |----timezoneSectionContainer
                            |----timeZoneHeaderContainer
                                |----timezoneSectionHeader
                            |----timeZoneSelectorContainer
                                |----timezoneDescLable
                                |----timezonecomboContainer
                        |----calendarSectionContainer
                            |----calendarHeaderContainer
                                |----calendarSectionHeader
                            |----calendarViewSelectorContainer
                            |----defWorkHoursLbl
                            |----timeSelectorContainer
                                |----startTimeSelectorContainer
                                    |----startTimeLbl
                                    |----startTimeOptionsContainer
                                |----endTimeSelectorContainer
                                    |----endTimeLbl
                                    |----endTimeOptionscontainer
                        |----viewSectionContainer
                            |----viewHeaderContainer
                                |----viewSectionHeader
                            |----viewdescLbl
                            |----pagingSelectorContainer
                                |----pagingOptionsContainer
                                |----recperpagelbl
                    */
                    /* Create Top Header Elements: Header */
                    var settingsHeader = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.settingsHeaderKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.settingsHeaderKey,
                        style: this._applyStyles.PS_settingsheader()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.PersonalisationSettingHeader));
                    /* Create Save Container which will have the Separator, Save Icon, Save button */
                    var saveButtonContainer = this.createSaveButtonContainer();
                    /* Create Calendar, TimeZone, View Section Header Labels */
                    var timeZoneSectionHeader = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneSectionHeaderKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneSectionHeaderKey,
                        style: this._applyStyles.PS_SectionHeader()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.TimeZoneHeader));
                    var calendarSectionHeader = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.CalendarSectionHeaderKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.CalendarSectionHeaderKey,
                        style: this._applyStyles.PS_SectionHeader()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.CalendarHeader));
                    var viewSectionHeader = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.ViewSectionHeaderKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.ViewSectionHeaderKey,
                        style: this._applyStyles.PS_SectionHeader()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.ViewHeader));
                    /* Create Containers For Section Labels */
                    var timeZoneHeaderContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneHeaderContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneHeaderContainerKey,
                        style: this._applyStyles.PS_HeaderContainer()
                    }, [timeZoneSectionHeader]);
                    var calendarHeaderContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.CalendarHeaderContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.CalendarHeaderContainerKey,
                        style: this._applyStyles.PS_HeaderContainer()
                    }, [calendarSectionHeader]);
                    var viewHeaderContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.ViewHeaderContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.ViewHeaderContainerKey,
                        style: this._applyStyles.PS_HeaderContainer()
                    }, [viewSectionHeader]);
                    /* Create Various Field Labels */
                    var timeZoneDescLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneDescFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneDescFieldLabelKey,
                        style: this._applyStyles.PS_timeZoneDescFieldLabel(),
                        forElementId: this._context.accessibility.getUniqueId(PersonalSettings.Constants.PersonalSettingsElements.TimezoneSelectorControlKey)
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.TimeZoneSubHeader));
                    var calDefDescLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.CalDefDescFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.CalDefDescFieldLabelKey,
                        style: this._applyStyles.PS_calDefDescFieldLabel(),
                        forElementId: this._context.accessibility.getUniqueId(PersonalSettings.Constants.PersonalSettingsElements.CalendarSelectorControlKey)
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.CalendarSubHeader));
                    var defWorkHoursLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.DefWorkHoursFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.DefWorkHoursFieldLabelKey,
                        style: this._applyStyles.PS_defWorkHoursFieldLabel()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.TimeSubHeader));
                    var startTimeLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.StartTimeFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.StartTimeFieldLabelKey,
                        style: this._applyStyles.PS_startTimeFieldLabel(),
                        forElementId: this._context.accessibility.getUniqueId(PersonalSettings.Constants.PersonalSettingsElements.StartTimeSelectorControlKey)
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.StartTime));
                    var endTimeLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.EndTimeFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.EndTimeFieldLabelKey,
                        style: this._applyStyles.PS_endTimeFieldLabel(),
                        forElementId: this._context.accessibility.getUniqueId(PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorControlKey)
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.EndTime));
                    var viewdescLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.ViewdescFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.ViewdescFieldLabelKey,
                        style: this._applyStyles.PS_viewdescFieldLabel()
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.ViewSubHeader));
                    var recperpageLbl = this._context.factory.createElement("LABEL", {
                        key: PersonalSettings.Constants.PersonalSettingsElements.RecperpageFieldLabelKey,
                        id: PersonalSettings.Constants.PersonalSettingsElements.RecperpageFieldLabelKey,
                        style: this._applyStyles.PS_recperpageFieldLabel(),
                        forElementId: this._context.accessibility.getUniqueId(PersonalSettings.Constants.PersonalSettingsElements.PagingSelectorControlKey)
                    }, this._context.resources.getString(PersonalSettings.ResourceKeys.RecordsPerPage));
                    /* Create Select Controls when appropriate data is available */
                    if (this._usersettings.timezonecode != PersonalSettings.Constants.PersonalSettingsElements.EMPTYNUMBER &&
                        this._timeZoneList.length != 0) {
                        this.createTimeZoneSelector();
                    }
                    if (this._usersettings.defaultcalendarview != PersonalSettings.Constants.PersonalSettingsElements.EMPTYNUMBER) {
                        this.createCalendarOptionSelector();
                    }
                    if (this._usersettings.paginglimit != PersonalSettings.Constants.PersonalSettingsElements.EMPTYNUMBER) {
                        this.createPagingSelector();
                    }
                    if (this._usersettings.workdaystarttime != PersonalSettings.Constants.PersonalSettingsElements.EMPTY) {
                        this.createStartTimeSelector();
                    }
                    if (this._usersettings.workdaystoptime != PersonalSettings.Constants.PersonalSettingsElements.EMPTY) {
                        this.createEndTimeSelector();
                    }
                    /* Create Various Selector Containers */
                    /* TimeZone */
                    var timeZoneOptionsContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneOptionsContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneOptionsContainerKey
                    }, [this._timeZoneSelector]);
                    var timeZoneSelectorContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneSelectorContainerKey,
                        style: this._applyStyles.TimeZoneSelectorContainer()
                    }, [timeZoneDescLbl, timeZoneOptionsContainer]);
                    /* Calendar */
                    var calendarOptionsContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.CalendarOptionsContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.CalendarOptionsContainerKey,
                        style: this._applyStyles.CalendarOptionsContainer()
                    }, [this._calendarViewSelector]);
                    timeZoneOptionsContainer;
                    var calendarViewSelectorContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.calendarViewSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.calendarViewSelectorContainerKey,
                        style: this._applyStyles.CalendarViewSelectorContainer()
                    }, [calDefDescLbl, calendarOptionsContainer]);
                    /* Start Time */
                    var startTimeOptionsContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.StartTimeOptionsContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.StartTimeOptionsContainerKey
                    }, [this._startTimeSelector]);
                    var startTimeSelectorContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.StartTimeSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.StartTimeSelectorContainerKey,
                        style: this._applyStyles.StartTimeSelectorContainer()
                    }, [startTimeLbl, startTimeOptionsContainer]);
                    /* end Time */
                    var endTimeOptionsContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorContainerKey
                    }, [this._stopTimeSelector]);
                    var endTimeSelectorContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.EndTimeSelectorContainerKey,
                        style: this._applyStyles.EndTimeSelectorContainer()
                    }, [endTimeLbl, endTimeOptionsContainer]);
                    /* Time Selector */
                    var timeSelectorContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeSelectorContainerKey,
                        style: this._applyStyles.TimeSelectorContainer()
                    }, [startTimeSelectorContainer, endTimeSelectorContainer]);
                    /* Paging Selector Box */
                    var pagingOptionsContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.PagingSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.PagingOptionsContainerKey,
                        style: this._applyStyles.PagingComboContainer()
                    }, [this._pagingSelector]);
                    var pagingSelectorContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.PagingSelectorContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.PagingSelectorContainerKey,
                        style: this._applyStyles.PagingSelectorContainer()
                    }, [pagingOptionsContainer, recperpageLbl]);
                    /* Create Containers for Sections Header, timezone, calendar, view */
                    var headerContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.HeadingContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.HeadingContainerKey,
                        style: this._applyStyles.PS_FREheadingContainer()
                    }, [settingsHeader]);
                    var timeZoneSectionContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneSectionContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.TimeZoneSectionContainerKey,
                        style: this._applyStyles.PS_SectionContainer()
                    }, [timeZoneHeaderContainer, timeZoneSelectorContainer]);
                    var calendarSectionContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.CalendarSectionContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.CalendarSectionContainerKey,
                        style: this._applyStyles.PS_SectionContainer()
                    }, [calendarHeaderContainer, calendarViewSelectorContainer, defWorkHoursLbl, timeSelectorContainer]);
                    var viewSectionContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.ViewSectionContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.ViewSectionContainerKey,
                        style: this._applyStyles.PS_SectionContainer()
                    }, [viewHeaderContainer, viewdescLbl, pagingSelectorContainer]);
                    /* Create Main Page Container */
                    var personalSettingsPageContainer = this._context.factory.createElement("CONTAINER", {
                        id: PersonalSettings.Constants.PersonalSettingsElements.PersonalSettingsPageContainerKey,
                        key: PersonalSettings.Constants.PersonalSettingsElements.PersonalSettingsPageContainerKey,
                        style: this._applyStyles.PS_FREPageContainer()
                    }, [headerContainer, saveButtonContainer, timeZoneSectionContainer, calendarSectionContainer, viewSectionContainer]);
                    if (this._freShell != null && this._requestsInitiated > 0 && this._requestsFulfilled === this._requestsInitiated) {
                        this._freShell.stopPerformanceStopWatch();
                    }
                    return personalSettingsPageContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                PersonalSettingsControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                PersonalSettingsControl.prototype.destroy = function () {
                };
                /**
                * This function handles Ctrl+S keyboard event to trigger save event
                */
                PersonalSettingsControl.prototype.controlPlusSEventHanlder = function () {
                    var that = this;
                    this._context.accessibility.registerShortcut([17 /* Ctrl */, 83 /* S */], function (event) {
                        event.preventDefault();
                        if (!event.ctrlKey || event.keyCode !== 83 /* S */) {
                            return;
                        }
                        that.onSaveButtonClicked();
                    }, true, "", "");
                };
                return PersonalSettingsControl;
            }());
            PersonalSettings.PersonalSettingsControl = PersonalSettingsControl;
        })(PersonalSettings = AppCommon.PersonalSettings || (AppCommon.PersonalSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="PersonalSettings.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: ProductCatalogStrings contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var PersonalSettings;
        (function (PersonalSettings) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                return Constants;
            }());
            PersonalSettings.Constants = Constants;
            (function (Constants) {
                var PersonalSettingsElements = (function () {
                    function PersonalSettingsElements() {
                    }
                    Object.defineProperty(PersonalSettingsElements, "EMPTY", {
                        get: function () {
                            return "EMPTY";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "EMPTYNUMBER", {
                        get: function () {
                            return -1;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimezoneFetchQuery", {
                        get: function () {
                            return "/api/data/v9.0/timezonedefinitions/Microsoft.Dynamics.CRM.GetAllTimeZonesWithDisplayName(LocaleId={0})";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "PersonalSettingsPageContainerKey", {
                        /* Main Page Container */
                        get: function () {
                            return "PS_FREPageContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "HeadingContainerKey", {
                        /* Heading conatiner enclosing "Personal Settings heading and close */
                        get: function () {
                            return "PS_FREheadingContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "settingsHeaderKey", {
                        /* Main Heading Key i.e "Personal Settings" */
                        get: function () {
                            return "PS_settingsheader";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "SaveButtonContainerKey", {
                        /* Save button container enclosing Separator, Save Icon, Save Button */
                        get: function () {
                            return "PS_FRESaveButtonContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "HeaderSeparatorContainerKey", {
                        get: function () {
                            return "PS_FREHeaderSeparatorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "SaveButtonKey", {
                        get: function () {
                            return "PS_saveButton_FREHeaderRightButtonStyle";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "SaveButtonLabelKey", {
                        get: function () {
                            return "PS_Save_FREHeaderRightButtonsLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "SaveIconContainerKey", {
                        get: function () {
                            return "PS_FRESaveIconContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeZoneSectionContainerKey", {
                        /* Section containers for timezone, calendar and view */
                        get: function () {
                            return "timeZone_PS_SectionContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "CalendarSectionContainerKey", {
                        get: function () {
                            return "calendar_PS_SectionContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "ViewSectionContainerKey", {
                        get: function () {
                            return "view_PS_SectionContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeZoneHeaderContainerKey", {
                        /* Containers for header of timezone, calendar, view section */
                        get: function () {
                            return "timeZone_PS_HeaderContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "CalendarHeaderContainerKey", {
                        get: function () {
                            return "calendar_PS_HeaderContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "ViewHeaderContainerKey", {
                        get: function () {
                            return "view_PS_HeaderContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeZoneSectionHeaderKey", {
                        /*Section Header Label : TimeZone, Calendar, Records/List View*/
                        get: function () {
                            return "timeZone_PS_SectionHeader";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "CalendarSectionHeaderKey", {
                        get: function () {
                            return "calendar_PS_SectionHeader";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "ViewSectionHeaderKey", {
                        get: function () {
                            return "view_PS_SectionHeader";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "closeFREPrimaryButtonKey", {
                        /* Close button */
                        get: function () {
                            return "PS_closeFRESecondaryButton";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "closeButtonContainerKey", {
                        get: function () {
                            return "PS_closeButtonContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeZoneDescFieldLabelKey", {
                        /* Various Labels being used across the screen */
                        get: function () {
                            return "PS_timeZoneDescFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "CalDefDescFieldLabelKey", {
                        get: function () {
                            return "PS_calDefDescFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "DefWorkHoursFieldLabelKey", {
                        get: function () {
                            return "PS_defWorkHoursFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "StartTimeFieldLabelKey", {
                        get: function () {
                            return "PS_startTimeFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "EndTimeFieldLabelKey", {
                        get: function () {
                            return "PS_endTimeFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "ViewdescFieldLabelKey", {
                        get: function () {
                            return "PS_viewdescFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "RecperpageFieldLabelKey", {
                        get: function () {
                            return "PS_recperpageFieldLabel";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "StartTimeSelectorControlKey", {
                        /* Selector boxes related keys */
                        get: function () {
                            return "PS_starttimeselector-selectcontrol";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "EndTimeSelectorControlKey", {
                        get: function () {
                            return "PS_endtimeselector-selectcontrol";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "PagingSelectorControlKey", {
                        get: function () {
                            return "PS_pagingselector-selectcontrol";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "CalendarSelectorControlKey", {
                        get: function () {
                            return "PS_calendarselector-selectcontrol";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimezoneSelectorControlKey", {
                        get: function () {
                            return "PS_timezoneselector-selectcontrol";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeZoneOptionsContainerKey", {
                        get: function () {
                            return "timeZoneOptionsContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeZoneSelectorContainerKey", {
                        get: function () {
                            return "timeZoneSelectorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "CalendarOptionsContainerKey", {
                        get: function () {
                            return "calendarOptionsContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "calendarViewSelectorContainerKey", {
                        get: function () {
                            return "calendarViewSelectorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "StartTimeOptionsContainerKey", {
                        get: function () {
                            return "startTimeOptionsContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "StartTimeSelectorContainerKey", {
                        get: function () {
                            return "startTimeSelectorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "EndTimeOptionsContainerKey", {
                        get: function () {
                            return "endTimeOptionsContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "EndTimeSelectorContainerKey", {
                        get: function () {
                            return "endTimeSelectorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "TimeSelectorContainerKey", {
                        get: function () {
                            return "timeSelectorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "PagingOptionsContainerKey", {
                        get: function () {
                            return "pagingOptionsContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(PersonalSettingsElements, "PagingSelectorContainerKey", {
                        get: function () {
                            return "pagingSelectorContainer";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    return PersonalSettingsElements;
                }());
                Constants.PersonalSettingsElements = PersonalSettingsElements;
            })(Constants = PersonalSettings.Constants || (PersonalSettings.Constants = {}));
        })(PersonalSettings = AppCommon.PersonalSettings || (AppCommon.PersonalSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var PersonalSettings;
        (function (PersonalSettings) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "PersonalisationSettingHeader", {
                    get: function () {
                        return "PersonalisationSettingHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "TimeZoneHeader", {
                    get: function () {
                        return "TimeZoneHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "CalendarHeader", {
                    get: function () {
                        return "CalendarHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ViewHeader", {
                    get: function () {
                        return "ViewHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "TimeZoneSubHeader", {
                    get: function () {
                        return "TimeZoneSubHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "CalendarSubHeader", {
                    get: function () {
                        return "CalendarSubHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "TimeSubHeader", {
                    get: function () {
                        return "TimeSubHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ViewSubHeader", {
                    get: function () {
                        return "ViewSubHeader";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "StartTime", {
                    get: function () {
                        return "StartTime";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "EndTime", {
                    get: function () {
                        return "EndTime";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RecordsPerPage", {
                    get: function () {
                        return "RecordsPerPage";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmDialogButtonText", {
                    get: function () {
                        return "ConfirmDialogButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RemoveButtonText", {
                    get: function () {
                        return "RemoveButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Day", {
                    get: function () {
                        return "Day";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Week", {
                    get: function () {
                        return "Week";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Month", {
                    get: function () {
                        return "Month";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Save", {
                    get: function () {
                        return "Save";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Close", {
                    get: function () {
                        return "Close";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Save_Successful_Notification", {
                    get: function () {
                        return "Save_Successful_Notification";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Error_StartTimeMustBeEarlierThanEndTime", {
                    get: function () {
                        return "Error_StartTimeMustBeEarlierThanEndTime";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            PersonalSettings.ResourceKeys = ResourceKeys;
        })(PersonalSettings = AppCommon.PersonalSettings || (AppCommon.PersonalSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var PersonalSettings;
        (function (PersonalSettings) {
            'use strict';
            var PersonalSettingStyles = (function (_super) {
                __extends(PersonalSettingStyles, _super);
                function PersonalSettingStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._pS_FREPageContainer = {};
                    _this._pS_FREheadingContainer = {};
                    _this._pS_settingsheader = {};
                    _this._pS_FRESaveButtonContainer = {};
                    _this._pS_saveButton_FREHeaderRightButtonStyle = {};
                    _this._pS_SectionContainer = {};
                    _this._pS_HeaderContainer = {};
                    _this._pS_SectionHeader = {};
                    _this._pS_timeZoneDescFieldLabel = {};
                    _this._pS_calDefDescFieldLabel = {};
                    _this._pS_defWorkHoursFieldLabel = {};
                    _this._pS_FieldLabel = {};
                    _this._pS_startTimeFieldLabel = {};
                    _this._pS_endTimeFieldLabel = {};
                    _this._pS_viewdescFieldLabel = {};
                    _this._pS_recperpageFieldLabel = {};
                    _this._selectorCombobox = {};
                    _this._selectorContainer = {};
                    _this._timeZoneSelectorContainer = {};
                    _this._calendarViewSelectorContainer = {};
                    _this._timeSelectorContainer = {};
                    _this._startTimeSelectorContainer = {};
                    _this._endTimeSelectorContainer = {};
                    _this._pagingSelectorContainer = {};
                    _this._pagingComboContainer = {};
                    _this._calendarOptionsContainer = {};
                    _this._context = context;
                    _this._pS_FREPageContainer = null;
                    _this._pS_FREheadingContainer = null;
                    _this._pS_settingsheader = null;
                    _this._pS_FRESaveButtonContainer = null;
                    _this._pS_saveButton_FREHeaderRightButtonStyle = null;
                    _this._pS_SectionContainer = null;
                    _this._pS_HeaderContainer = null;
                    _this._pS_SectionHeader = null;
                    _this._pS_timeZoneDescFieldLabel = null;
                    _this._pS_calDefDescFieldLabel = null;
                    _this._pS_defWorkHoursFieldLabel = null;
                    _this._pS_FieldLabel = null;
                    _this._pS_startTimeFieldLabel = null;
                    _this._pS_endTimeFieldLabel = null;
                    _this._pS_viewdescFieldLabel = null;
                    _this._pS_recperpageFieldLabel = null;
                    _this._selectorCombobox = null;
                    _this._selectorContainer = null;
                    _this._timeZoneSelectorContainer = null;
                    _this._calendarViewSelectorContainer = null;
                    _this._timeSelectorContainer = null;
                    _this._startTimeSelectorContainer = null;
                    _this._endTimeSelectorContainer = null;
                    _this._pagingSelectorContainer = null;
                    _this._pagingComboContainer = null;
                    _this._calendarOptionsContainer = null;
                    return _this;
                }
                /***** Personal Settings Main Page Container*****/
                PersonalSettingStyles.prototype.PS_FREPageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_FREPageContainer)) {
                        this._pS_FREPageContainer = {};
                        this._pS_FREPageContainer["display"] = "block";
                        this._pS_FREPageContainer["justifyContent"] = "flex-start";
                        this._pS_FREPageContainer["width"] = "100%";
                    }
                    return this._pS_FREPageContainer;
                };
                /* Heading container enclosing "Personal Settings heading */
                PersonalSettingStyles.prototype.PS_FREheadingContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_FREheadingContainer)) {
                        this._pS_FREheadingContainer = {};
                        this._pS_FREheadingContainer["display"] = "flex";
                        this._pS_FREheadingContainer["flexDirection"] = "row";
                        this._pS_FREheadingContainer["justifyContent"] = "space-between";
                        this._pS_FREheadingContainer["marginLeft"] = this._context.theming.measures.measure150;
                        this._pS_FREheadingContainer["marginRight"] = this._context.theming.measures.measure150;
                        this._pS_FREheadingContainer["alignItems"] = "center";
                    }
                    return this._pS_FREheadingContainer;
                };
                /* Main heading styling i.e. Personal Settings*/
                PersonalSettingStyles.prototype.PS_settingsheader = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_settingsheader)) {
                        this._pS_settingsheader = {};
                        this._pS_settingsheader["fontFamily"] = this._context.theming.fontfamilies.semilight;
                        this._pS_settingsheader["fontSize"] = this._context.theming.fontsizes.font150;
                        this._pS_settingsheader["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._pS_settingsheader["lineHeight"] = "1.8rem";
                        this._pS_settingsheader["letterSpacing"] = "0rem";
                        this._pS_settingsheader["marginTop"] = this._context.theming.measures.measure075;
                        this._pS_settingsheader["marginBottom"] = this._context.theming.measures.measure200;
                    }
                    return this._pS_settingsheader;
                };
                /***** Save Button Container enclosing Separator, Save Icon, Save Button*****/
                PersonalSettingStyles.prototype.PS_FRESaveButtonContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_FRESaveButtonContainer)) {
                        this._pS_FRESaveButtonContainer = {};
                        this._pS_FRESaveButtonContainer["display"] = "flex";
                        this._pS_FRESaveButtonContainer["justifyContent"] = "flex-end";
                        this._pS_FRESaveButtonContainer["marginLeft"] = this._context.theming.measures.measure150;
                        this._pS_FRESaveButtonContainer["marginRight"] = this._context.theming.measures.measure150;
                        this._pS_FRESaveButtonContainer["paddingBottom"] = this._context.theming.measures.measure025;
                        this._pS_FRESaveButtonContainer["width"] = "96.9%";
                        this._pS_FRESaveButtonContainer["borderBottom"] = "0.1rem solid #CCCCCC";
                    }
                    return this._pS_FRESaveButtonContainer;
                };
                PersonalSettingStyles.prototype.PS_saveButton_FREHeaderRightButtonStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_saveButton_FREHeaderRightButtonStyle)) {
                        this._pS_saveButton_FREHeaderRightButtonStyle = {};
                        this._pS_saveButton_FREHeaderRightButtonStyle = this.FREHeaderRightButtonStyle();
                        this._pS_saveButton_FREHeaderRightButtonStyle["margin"] = "0rem";
                        this._pS_saveButton_FREHeaderRightButtonStyle["marginLeft"] = this._context.theming.measures.measure075;
                    }
                    return this._pS_saveButton_FREHeaderRightButtonStyle;
                };
                /**** Section Container for TimeZone, Calendar, View *****/
                PersonalSettingStyles.prototype.PS_SectionContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_SectionContainer)) {
                        this._pS_SectionContainer = {};
                        this._pS_SectionContainer["display"] = "flex";
                        this._pS_SectionContainer["flexDirection"] = "column";
                        this._pS_SectionContainer["borderRadius"] = "0rem";
                        this._pS_SectionContainer["border"] = "1px solid #CCCCCC";
                        this._pS_SectionContainer["width"] = "96.9%";
                        this._pS_SectionContainer["marginLeft"] = this._context.theming.measures.measure150;
                        this._pS_SectionContainer["marginRight"] = this._context.theming.measures.measure150;
                        this._pS_SectionContainer["marginTop"] = this._context.theming.measures.measure075;
                        this._pS_SectionContainer["paddingBottom"] = this._context.theming.measures.measure075;
                        this._pS_SectionContainer["backgroundColor"] = this._context.theming.colors.basecolor.white;
                        this._pS_SectionContainer["width"] = "96.9%";
                    }
                    return this._pS_SectionContainer;
                };
                /***** Header Container for TimeZone, Calendar and Paging Options ****/
                PersonalSettingStyles.prototype.PS_HeaderContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_HeaderContainer)) {
                        this._pS_HeaderContainer = {};
                        this._pS_HeaderContainer["display"] = "flex";
                        this._pS_HeaderContainer["flexDirection"] = "row";
                        this._pS_HeaderContainer["backgroundColor"] = this._context.theming.colors.basecolor.grey.grey1;
                        this._pS_HeaderContainer["borderRadius"] = "0rem";
                        this._pS_HeaderContainer["borderBottom"] = "0.1px solid #CCCCCC";
                        this._pS_HeaderContainer["justifyContent"] = "space-between";
                    }
                    return this._pS_HeaderContainer;
                };
                /***** Section Header Label : TimeZone, Calendar, Records/List View */
                PersonalSettingStyles.prototype.PS_SectionHeader = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_SectionHeader)) {
                        this._pS_SectionHeader = {};
                        this._pS_SectionHeader["fontSize"] = this._context.theming.fontsizes.font100;
                        this._pS_SectionHeader["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._pS_SectionHeader["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        this._pS_SectionHeader["lineHeight"] = "1.2rem";
                        this._pS_SectionHeader["letterSpacing"] = "0rem";
                        this._pS_SectionHeader["marginLeft"] = this._context.theming.measures.measure075;
                        this._pS_SectionHeader["marginTop"] = this._context.theming.measures.measure075;
                        this._pS_SectionHeader["marginBottom"] = this._context.theming.measures.measure075;
                        this._pS_SectionHeader["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._pS_SectionHeader;
                };
                /**** For various text being used in PS FRE Screen ****/
                PersonalSettingStyles.prototype.PS_timeZoneDescFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_timeZoneDescFieldLabel)) {
                        this._pS_timeZoneDescFieldLabel = {};
                        this._pS_timeZoneDescFieldLabel["paddingTop"] = this._context.theming.measures.measure075;
                        this._pS_timeZoneDescFieldLabel["paddingBottom"] = this._context.theming.measures.measure025;
                    }
                    return this._pS_timeZoneDescFieldLabel;
                };
                PersonalSettingStyles.prototype.PS_calDefDescFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_calDefDescFieldLabel)) {
                        this._pS_calDefDescFieldLabel = {};
                        this._pS_calDefDescFieldLabel["paddingTop"] = this._context.theming.measures.measure075;
                        this._pS_calDefDescFieldLabel["paddingBottom"] = this._context.theming.measures.measure025;
                    }
                    return this._pS_calDefDescFieldLabel;
                };
                PersonalSettingStyles.prototype.PS_defWorkHoursFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_defWorkHoursFieldLabel)) {
                        this._pS_defWorkHoursFieldLabel = {};
                        this._pS_defWorkHoursFieldLabel["paddingTop"] = this._context.theming.measures.measure075;
                        this._pS_defWorkHoursFieldLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._pS_defWorkHoursFieldLabel["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._pS_defWorkHoursFieldLabel;
                };
                PersonalSettingStyles.prototype.PS_FieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_FieldLabel)) {
                        this._pS_FieldLabel = {};
                        this._pS_FieldLabel["fontSize"] = this._context.theming.fontsizes.font100;
                    }
                    return this._pS_FieldLabel;
                };
                PersonalSettingStyles.prototype.PS_startTimeFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_startTimeFieldLabel)) {
                        this._pS_startTimeFieldLabel = {};
                        this._pS_startTimeFieldLabel["paddingTop"] = this._context.theming.measures.measure025;
                        this._pS_startTimeFieldLabel["paddingBottom"] = this._context.theming.measures.measure025;
                    }
                    return this._pS_startTimeFieldLabel;
                };
                PersonalSettingStyles.prototype.PS_endTimeFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_endTimeFieldLabel)) {
                        this._pS_endTimeFieldLabel = {};
                        this._pS_endTimeFieldLabel["paddingTop"] = this._context.theming.measures.measure025;
                        this._pS_endTimeFieldLabel["paddingBottom"] = this._context.theming.measures.measure025;
                    }
                    return this._pS_endTimeFieldLabel;
                };
                PersonalSettingStyles.prototype.PS_viewdescFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_viewdescFieldLabel)) {
                        this._pS_viewdescFieldLabel = {};
                        this._pS_viewdescFieldLabel["paddingTop"] = this._context.theming.measures.measure075;
                        this._pS_viewdescFieldLabel["paddingLeft"] = this._context.theming.measures.measure075;
                        this._pS_viewdescFieldLabel["paddingRight"] = this._context.theming.measures.measure075;
                    }
                    return this._pS_viewdescFieldLabel;
                };
                PersonalSettingStyles.prototype.PS_recperpageFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._pS_recperpageFieldLabel)) {
                        this._pS_recperpageFieldLabel = {};
                        this._pS_recperpageFieldLabel["paddingTop"] = this._context.theming.measures.measure025;
                        this._pS_recperpageFieldLabel["paddingRight"] = this._context.theming.measures.measure075;
                        this._pS_recperpageFieldLabel["marginLeft"] = this._context.theming.measures.measure050;
                    }
                    return this._pS_recperpageFieldLabel;
                };
                //selector-combobox
                PersonalSettingStyles.prototype.SelectorCombobox = function () {
                    if (this._context.utils.isNullOrUndefined(this._selectorCombobox)) {
                        this._selectorCombobox = {};
                        this._selectorCombobox["fontSize"] = "0.8rem";
                    }
                    return this._selectorCombobox;
                };
                PersonalSettingStyles.prototype.SelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._selectorContainer)) {
                        this._selectorContainer = {};
                        this._selectorContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._selectorContainer["width"] = "24.8rem";
                        this._selectorContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._selectorContainer["display"] = "flex";
                        this._selectorContainer["flexDirection"] = "column";
                        this._selectorContainer["justifyContent"] = " space-between";
                    }
                    return this._selectorContainer;
                };
                PersonalSettingStyles.prototype.TimeZoneSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._timeZoneSelectorContainer)) {
                        this._timeZoneSelectorContainer = {};
                        this._timeZoneSelectorContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._timeZoneSelectorContainer["width"] = "25% !important";
                        this._timeZoneSelectorContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._timeZoneSelectorContainer["display"] = "flex";
                        this._timeZoneSelectorContainer["flexDirection"] = "column";
                        this._timeZoneSelectorContainer["justifyContent"] = " space-between";
                    }
                    return this._timeZoneSelectorContainer;
                };
                //Calender Options Container
                PersonalSettingStyles.prototype.CalendarOptionsContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._calendarOptionsContainer)) {
                        this._calendarOptionsContainer = {};
                        this._calendarOptionsContainer["width"] = "15% !important";
                    }
                    return this._calendarOptionsContainer;
                };
                PersonalSettingStyles.prototype.CalendarViewSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._calendarViewSelectorContainer)) {
                        this._calendarViewSelectorContainer = {};
                        this._calendarViewSelectorContainer = this.SelectorContainer();
                        this._calendarViewSelectorContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._calendarViewSelectorContainer["width"] = "auto";
                        this._calendarViewSelectorContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._calendarViewSelectorContainer["display"] = "flex";
                        this._calendarViewSelectorContainer["flexDirection"] = "column";
                        this._calendarViewSelectorContainer["justifyContent"] = " space-between";
                    }
                    return this._calendarViewSelectorContainer;
                };
                PersonalSettingStyles.prototype.TimeSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._timeSelectorContainer)) {
                        this._timeSelectorContainer = {};
                        this._timeSelectorContainer["display"] = "flex";
                        this._timeSelectorContainer["flexDirection"] = "row";
                        this._timeSelectorContainer["justifyContent"] = "flex-start";
                        this._timeSelectorContainer["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._timeSelectorContainer;
                };
                PersonalSettingStyles.prototype.StartTimeSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._startTimeSelectorContainer)) {
                        this._startTimeSelectorContainer = {};
                        this._startTimeSelectorContainer["display"] = "flex";
                        this._startTimeSelectorContainer["flexDirection"] = "column";
                        this._startTimeSelectorContainer["justifyContent"] = " space-between";
                        this._startTimeSelectorContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._startTimeSelectorContainer["width"] = "12.1rem";
                    }
                    return this._startTimeSelectorContainer;
                };
                PersonalSettingStyles.prototype.EndTimeSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._endTimeSelectorContainer)) {
                        this._endTimeSelectorContainer = {};
                        this._endTimeSelectorContainer["display"] = "flex";
                        this._endTimeSelectorContainer["flexDirection"] = "column";
                        this._endTimeSelectorContainer["justifyContent"] = " space-between";
                        this._endTimeSelectorContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._endTimeSelectorContainer["width"] = "12.1rem";
                    }
                    return this._endTimeSelectorContainer;
                };
                PersonalSettingStyles.prototype.PagingSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pagingSelectorContainer)) {
                        this._pagingSelectorContainer = {};
                        this._pagingSelectorContainer["display"] = "flex";
                        this._pagingSelectorContainer["flexDirection"] = "row";
                        this._pagingSelectorContainer["justifyContent"] = "flex-start";
                        this._pagingSelectorContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._pagingSelectorContainer["marginTop"] = this._context.theming.measures.measure025;
                        this._pagingSelectorContainer["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._pagingSelectorContainer;
                };
                PersonalSettingStyles.prototype.PagingComboContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._pagingComboContainer)) {
                        this._pagingComboContainer = {};
                        this._pagingComboContainer["width"] = "12.2rem";
                    }
                    return this._pagingComboContainer;
                };
                return PersonalSettingStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            PersonalSettings.PersonalSettingStyles = PersonalSettingStyles;
        })(PersonalSettings = AppCommon.PersonalSettings || (AppCommon.PersonalSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=PersonalSettings.js.map