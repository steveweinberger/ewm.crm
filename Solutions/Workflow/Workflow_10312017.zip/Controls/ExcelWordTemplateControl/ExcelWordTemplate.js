var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../freshell/libs/smbappmoduleappconfig-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var ServiceProxy = Mscrm.AppCommon.Common.ServiceProxy;
            var Utility = Mscrm.AppCommon.Common.Utility;
            var ExcelWordTemplateControl = (function () {
                /**
                 * Empty constructor.
                 */
                function ExcelWordTemplateControl() {
                    var _this = this;
                    this._dataFetched = false;
                    this._hasRenderedOnce = false;
                    this._columns = ['DisplayName', 'LogicalName', 'ObjectTypeCode'];
                    /**
                    * The function is called asynchronously by AppConfig integration module when grid filtering input is available
                    **/
                    this.requiredDataAvailableToRender = function (filteringInput) {
                        _this._dataFetched = true;
                        _this._entityList = JSON.parse(_this._appModuleAppConfig.GetEntityWhiteListForCreateDialog());
                        _this._filteringInput = _this.createFilteringInput(_this._entityList);
                        _this._context.utils.requestRender();
                    };
                    this._applyStyles = null;
                    this._refreshCounter = 0;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                ExcelWordTemplateControl.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    var title = this._context.resources.getString(ExcelWordTemplate.StringKeys.AdvancedSettingsText) + " " + this._context.resources.getString(ExcelWordTemplate.StringKeys.SubAreaLabel) + " - " + this._context.resources.getString(ExcelWordTemplate.StringKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(context, title);
                    this._applyStyles = new ExcelWordTemplate.ExcelWordTemplateStyles(context);
                    this._appId = Utility.GetCurrentAppId();
                    ServiceProxy.init("../" + this._context.utils.createCrmUri(""));
                    if (!context.utils.isNullOrUndefined(context.parameters.FilteringInput)) {
                        this._filteringInput = context.parameters.FilteringInput.raw;
                        this._dataFetched = true;
                    }
                    else {
                        this._appModuleAppConfig = new MscrmControls.AppCommon.AppModuleAppConfig(this._context.webAPI, this._context.utils, ExcelWordTemplate.Constants.ComponentType, this._appId, this.requiredDataAvailableToRender.bind(this), null);
                        this._appModuleAppConfig.AsyncGetFilteringInputForCustomizationGrid();
                    }
                    this._viewId = context.utils.isNullOrUndefined(context.parameters.ViewId) ?
                        ExcelWordTemplate.Constants.DefaultViewId : context.parameters.ViewId.raw;
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.WORDANDEXCELTEMPLATE, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "ExcelWordTemplateControl", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                ExcelWordTemplateControl.prototype.updateView = function (context) {
                    this._hasRenderedOnce = true;
                    return this._freShell.getVirtualComponents(this.getChildControls());
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                ExcelWordTemplateControl.prototype.getChildControls = function () {
                    var params = {};
                    params.areaLabel = this._context.resources.getString(ExcelWordTemplate.StringKeys.AreaLabel);
                    params.subAreaLabel = this._context.resources.getString(ExcelWordTemplate.StringKeys.SubAreaLabel);
                    // Create the right container having buttons.
                    params.headerRightContainerChild = this.createHeaderRightContainer();
                    //icon content
                    params.normalIconImagePath = ExcelWordTemplate.Constants.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = ExcelWordTemplate.Constants.HeaderHighContrastIconImagePath;
                    //the grid has - 5px margin.To compensate that we need to have margin of 5px on the container.
                    // TODO: replace with overflow:none on parent and have it expand as grid expands.
                    if (this._dataFetched) {
                        var properties = {
                            "parameters": {
                                Grid: {
                                    "TargetEntityType": ExcelWordTemplate.Constants.DocumentTemplate,
                                    "ViewId": this._viewId,
                                    Type: "Grid",
                                    FilteringInput: {
                                        Static: true,
                                        ControlLinked: false,
                                        Value: this._filteringInput
                                    },
                                    DataSetHostProps: {
                                        commandBarEnabled: true,
                                        jumpBarEnabled: true,
                                        quickFindEnabled: true,
                                        viewSelectorEnabled: false
                                    }, RefreshInput: {
                                        Static: true,
                                        Value: this._refreshCounter
                                    },
                                },
                                EnableGroupBy: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableFiltering: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                },
                                EnableEditing: {
                                    Usage: 1,
                                    Static: true,
                                    Type: "Enum",
                                    Value: "No",
                                    Primary: false
                                }
                            },
                        };
                        var grid = this._context.factory.createComponent("MscrmControls.Grid.GridControl", "documenttemplate", properties);
                        //Grid container
                        var gridContainer = this._context.factory.createElement("CONTAINER", {
                            id: ExcelWordTemplate.Constants.ExcelGridContainerKey, key: ExcelWordTemplate.Constants.ExcelGridContainerKey,
                            style: this._applyStyles.FREGridContainer()
                        }, [grid]);
                        params.contentContainerChild = gridContainer;
                        this._freShell.stopPerformanceStopWatch();
                    }
                    return params;
                };
                /**
                 * Creates RightContainer for header
                 */
                ExcelWordTemplateControl.prototype.createHeaderRightContainer = function () {
                    var addTemplateButtonIcon = this._context.factory.createElement("CONTAINER", {
                        key: ExcelWordTemplate.Constants.ExcelAddButtonIconContainerKey, id: ExcelWordTemplate.Constants.ExcelAddButtonIconContainerKey,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var addTemplateButton = this._context.factory.createElement("BUTTON", {
                        key: ExcelWordTemplate.Constants.ExcelAddButtonKey, id: ExcelWordTemplate.Constants.ExcelAddButtonKey,
                        onClick: this.onNewTemplateClick.bind(this),
                        title: this._context.resources.getString(ExcelWordTemplate.StringKeys.NewTemplateButtonToolTip), tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [addTemplateButtonIcon, this._context.resources.getString(ExcelWordTemplate.StringKeys.NewTemplateButtonLabel)]);
                    var uploadTemplateButtonIcon = this._context.factory.createElement("CONTAINER", {
                        key: ExcelWordTemplate.Constants.ExcelUploadButtonIconContainerKey, id: ExcelWordTemplate.Constants.ExcelUploadButtonIconContainerKey,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var uploadTemplateButton = this._context.factory.createElement("BUTTON", {
                        key: ExcelWordTemplate.Constants.ExcelUploadButtonKey, id: ExcelWordTemplate.Constants.ExcelUploadButtonKey,
                        onClick: this.onUploadTemplateClick.bind(this),
                        title: this._context.resources.getString(ExcelWordTemplate.StringKeys.UploadTemplateButtonToolTip), tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [uploadTemplateButtonIcon, this._context.resources.getString(ExcelWordTemplate.StringKeys.UploadTemplateButtonLabel)]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: ExcelWordTemplate.Constants.ExcelHeaderSeparatorContainerKey, id: ExcelWordTemplate.Constants.ExcelHeaderSeparatorContainerKey,
                        style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: ExcelWordTemplate.Constants.ExcelHeaderRightContainerKey, id: ExcelWordTemplate.Constants.ExcelHeaderRightContainerKey,
                        style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, addTemplateButton, uploadTemplateButton]);
                    return headerRightContainer;
                };
                ExcelWordTemplateControl.prototype.onNewTemplateClick = function (event) {
                    var dialogOptions = {};
                    dialogOptions.position = 2 /* side */;
                    dialogOptions.width = "25rem";
                    var that = this;
                    this._context.navigation.openDialog(ExcelWordTemplate.Constants.ExcelWordTemplateDialog, dialogOptions, { "filter_entity": this._entityList }).then(function (resp) {
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.accessibility.focusElementById(ExcelWordTemplate.Constants.ExcelAddButtonKey);
                        that._context.utils.requestRender();
                        that.successCallback(resp);
                    }, function (error) {
                        that._context.accessibility.focusElementById(ExcelWordTemplate.Constants.ExcelAddButtonKey);
                        that.errorCallback;
                    });
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.WORDANDEXCELTEMPLATE, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDLINK, "ExcelWordTemplateControl", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Create Template Tried", false);
                };
                ExcelWordTemplateControl.prototype.onUploadTemplateClick = function (event) {
                    var dialogOptions = {};
                    dialogOptions.position = 2 /* side */;
                    dialogOptions.width = "25rem";
                    var that = this;
                    this._context.navigation.openDialog(ExcelWordTemplate.Constants.ExcelWordTemplateDialog, dialogOptions, { "Tab_To_Open": "UploadTemplate", "filter_entity": this._entityList }).then(function (resp) {
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.accessibility.focusElementById(ExcelWordTemplate.Constants.ExcelUploadButtonKey);
                        that._context.utils.requestRender();
                        that.successCallback(resp);
                    }, function (error) {
                        that._context.accessibility.focusElementById(ExcelWordTemplate.Constants.ExcelUploadButtonKey);
                        that.errorCallback;
                    });
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.WORDANDEXCELTEMPLATE, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDLINK, "ExcelWordTemplateControl", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Create Template Tried", false);
                };
                ExcelWordTemplateControl.prototype.successCallback = function (response) {
                    //TODO: Add condition over here
                    //this._context.utils.refreshDataSet();
                    if (!Utility.isNullOrUndefined(response.parameters) && !Utility.isNullOrUndefined(response.parameters.uploaded_template_id)) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.WORDANDEXCELTEMPLATE, SmbAppsTelemetryUtility.Controls_EventName.COMPLETED, "ExcelWordTemplateControl", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Create Template Success", false);
                    }
                };
                ExcelWordTemplateControl.prototype.errorCallback = function (response) {
                };
                ExcelWordTemplateControl.prototype.createFilteringInput = function (items) {
                    var conditions = [];
                    items.forEach(function (item) {
                        conditions.push({
                            attributeName: ExcelWordTemplate.Constants.AssociatedETC,
                            conditionOperator: 0 /* Equal */,
                            value: item.OTC.toString() //This is important since infra checks for .length property on value
                        });
                    });
                    var InstancesFilterExpression = {
                        filterOperator: 1 /* Or */,
                        conditions: conditions
                    };
                    return JSON.stringify({ filters: [InstancesFilterExpression] });
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                ExcelWordTemplateControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                ExcelWordTemplateControl.prototype.destroy = function () {
                };
                return ExcelWordTemplateControl;
            }());
            ExcelWordTemplate.ExcelWordTemplateControl = ExcelWordTemplateControl;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="control.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            var Entity = (function () {
                function Entity() {
                }
                return Entity;
            }());
            Entity.Account = 1;
            Entity.Contact = 2;
            Entity.Opportunity = 3;
            Entity.Lead = 4;
            Entity.Invoice = 1090;
            Entity.InvoiceDetail = 1091;
            Entity.Quote = 1084;
            Entity.QuoteDetail = 1085;
            Entity.Product = 1024;
            ExcelWordTemplate.Entity = Entity;
            var Constants = (function () {
                function Constants() {
                }
                return Constants;
            }());
            Constants.DocumentTemplate = "documenttemplate";
            Constants.DefaultViewId = "85966d5d-19e4-46e3-9d96-5a4b6d3d1264";
            Constants.ExcelWordTemplateDialog = "Excel_Word_Template";
            Constants.SMBDefaultEntities = [
                Entity.Account,
                Entity.Contact,
                Entity.Opportunity,
                Entity.Lead,
                Entity.Invoice,
                Entity.InvoiceDetail,
                Entity.Quote,
                Entity.QuoteDetail,
                Entity.Product
            ];
            Constants.ComponentType = 29;
            Constants.AssociatedETC = "associatedentitytypecode";
            Constants.HeaderNormalIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ExcelAndWordTemplate.svg";
            Constants.HeaderHighContrastIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ExcelAndWordTemplate_HC.svg";
            Constants.ExcelGridContainerKey = "ExcelFREGridContainer";
            Constants.ExcelAddButtonIconContainerKey = "ExcelWordTemplatePage.AddButton_label";
            Constants.ExcelAddButtonKey = "ExcelWordTemplatePage.AddButton";
            Constants.ExcelUploadButtonIconContainerKey = "ExcelWordTemplatePage.UploadButton_label";
            Constants.ExcelUploadButtonKey = "ExcelWordTemplatePage.UploadButton";
            Constants.ExcelHeaderSeparatorContainerKey = "ExcelWordTemplatePage.ButtonSeparator";
            Constants.ExcelHeaderRightContainerKey = "ExcelWordTemplatePage.HeaderRightContainer";
            ExcelWordTemplate.Constants = Constants;
            var StringKeys = (function () {
                function StringKeys() {
                }
                return StringKeys;
            }());
            StringKeys.AreaLabel = "TemplateHomePage.AreaLabel";
            StringKeys.SubAreaLabel = "TemplateHomePage.SubAreaLabel";
            StringKeys.NewTemplateButtonLabel = "TemplateHomePage.NewTemplateButtonLabel";
            StringKeys.NewTemplateButtonToolTip = "TemplateHomePage.NewTemplateButtonToolTip";
            StringKeys.UploadTemplateButtonLabel = "TemplateHomePage.UploadTemplateButtonLabel";
            StringKeys.UploadTemplateButtonToolTip = "TemplateHomePage.UploadTemplateButtonToolTip";
            StringKeys.AdvancedSettingsText = "AdvancedSettingsText";
            StringKeys.MicrosoftDynamics365Text = "MicrosoftDynamics365Text";
            ExcelWordTemplate.StringKeys = StringKeys;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            var ExcelWordTemplateStyles = (function (_super) {
                __extends(ExcelWordTemplateStyles, _super);
                function ExcelWordTemplateStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._excelWordTemplatePageIcon = {};
                    _this._excelWordTemplatePageAddButtonLabel = {};
                    _this._excelWordTemplatePageUploadButtonLabel = {};
                    _this._excelWordTemplateCreateButtonIcon = {};
                    _this._excelWordTemplateCreateButtonText = {};
                    _this._excelWordTemplateCreateButtonButton = {};
                    _this._excelWordTemplateHeaderRightContainerChild = {};
                    _this._context = context;
                    _this._excelWordTemplatePageIcon = null;
                    _this._excelWordTemplatePageAddButtonLabel = null;
                    _this._excelWordTemplatePageUploadButtonLabel = null;
                    _this._excelWordTemplateCreateButtonIcon = null;
                    _this._excelWordTemplateCreateButtonText = null;
                    _this._excelWordTemplateCreateButtonButton = null;
                    _this._excelWordTemplateHeaderRightContainerChild = null;
                    return _this;
                }
                ExcelWordTemplateStyles.prototype.ExcelWordTemplatePageCreateButtonIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._excelWordTemplateCreateButtonIcon)) {
                        this._excelWordTemplateCreateButtonIcon = {};
                        this._excelWordTemplateCreateButtonIcon["margin"] = "0px";
                    }
                    return this._excelWordTemplateCreateButtonIcon;
                };
                ExcelWordTemplateStyles.prototype.ExcelWordTemplatePageCreateButtonText = function () {
                    if (this._context.utils.isNullOrUndefined(this._excelWordTemplateCreateButtonText)) {
                        this._excelWordTemplateCreateButtonText = {};
                        this._excelWordTemplateCreateButtonText["margin"] = "0px";
                        this._excelWordTemplateCreateButtonText["fontSize"] = "16px";
                        this._excelWordTemplateCreateButtonText["color"] = "#0078D7";
                        this._excelWordTemplateCreateButtonText["letterSpacing"] = "0px";
                        this._excelWordTemplateCreateButtonText["whiteSpace"] = "nowrap";
                    }
                    return this._excelWordTemplateCreateButtonText;
                };
                return ExcelWordTemplateStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            ExcelWordTemplate.ExcelWordTemplateStyles = ExcelWordTemplateStyles;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExcelWordTemplate;
        (function (ExcelWordTemplate) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "OrganizationSetup", {
                    get: function () {
                        return "OrganizationSetup";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Templates", {
                    get: function () {
                        return "Templates";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "NewTemplate", {
                    get: function () {
                        return "NewTemplate";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "UploadTemplate", {
                    get: function () {
                        return "UploadTemplate";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            ExcelWordTemplate.ResourceKeys = ResourceKeys;
        })(ExcelWordTemplate = AppCommon.ExcelWordTemplate || (AppCommon.ExcelWordTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=ExcelWordTemplate.js.map