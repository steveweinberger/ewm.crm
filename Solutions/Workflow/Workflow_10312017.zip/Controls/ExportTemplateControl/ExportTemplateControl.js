var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExportTemplate;
        (function (ExportTemplate) {
            'use strict';
            var ExportTemplateControl = (function () {
                /**
                 * Empty constructor.
                 */
                function ExportTemplateControl() {
                    this._ViewIDViewTypeMap = {};
                    this._entityViewIDFetchXml = {};
                    this._entityViewIDLayoutXml = {};
                }
                /**
                 * Method is called by the framework to notify the control about pre navigation event.
                 */
                ExportTemplateControl.prototype.onPreNavigation = function () {
                    /// No implementation
                };
                /**
                 * Initializes the control. This function has access to the property bag context that will contain your custom control properties and utility functions.
                 * Predefinitions and initialisations can be done in this.
                 *
                 * @param context Dictionary containing custom control's context.
                 * @param notifyOutputChanged Function to call when control changed its value, to propagate changes to redux state.
                 * @param state The control's internal state. Has nothing to do with redux state tree.
                 */
                ExportTemplateControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._currentEntitySelected = { Value: 0, Label: "", Id: "" };
                    this._currentEntityViewSelected = { Value: 0, Label: "", Id: "" };
                    this._defaultSystemView = { Value: 0, Label: this._context.resources.getString("ExportTemplateControl_SelectViewLabel"), Id: "" };
                    this._defaultSystemViewList = [
                        { Value: 0, Label: this._context.resources.getString("ExportTemplateControl_SelectViewLabel"), Id: "" }
                    ];
                    this.getEntities();
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    this._retrievedSystemView = false;
                    this._retrievedUserView = false;
                    this._applyStyles = new ExportTemplate.ExportTemplateStyles(this._context);
                };
                /**
                 * Renders the control with data from the a context properties currently assigned to the control's manifest parameters
                 */
                ExportTemplateControl.prototype.updateView = function (context) {
                    this._context = context;
                    return this._context.factory.createElement("CONTAINER", {
                        key: "exportTemplatePagecontainer",
                        id: "exportTemplatePagecontainer",
                        style: this._applyStyles.ExportTemplatePageContainerStyle()
                    }, [this.createEntitySelectorControl(), this.createViewSelectorControl()]);
                };
                /**
                * Creates the entity selector control
                **/
                ExportTemplateControl.prototype.createEntitySelectorControl = function () {
                    this._entitiesProps = {
                        id: "entitySelectorContainer",
                        key: "entitySelectorContainer",
                        freeTextMode: false,
                        onChange: this._onChangeHandlerEntity.bind(this),
                        value: { Value: this._currentEntitySelected.Value },
                        options: this._entityList,
                        style: this._applyStyles.selectStyle()
                    };
                    var entitiesSelector = this._context.factory.createElement("SELECT", this._entitiesProps, null);
                    var selectEntityLabel = this._context.factory.createElement("LABEL", {
                        key: "selectEntityLabel",
                        id: "selectEntityLabel",
                        forElementId: this._context.accessibility.getUniqueId("entitySelectorContainer"),
                        style: this._applyStyles.ExportTemplateLabelStyle()
                    }, this._context.resources.getString("ExportTemplateControl_EntityLabel"));
                    return this._context.factory.createElement("CONTAINER", {
                        key: "entitySelectorDivContainer",
                        id: "entitySelectorDivContainer",
                        style: this._applyStyles.ExportTemplateSelectorContainer()
                    }, [selectEntityLabel, entitiesSelector]);
                };
                /**
                 * Create View Selector Control
                 */
                ExportTemplateControl.prototype.createViewSelectorControl = function () {
                    if ((this._entityViewJsonData == null || this._entityViewJsonData == undefined) &&
                        (this._entityUserViewJsonData == null || this._entityUserViewJsonData == undefined)) {
                        this._currentEntityViewSelected = this._defaultSystemView;
                        this._viewList = this._defaultSystemViewList;
                    }
                    this._viewsProps = {
                        id: "viewSelectorContainer",
                        key: "viewSelectorContainer",
                        freeTextMode: false,
                        onChange: this._onChangeHandlerView.bind(this),
                        value: { Value: this._currentEntityViewSelected.Value },
                        options: this._viewList,
                        style: this._applyStyles.selectStyle()
                    };
                    var viewsSelector = this._context.factory.createElement("SELECT", this._viewsProps, null);
                    var selectViewLabel = this._context.factory.createElement("LABEL", {
                        key: "selectViewLabel",
                        id: "selectViewLabel",
                        forElementId: this._context.accessibility.getUniqueId("viewSelectorContainer"),
                        style: this._applyStyles.ExportTemplateLabelStyle()
                    }, this._context.resources.getString("ExportTemplateControl_ViewLabel"));
                    return this._context.factory.createElement("CONTAINER", {
                        key: "viewSelectorContainer",
                        id: "viewSelectorContainer",
                        style: this._applyStyles.ExportTemplateSelectorContainer()
                    }, [selectViewLabel, viewsSelector]);
                };
                /**
                 * OnChangeHandler for Entity Dropdown
                .* It retrieves views related to an entity
                 * @param selectedEntity: Entity selected in dropdown
                 */
                ExportTemplateControl.prototype._onChangeHandlerEntity = function (selectedEntity) {
                    if (!this.EqualsIgnoreCase(this._currentEntitySelected.Id, selectedEntity.Id)) {
                        this._currentEntitySelected = selectedEntity;
                        this._entityViewJsonData = null;
                        this._entityUserViewJsonData = null;
                        this._retrievedSystemView = false;
                        ;
                        this._retrievedUserView = false;
                        this._currentEntityViewSelected = this._defaultSystemView;
                        this.getEntitySystemViews();
                        this.getEntityUserViews();
                        this._notifyOutputChanged();
                    }
                };
                /**
                * Onchange handler for View Dropdown
                * @param selectedView: View selected in dropdown
                */
                ExportTemplateControl.prototype._onChangeHandlerView = function (selectedView) {
                    this._currentEntityViewSelected = selectedView;
                    this._notifyOutputChanged();
                };
                /**
                * Initiate the request render available in the utils
                */
                ExportTemplateControl.prototype.renderControl = function (render, callback) {
                    if (render === void 0) { render = false; }
                    if (callback === void 0) { callback = null; }
                    if (render) {
                        this._context.utils.requestRender(callback);
                    }
                };
                /**
                * Creates an option for the given value.which can be consumed by select control
                */
                ExportTemplateControl.prototype._createOption = function (key, value, text) {
                    return { Value: key, Label: value, Id: text };
                };
                /**
                * Forms an array of the options for populating Entity Select dropdown
                */
                ExportTemplateControl.prototype._createEntitiesList = function () {
                    var defaultValue = [
                        { Value: 0, Label: this._context.resources.getString("ExportTemplateControl_SelectEntityLabel"), Id: "" }
                    ];
                    if ((this._entitiesJsonData == null || this._entitiesJsonData == undefined)) {
                        return defaultValue;
                    }
                    var i;
                    var entitiesOptions = [];
                    for (i = 0; i < this._entitiesJsonData.length; i++) {
                        entitiesOptions = entitiesOptions.concat(this._createOption(i + 1, this._entitiesJsonData[i].UserLocalizedName, this._entitiesJsonData[i].LogicalName));
                    }
                    entitiesOptions.sort(function (firstOption, secondOption) {
                        if (firstOption.Label != secondOption.Label) {
                            if (firstOption.Label < secondOption.Label)
                                return -1;
                            else if (firstOption.Label > secondOption.Label)
                                return 1;
                        }
                        return 0;
                    });
                    this._entityList = defaultValue.concat(entitiesOptions);
                };
                /**
                 * Forms an array of the options for populating View Select dropdown
                 */
                ExportTemplateControl.prototype._createEntityViewList = function () {
                    if (this._retrievedSystemView && this._retrievedUserView) {
                        var systemViewList = [];
                        var userViewList = [];
                        var systemAndUserViewList = [];
                        var i = 0;
                        // Get List of System Views
                        if (!(this._entityViewJsonData == null || this._entityViewJsonData == undefined) &&
                            !(this._entityViewJsonData.entities == null)) {
                            this._entityViewIDFetchXml = {};
                            this._entityViewIDLayoutXml = {};
                            for (i = 0; i < this._entityViewJsonData.entities.length; i++) {
                                if (this.isNullUndefinedOrWhitespace(this._entityViewJsonData.entities[i].fetchxml))
                                    continue;
                                this._entityViewIDFetchXml[this._entityViewJsonData.entities[i].savedqueryid] =
                                    this._entityViewJsonData.entities[i].fetchxml;
                                systemViewList = systemViewList.concat(this._createOption(i + 1, this._entityViewJsonData.entities[i].name, this._entityViewJsonData.entities[i].savedqueryid));
                                this._ViewIDViewTypeMap[this._entityViewJsonData.entities[i].savedqueryid] =
                                    ExportTemplate.Constants.Form.SAVED_QUERY_VIEW_TYPE;
                                this._entityViewIDLayoutXml[this._entityViewJsonData.entities[i].savedqueryid] =
                                    this._entityViewJsonData.entities[i].layoutxml;
                            }
                        }
                        // Get the list of user views
                        if (!(this._entityUserViewJsonData == null || this._entityUserViewJsonData == undefined) &&
                            !(this._entityUserViewJsonData.entities == null)) {
                            var j;
                            for (j = 0; j < this._entityUserViewJsonData.entities.length; j++) {
                                if (this.isNullUndefinedOrWhitespace(this._entityUserViewJsonData.entities[j].fetchxml))
                                    continue;
                                userViewList = userViewList.concat(this._createOption(i++, this._entityUserViewJsonData.entities[j].name, this._entityUserViewJsonData.entities[j].userqueryid));
                                this._ViewIDViewTypeMap[this._entityUserViewJsonData.entities[j].userqueryid] =
                                    ExportTemplate.Constants.Form.USER_QUERY_VIEW_TYPE;
                                this._entityViewIDFetchXml[this._entityUserViewJsonData.entities[j].userqueryid] =
                                    this._entityUserViewJsonData.entities[j].fetchxml;
                                this._entityViewIDLayoutXml[this._entityUserViewJsonData.entities[j].userqueryid] =
                                    this._entityUserViewJsonData.entities[j].layoutxml;
                            }
                        }
                        // Concat all(System + User) views and create view list
                        systemAndUserViewList = systemViewList.concat(userViewList);
                        systemAndUserViewList.sort(function (firstOption, secondOption) {
                            if (firstOption.Label != secondOption.Label) {
                                if (firstOption.Label < secondOption.Label)
                                    return -1;
                                else if (firstOption.Label > secondOption.Label)
                                    return 1;
                            }
                            return 0;
                        });
                        this._viewList = this._viewList.concat(systemAndUserViewList);
                    }
                    this._context.utils.requestRender();
                };
                /**
                    * Gets the list of the entity names.
                */
                ExportTemplateControl.prototype.getEntities = function () {
                    if ((this._entitiesJsonData == null || this._entitiesJsonData == undefined) || (this._entitiesJsonData != null && this._entitiesJsonData.value == null)) {
                        this._entitiesJsonData = this._context.parameters.EntityList.raw;
                        this._createEntitiesList();
                    }
                };
                ExportTemplateControl.prototype.actionFailedCallback = function (error) {
                    // TODO: Add failure notification
                };
                /**
                 * Retrieved System Views for selected entity
                 */
                ExportTemplateControl.prototype.getEntitySystemViews = function () {
                    var _this = this;
                    if ((((this._entityViewJsonData == null || this._entityViewJsonData == undefined) || (this._entityViewJsonData != null && this._entityViewJsonData.entities == null))) && !this.isNullUndefinedOrWhitespace(this._currentEntitySelected.Id)) {
                        var selectString = "?$select=name,savedqueryid,fetchxml,layoutxml&$filter=returnedtypecode eq '" + this._currentEntitySelected.Id + "' and querytype eq 0";
                        console.log(selectString);
                        this._context.webAPI.retrieveMultipleRecords("savedquery", selectString).then(function (retrieveResponse) {
                            _this._entityViewJsonData = retrieveResponse;
                            _this._retrievedSystemView = true;
                            _this._createEntityViewList();
                        }, this.actionFailedCallback);
                    }
                };
                /**
                 * Retrieves User Views for selected entity
                 */
                ExportTemplateControl.prototype.getEntityUserViews = function () {
                    var _this = this;
                    if ((((this._entityUserViewJsonData == null || this._entityUserViewJsonData == undefined) ||
                        (this._entityUserViewJsonData != null && this._entityUserViewJsonData.entities == null))) &&
                        !this.isNullUndefinedOrWhitespace(this._currentEntitySelected.Id)) {
                        var selectString = "?$select=name,userqueryid,fetchxml,layoutxml&$filter=returnedtypecode eq '" + this._currentEntitySelected.Id + "' and querytype eq 0";
                        console.log(selectString);
                        this._context.webAPI.retrieveMultipleRecords("userquery", selectString).then(function (retrieveResponse) {
                            _this._entityUserViewJsonData = retrieveResponse;
                            _this._retrievedUserView = true;
                            _this._createEntityViewList();
                        }, this.actionFailedCallback);
                    }
                };
                ExportTemplateControl.prototype.EqualsIgnoreCase = function (string1, string2) {
                    var isString1Null = string1 == null;
                    var isString2Null = string2 == null;
                    var isString1Undefined = string1 == undefined;
                    var isString2Undefined = string2 == undefined;
                    if (isString1Null && isString2Null || isString1Undefined && isString2Undefined) {
                        return true;
                    }
                    if (isString1Null != isString2Null || isString1Undefined != isString2Undefined) {
                        return false;
                    }
                    return string1.toUpperCase() === string2.toUpperCase();
                };
                ExportTemplateControl.prototype.isNullUndefinedOrWhitespace = function (s) {
                    return s == null || s == undefined || s.trim().length === 0;
                };
                ;
                /**
                 * @returns The a bag of output values to pass to the infrastructure
                 */
                ExportTemplateControl.prototype.getOutputs = function () {
                    var result = {
                        entity_id: this._currentEntitySelected.Id,
                        view_id: this._currentEntityViewSelected.Id,
                        entityview_fetchxml: this._entityViewIDFetchXml[this._currentEntityViewSelected.Id],
                        entityview_layoutxml: this._entityViewIDLayoutXml[this._currentEntityViewSelected.Id]
                    };
                    return result;
                };
                /**
                 * This function destroys the control and cleans up
                 */
                ExportTemplateControl.prototype.destroy = function () {
                    /// No implementation
                };
                return ExportTemplateControl;
            }());
            ExportTemplate.ExportTemplateControl = ExportTemplateControl;
        })(ExportTemplate = AppCommon.ExportTemplate || (AppCommon.ExportTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="ExportTemplateControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExportTemplate;
        (function (ExportTemplate) {
            var ExportTemplateStyles = (function (_super) {
                __extends(ExportTemplateStyles, _super);
                function ExportTemplateStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._exportTemplatePageContainer = {};
                    _this._exportTemplateLabelStyle = {};
                    _this._exportTemplateSelectorContainer = {};
                    _this._context = context;
                    _this._exportTemplatePageContainer = null;
                    _this._exportTemplateLabelStyle = null;
                    _this._exportTemplateSelectorContainer = null;
                    return _this;
                }
                ExportTemplateStyles.prototype.ExportTemplatePageContainerStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._exportTemplatePageContainer)) {
                        this._exportTemplatePageContainer = {};
                        this._exportTemplatePageContainer["display"] = "flex";
                        this._exportTemplatePageContainer["flexDirection"] = "column";
                        this._exportTemplatePageContainer["width"] = "100%";
                        this._exportTemplatePageContainer["marginRight"] = "0rem";
                    }
                    return this._exportTemplatePageContainer;
                };
                ExportTemplateStyles.prototype.ExportTemplateLabelStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._exportTemplatePageContainer)) {
                        this._exportTemplateLabelStyle = {};
                        this._exportTemplateLabelStyle["paddingBottom"] = this._context.theming.measures.measure025;
                        this._exportTemplateLabelStyle["fontSize"] = this._context.theming.fontsizes.font100;
                        ;
                        this._exportTemplateLabelStyle["fontFamily"] = this._context.theming.fontfamilies.semibold;
                        ;
                        this._exportTemplateLabelStyle["color"] = this._context.theming.colors.grays.gray06;
                        ;
                    }
                    return this._exportTemplateLabelStyle;
                };
                ExportTemplateStyles.prototype.ExportTemplateSelectorContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._exportTemplateSelectorContainer)) {
                        this._exportTemplateSelectorContainer = {};
                        this._exportTemplateSelectorContainer["marginBottom"] = this._context.theming.measures.measure075;
                        this._exportTemplateSelectorContainer["width"] = "100%";
                        this._exportTemplateSelectorContainer["display"] = "flex";
                        this._exportTemplateSelectorContainer["flexDirection"] = "column";
                    }
                    return this._exportTemplateSelectorContainer;
                };
                return ExportTemplateStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            ExportTemplate.ExportTemplateStyles = ExportTemplateStyles;
        })(ExportTemplate = AppCommon.ExportTemplate || (AppCommon.ExportTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExportTemplate;
        (function (ExportTemplate) {
            var Constants;
            (function (Constants) {
                Constants.DATA_SELECTOR = "1";
                Constants.TEMPLATE_SELECTOR = "0";
                Constants.EXPORT_TYPE_XLSX = "xlsx";
                var Form;
                (function (Form) {
                    Form.SAVED_QUERY_VIEW_TYPE = "1039";
                    Form.USER_QUERY_VIEW_TYPE = "4230";
                    Form.FORM_TAG = "form";
                    Form.PRINT_DATA_ASPX = "/_grid/print/print_data.aspx";
                    Form.FORM_POST = "POST";
                    Form.FORM_TARGET = "exportIFrame";
                })(Form = Constants.Form || (Constants.Form = {}));
            })(Constants = ExportTemplate.Constants || (ExportTemplate.Constants = {}));
        })(ExportTemplate = AppCommon.ExportTemplate || (AppCommon.ExportTemplate = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=ExportTemplateControl.js.map