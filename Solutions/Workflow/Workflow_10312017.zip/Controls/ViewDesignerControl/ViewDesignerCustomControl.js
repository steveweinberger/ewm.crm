/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="../freshell/libs/smbappmoduleappconfig-lib.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ViewDesigner;
        (function (ViewDesigner) {
            'use strict';
            var ViewDesignerControl = (function () {
                /**
                 * Empty constructor.
                 */
                function ViewDesignerControl() {
                    var _this = this;
                    /**
                    * The function is called by AppConfig integration module when parking solution id is retrieved
                    **/
                    this.parkingSolutionIdIsAvailable = function (parkingSolutionId) {
                        _this._parkingSolutionId = parkingSolutionId;
                        _this._requiredDataAvailableToRender = true;
                        _this._context.utils.requestRender();
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                ViewDesignerControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._clientUrl = "";
                    this._appId = "";
                    this._entityName = "";
                    this._parkingSolutionId = "";
                    this._viewDesignerMode = "";
                    this._viewId = "";
                    this._requiredDataAvailableToRender = false;
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                ViewDesignerControl.prototype.updateView = function (context) {
                    var viewDesignerBaseUrl = "/designer/pview/";
                    this._clientUrl = context.page.getClientUrl();
                    this.extractParametersFromUrl();
                    this._appModuleAppConfig = new MscrmControls.AppCommon.AppModuleAppConfig(this._context.webAPI, this._context.utils, null, this._appId, null, this.parkingSolutionIdIsAvailable.bind(this));
                    if (!this._requiredDataAvailableToRender) {
                        this._appModuleAppConfig.AsyncGetParkingSolution();
                    }
                    else {
                        if (this._appId && this._entityName && this._parkingSolutionId && this._viewDesignerMode && ((this._viewDesignerMode === "edit") ? this._viewId : true)) {
                            var url = this._clientUrl + viewDesignerBaseUrl + this._parkingSolutionId + "/" + this._entityName + ((this._viewDesignerMode === "edit") ? "#/ViewDesignerCanvas/" + this._viewId : "#/CreateNewView/" + this._entityName);
                            this.ViewDesignerFrame = context.factory.createElement("IFRAME", {
                                id: "ViewDesignerFrame",
                                key: "ViewDesignerFrame",
                                src: url,
                                onLoad: this.onLoadDesigner.bind(this),
                                style: {
                                    width: "0%",
                                    height: "100%",
                                    title: this._parkingSolutionId
                                }
                            });
                        }
                    }
                    return this.ViewDesignerFrame;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                ViewDesignerControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                ViewDesignerControl.prototype.destroy = function () {
                };
                /**
                 *  This funciton will fetch the Appid from URL
                 */
                ViewDesignerControl.prototype.extractParametersFromUrl = function () {
                    if (window && window.top && window.top.location && window.top.location.href) {
                        var currentUrl = window.top.location.href;
                        var index = currentUrl.indexOf("?");
                        var queryString = currentUrl.substring(index + 1, currentUrl.length);
                        var UrlVariables = queryString.split("&");
                        for (var i = 0; i < UrlVariables.length; i++) {
                            var Entry = UrlVariables[i].split("=");
                            var key = Entry.length === 2 ? Entry[0] : null;
                            if (key === "appid") {
                                this._appId = Entry[1];
                            }
                            else if (key === "extraqs") {
                                this.extractExtraqsParameters(Entry[1]);
                            }
                        }
                    }
                };
                ViewDesignerControl.prototype.extractExtraqsParameters = function (encodedExtraqsString) {
                    var extraqsString = decodeURIComponent(encodedExtraqsString);
                    var extraqsVariables = extraqsString.split("&");
                    for (var i = 0; i < extraqsVariables.length; i++) {
                        var Entry = extraqsVariables[i].split("=");
                        var key = Entry.length === 2 ? Entry[0] : null;
                        if (key === "mode") {
                            this._viewDesignerMode = Entry[1];
                        }
                        if (key === "entity") {
                            this._entityName = Entry[1];
                        }
                        if (key === "id") {
                            this._viewId = Entry[1];
                        }
                    }
                };
                /**
                 * This function handles events when designer get loaded with different src set
                 * @param event
                 */
                ViewDesignerControl.prototype.onLoadDesigner = function (event) {
                    var designerIFrame = document.getElementById("ViewDesignerFrame");
                    //In case designer is being lauched first time or consequently
                    if (designerIFrame.style.width == "" || designerIFrame.style.width == "0%") {
                        //Setting appId in the designer Iframe
                        var designerLaunchArgs = {};
                        designerLaunchArgs.AppModuleId = this._appId;
                        designerIFrame.contentWindow.DesignerLaunchArgs = designerLaunchArgs;
                        designerIFrame.style.width = "100%";
                        designerIFrame.style.height = "inherit";
                    }
                    else {
                        var previousUrl = "";
                        if (this._appId != "" && this._entityName != "") {
                            previousUrl = this._clientUrl + "/main.aspx?appid=" + this._appId + "&pagetype=entitylist&etn=" + this._entityName;
                            window.top.location.replace(previousUrl);
                        }
                    }
                };
                return ViewDesignerControl;
            }());
            ViewDesigner.ViewDesignerControl = ViewDesignerControl;
        })(ViewDesigner = AppCommon.ViewDesigner || (AppCommon.ViewDesigner = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="ViewDesigner.ts" /> 
//# sourceMappingURL=ViewDesignerCustomControl.js.map