var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DuplicateDetection;
        (function (DuplicateDetection) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            /// <summary>
            /// ImportStatus Reasons
            /// </summary>
            var DuplicateRuleState;
            (function (DuplicateRuleState) {
                DuplicateRuleState[DuplicateRuleState["Inactive"] = 0] = "Inactive";
                DuplicateRuleState[DuplicateRuleState["Active"] = 1] = "Active";
            })(DuplicateRuleState = DuplicateDetection.DuplicateRuleState || (DuplicateDetection.DuplicateRuleState = {}));
            /// <summary>
            /// The statuses of DuplicateRule
            /// </summary>
            var DuplicateRuleStatus;
            (function (DuplicateRuleStatus) {
                DuplicateRuleStatus[DuplicateRuleStatus["Unpublished"] = 0] = "Unpublished";
                DuplicateRuleStatus[DuplicateRuleStatus["Publishing"] = 1] = "Publishing";
                DuplicateRuleStatus[DuplicateRuleStatus["Published"] = 2] = "Published";
            })(DuplicateRuleStatus = DuplicateDetection.DuplicateRuleStatus || (DuplicateDetection.DuplicateRuleStatus = {}));
            var DuplicateDetectionControl = (function () {
                /**
                 * Empty constructor.
                 */
                function DuplicateDetectionControl() {
                    this._duplicateEnabledJsonData = {};
                    this._duplicateRulesJsonData = {};
                    this._duplicateDetectionFlagJsonData = {};
                    this._issameNameRuleAvailable = false;
                    this._issameEmailRuleAvailable = false;
                    this._issameAccountRuleAvailable = false;
                    this._isLoadingFlags = true;
                    this._isLoadingRules = true;
                    this._isGlobalDuplicateDetectionFlag = false;
                    this._applyStyles = null;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                DuplicateDetectionControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this.context = context;
                    var title = this.context.resources.getString(DuplicateDetection.ResourceKeys.AdvancedSettingsText) + " " + this.context.resources.getString(DuplicateDetection.ResourceKeys.DuplicateDetectionLabel) + " - " + this.context.resources.getString(DuplicateDetection.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(context, title);
                    this._applyStyles = new DuplicateDetection.DuplicateDetectionStyles(context);
                    var that = this;
                    var uri = this.context.utils.createCrmUri(DuplicateDetection.DuplicateDetectionStrings.CRMURI);
                    //O-data call for finding if duplicate detection is enabled or not
                    var c = $.getJSON(uri + DuplicateDetection.DuplicateDetectionStrings.DuplicateEnabledFlags)
                        .done(function (data) {
                        that._duplicateEnabledJsonData = data;
                        that._organizationID = that._duplicateEnabledJsonData.value[0].organizationid;
                        that._isLoadingFlags = false;
                        that.isDuplicateDetectionFlagsEnabled();
                        that.context.utils.requestRender();
                    })
                        .fail(function (data) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, data);
                        console.log(data);
                    });
                    //O-data call for finding number of duplicate rules available
                    var c = $.getJSON(uri + DuplicateDetection.DuplicateDetectionStrings.DuplicateDetectionRules)
                        .done(function (data) {
                        that._duplicateRulesJsonData = data;
                        that._isLoadingRules = false;
                        that.getStatusStateForDuplicateRules();
                        that.context.utils.requestRender();
                    })
                        .fail(function (data) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, data);
                        console.log(data);
                    });
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "DuplicateDetectionPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                DuplicateDetectionControl.prototype.updateView = function (context) {
                    return this._freShell.getVirtualComponents(this.getChildControls());
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                DuplicateDetectionControl.prototype.getChildControls = function () {
                    var params = {};
                    params.areaLabel = this.context.resources.getString(DuplicateDetection.ResourceKeys.BusinessManagementLabel);
                    params.subAreaLabel = this.context.resources.getString(DuplicateDetection.ResourceKeys.DuplicateDetectionLabel);
                    //icon content
                    params.normalIconImagePath = DuplicateDetection.DuplicateDetectionStrings.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = DuplicateDetection.DuplicateDetectionStrings.HeaderHighContrastIconImagePath;
                    var controls = [];
                    if (this._isLoadingFlags || this._isLoadingRules) {
                        controls.push(this.createBodyForLoadingPageDuplicateDetection());
                    }
                    else if (this._isLoadingFlags === false && this._isLoadingRules === false) {
                        if (this._duplicateEnabledJsonData === null) {
                            controls.push(this.createBodyForWaitPageDuplicateDetection());
                        }
                        else {
                            if (this._isGlobalDuplicateDetectionFlag === false) {
                                controls.push(this.createBodyForDisabledDuplicateDetection(this._rulesState === DuplicateRuleState.Inactive && this._rulesStatus === DuplicateRuleStatus.Unpublished));
                            }
                            else if (this._isGlobalDuplicateDetectionFlag === true) {
                                controls.push(this.createBodyForActivatedDuplicateDetection(this._rulesState === DuplicateRuleState.Active && this._rulesStatus === DuplicateRuleStatus.Published));
                            }
                        }
                        this._freShell.stopPerformanceStopWatch();
                    }
                    params.contentContainerChild = this.context.factory.createElement("CONTAINER", {
                        key: DuplicateDetection.DuplicateDetectionStrings.PageContainer,
                        id: DuplicateDetection.DuplicateDetectionStrings.PageContainer,
                        style: this._applyStyles.FREContentContainer()
                    }, controls);
                    return params;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                DuplicateDetectionControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                DuplicateDetectionControl.prototype.destroy = function () {
                };
                /**
                 * Sets the flag if the duplicate detection flag is enabled
                 */
                DuplicateDetectionControl.prototype.isDuplicateDetectionFlagsEnabled = function () {
                    if (!(this.context.utils.isNullOrUndefined(this._duplicateEnabledJsonData))
                        && !(this.context.utils.isNullOrUndefined(this._duplicateEnabledJsonData.value))
                        && this._duplicateEnabledJsonData.value.length > 0) {
                        if (this._duplicateEnabledJsonData.value[0].isduplicatedetectionenabled === false &&
                            this._duplicateEnabledJsonData.value[0].isduplicatedetectionenabledforimport === false &&
                            this._duplicateEnabledJsonData.value[0].isduplicatedetectionenabledforonlinecreateupdate === false) {
                            this._isGlobalDuplicateDetectionFlag = false;
                        }
                        else {
                            if (this._duplicateEnabledJsonData.value[0].isduplicatedetectionenabled === true &&
                                this._duplicateEnabledJsonData.value[0].isduplicatedetectionenabledforimport === true &&
                                this._duplicateEnabledJsonData.value[0].isduplicatedetectionenabledforonlinecreateupdate === true) {
                                this._isGlobalDuplicateDetectionFlag = true;
                            }
                        }
                    }
                };
                /**
                 * Gets the status if the rules are published, unpublished, publishing
                 */
                DuplicateDetectionControl.prototype.getStatusStateForDuplicateRules = function () {
                    var i;
                    var stateCodeActive = false;
                    var stateCodeInactive = false;
                    var statusCodePublish = false;
                    var statusCodePublishing = false;
                    var statusCodeUnPublish = false;
                    for (i = 0; i < this._duplicateRulesJsonData.value.length; i++) {
                        if (this._duplicateRulesJsonData.value[i].statecode === DuplicateRuleState.Inactive) {
                            stateCodeInactive = true;
                        }
                        if (this._duplicateRulesJsonData.value[i].statecode === DuplicateRuleState.Active) {
                            stateCodeActive = true;
                        }
                        if (this._duplicateRulesJsonData.value[i].statuscode === DuplicateRuleStatus.Published) {
                            statusCodePublish = true;
                        }
                        if (this._duplicateRulesJsonData.value[i].statuscode === DuplicateRuleStatus.Publishing) {
                            statusCodePublishing = true;
                        }
                        if (this._duplicateRulesJsonData.value[i].statuscode === DuplicateRuleStatus.Unpublished) {
                            statusCodeUnPublish = true;
                        }
                    }
                    if (stateCodeInactive === true && stateCodeActive === false) {
                        this._rulesState = DuplicateRuleState.Inactive;
                    }
                    if (stateCodeActive === true && stateCodeInactive === false) {
                        this._rulesState = DuplicateRuleState.Active;
                    }
                    if (statusCodePublish === true && statusCodePublishing === false && statusCodeUnPublish === false) {
                        this._rulesStatus = DuplicateRuleStatus.Published;
                    }
                    if (statusCodeUnPublish === true && statusCodePublishing === false && statusCodePublish === false) {
                        this._rulesStatus = DuplicateRuleStatus.Unpublished;
                    }
                };
                /**
                 * Post call for unPublishing the duplicateRules
                 */
                DuplicateDetectionControl.prototype.unPublishDuplicateRule = function () {
                    var that = this;
                    var uriUnPublishRule = this.context.utils.createCrmUri(DuplicateDetection.DuplicateDetectionStrings.CRMURI + "/UnpublishDuplicateRule");
                    var i;
                    var errorUnpublishRuleFlag = false;
                    for (i = 0; i < this._duplicateRulesJsonData.value.length; i++) {
                        if (this._duplicateRulesJsonData.value[i].duplicateruleid) {
                            $.ajax({
                                type: DuplicateDetection.DuplicateDetectionStrings.DDPostRequest,
                                url: uriUnPublishRule,
                                data: '{"DuplicateRuleId":"' + this._duplicateRulesJsonData.value[i].duplicateruleid + '"}',
                                success: function (data) {
                                },
                                error: function (data) {
                                    SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, data);
                                    errorUnpublishRuleFlag = true;
                                },
                                contentType: DuplicateDetection.DuplicateDetectionStrings.DDContentTypeRequest
                            });
                        }
                    }
                };
                /**
                * Handler for the Disabled button in the main Screen.
                */
                DuplicateDetectionControl.prototype.onDisabledButtonClicked = function () {
                    var that = this;
                    //Patch call for setting the duplicate detection flag as false
                    var organizationUpdateuri = this.context.utils.createCrmUri(DuplicateDetection.DuplicateDetectionStrings.CRMURI) + "/organizations(" + this._organizationID + ")";
                    $.ajax({
                        type: DuplicateDetection.DuplicateDetectionStrings.DDPatchRequest,
                        url: organizationUpdateuri,
                        data: '{"isduplicatedetectionenabled":"false","isduplicatedetectionenabledforimport":"false","isduplicatedetectionenabledforonlinecreateupdate":"false"}',
                        success: function (data) {
                            that.unPublishDuplicateRule();
                        },
                        contentType: DuplicateDetection.DuplicateDetectionStrings.DDContentTypeRequest
                    });
                    //To open an alert Dialog, if any of the duplicate rules are not present
                    if (this._duplicateRulesJsonData.value.length < 3) {
                        var alertMessage = {
                            text: this.context.resources.getString(DuplicateDetection.ResourceKeys.AlertLabel),
                            confirmButtonLabel: this.context.resources.getString(DuplicateDetection.ResourceKeys.OKLabel)
                        };
                        this.context.navigation.openAlertDialog(alertMessage);
                    }
                    //To Rerender the body container
                    if ((this._duplicateEnabledJsonData != null || this._duplicateEnabledJsonData != undefined) || (this._duplicateEnabledJsonData != null && this._duplicateEnabledJsonData.value != null)) {
                        this._duplicateEnabledJsonData = null;
                    }
                    this.context.utils.requestRender();
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "DisabledButton", DuplicateDetection.DuplicateDetectionStrings.SecondaryButtonID, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Disabled Duplicate Detection Rule", false);
                };
                /**
                 * Post call for Publishing the duplicateRules
                 */
                DuplicateDetectionControl.prototype.publishDuplicateRules = function () {
                    var that = this;
                    var i;
                    var errorPublishFlag = false;
                    var errorPublishFlag = false;
                    //Post call for Publishing the duplicateRules
                    for (i = 0; i < this._duplicateRulesJsonData.value.length; i++) {
                        if (this._duplicateRulesJsonData.value[i].duplicateruleid) {
                            var uriPublishRule = this.context.utils.createCrmUri(DuplicateDetection.DuplicateDetectionStrings.CRMURI + "/duplicaterules(" + this._duplicateRulesJsonData.value[i].duplicateruleid + ")/Microsoft.Dynamics.CRM.PublishDuplicateRule");
                            $.ajax({
                                type: DuplicateDetection.DuplicateDetectionStrings.DDPostRequest,
                                url: uriPublishRule,
                                data: null,
                                success: function (data) {
                                },
                                error: function (data) {
                                    SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that.context, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, data);
                                    errorPublishFlag = true;
                                },
                                contentType: DuplicateDetection.DuplicateDetectionStrings.DDContentTypeRequest
                            });
                        }
                        SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "EnabledButton", DuplicateDetection.DuplicateDetectionStrings.PrimaryButtonID, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Enabled Duplicate Detection Rule", false);
                    }
                };
                /**
                * Handler for the Enabled button in the main Screen.
                */
                DuplicateDetectionControl.prototype.onEnabledButtonClicked = function () {
                    var that = this;
                    //Patch call for setting the duplicate detection flag as false
                    var organizationUpdateuri = this.context.utils.createCrmUri(DuplicateDetection.DuplicateDetectionStrings.CRMURI) + "/organizations(" + this._organizationID + ")";
                    $.ajax({
                        type: DuplicateDetection.DuplicateDetectionStrings.DDPatchRequest,
                        url: organizationUpdateuri,
                        data: '{"isduplicatedetectionenabled":"true","isduplicatedetectionenabledforimport":"true","isduplicatedetectionenabledforonlinecreateupdate":"true"}',
                        success: function (data) {
                            that.publishDuplicateRules();
                        },
                        contentType: DuplicateDetection.DuplicateDetectionStrings.DDContentTypeRequest
                    });
                    //To open an alert Dialog, if any of the duplicate rules are not present
                    if (this._duplicateRulesJsonData.value.length < 3) {
                        var alertMessage = {
                            text: this.context.resources.getString(DuplicateDetection.ResourceKeys.AlertLabel),
                            confirmButtonLabel: this.context.resources.getString(DuplicateDetection.ResourceKeys.OKLabel)
                        };
                        this.context.navigation.openAlertDialog(alertMessage);
                    }
                    //To Rerender the body container
                    if ((this._duplicateEnabledJsonData != null || this._duplicateEnabledJsonData != undefined) || (this._duplicateEnabledJsonData != null && this._duplicateEnabledJsonData.value != null)) {
                        this._duplicateEnabledJsonData = null;
                    }
                    this.context.utils.requestRender();
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this.context, 1, SmbAppsTelemetryUtility.Controls_PageType.DUPLICATEDETECTION, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "EnabledButton", DuplicateDetection.DuplicateDetectionStrings.PrimaryButtonID, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Enabled Duplicate Detection Rule", false);
                };
                /**
                 * Rendering the TextBox for Duplicate Detection
                 */
                DuplicateDetectionControl.prototype.createTextBodyForDuplicateDetection = function () {
                    var disclaimerLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisclaimer_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisclaimer_Label,
                        style: this._applyStyles.DDDisclaimerLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.DisclaimerLabel));
                    var disclaimerMessageLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisclaimerMessage_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisclaimerMessage_Label,
                        style: this._applyStyles.DDDisclaimerMessageLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.DisclaimerMessageLabel));
                    var contactEntityLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDContacts_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDContacts_Label,
                        style: this._applyStyles.DDContactsEntityLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.ContactsLabel));
                    var sameNameLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDSameName_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDSameName_Label,
                        style: this._applyStyles.DDSameNameLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.SameNameLabel));
                    var sameEmailLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDSameEmail_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDSameEmail_Label,
                        style: this._applyStyles.DDSameEmailLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.SameEmailLabel));
                    var accountEntityLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDAccounts_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDAccounts_Label,
                        style: this._applyStyles.DDAccountsEntityLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.AccountsLabel));
                    var sameaccountnameLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDSameaccountname_Label,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDSameaccountname_Label,
                        style: this._applyStyles.DDSameAccountNameLabel()
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.SameAccountnameLabel));
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.TextContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.TextContainer,
                        style: this._applyStyles.DDDisclaimerTextContainer()
                    }, [disclaimerLabel, disclaimerMessageLabel, contactEntityLabel, sameNameLabel, sameEmailLabel, accountEntityLabel, sameaccountnameLabel]);
                };
                /**
                 * Rendering the Disabled Button
                 */
                DuplicateDetectionControl.prototype.createDisabledButtonContainer = function (noRetryReq) {
                    var DisabledButton = this.context.factory.createElement("BUTTON", {
                        key: DuplicateDetection.DuplicateDetectionStrings.SecondaryButtonID,
                        id: DuplicateDetection.DuplicateDetectionStrings.SecondaryButtonID,
                        style: this._applyStyles.FRESecondaryButton(),
                        onClick: this.onDisabledButtonClicked.bind(this),
                        tabIndex: 0
                    }, this.context.resources.getString(noRetryReq ? DuplicateDetection.ResourceKeys.DisableButton : DuplicateDetection.ResourceKeys.RetryDisableButton));
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DisableButton,
                        key: DuplicateDetection.DuplicateDetectionStrings.DisableButton,
                        style: this._applyStyles.DDDisableButtonContainer()
                    }, DisabledButton);
                };
                /**
                 * Rendering the Center Container when Duplicate Detection is Enabled
                 */
                DuplicateDetectionControl.prototype.createDuplicateDetectionActiveCenterContainer = function (noRetryReq) {
                    var centerImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDActiveImageCenterContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDActiveImageCenterContainer,
                        style: this._applyStyles.DDActiveImageContainer()
                    }, []);
                    var activeLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDActiveMiddleLabel,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDActiveMiddleLabel,
                        style: this._applyStyles.DDActiveMiddleLabel()
                    }, this.context.resources.getString(noRetryReq ? DuplicateDetection.ResourceKeys.ActiveLabel : DuplicateDetection.ResourceKeys.RetryActiveLabel));
                    var buttonControl = this.createDisabledButtonContainer(noRetryReq);
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDActiveCenterData,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDActiveCenterData,
                        style: this._applyStyles.DDActiveCenterContainer()
                    }, [centerImageContainer, activeLabel, buttonControl]);
                };
                /**
                 * Rendering the Complete Body when Duplicate Detection is Enabled
                 */
                DuplicateDetectionControl.prototype.createBodyForActivatedDuplicateDetection = function (noRetryReq) {
                    var textContainer = this.createTextBodyForDuplicateDetection();
                    if (noRetryReq) {
                        var centerContainer = this.createDuplicateDetectionActiveCenterContainer(noRetryReq);
                    }
                    else {
                        var centerContainer = this.createDuplicateDetectionDisabledCenterContainer(noRetryReq);
                    }
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        style: this._applyStyles.FRESectionContainer()
                    }, [textContainer, centerContainer]);
                };
                /**
                 * Rendering the Enabled Button
                 */
                DuplicateDetectionControl.prototype.createEnabledButtonContainer = function (noRetryReq) {
                    var EnabledButton = this.context.factory.createElement("BUTTON", {
                        key: DuplicateDetection.DuplicateDetectionStrings.PrimaryButtonID,
                        id: DuplicateDetection.DuplicateDetectionStrings.PrimaryButtonID,
                        style: this._applyStyles.FREPrimaryButton(),
                        onClick: this.onEnabledButtonClicked.bind(this),
                        tabIndex: 0
                    }, this.context.resources.getString(noRetryReq ? DuplicateDetection.ResourceKeys.EnableButton : DuplicateDetection.ResourceKeys.RetryEnableButton));
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.EnableButton,
                        key: DuplicateDetection.DuplicateDetectionStrings.EnableButton,
                        style: this._applyStyles.DDEnableButtonContainer()
                    }, EnabledButton);
                };
                /**
                 * Rendering the Center Container when Duplicate Detection is Disabled
                 */
                DuplicateDetectionControl.prototype.createDuplicateDetectionDisabledCenterContainer = function (noRetryReq) {
                    var centerImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisabledImageCenterContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisabledImageCenterContainer,
                        style: this._applyStyles.DDDisabledImageContainer()
                    }, []);
                    var disabledLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisabledMiddleLabel,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisabledMiddleLabel,
                        style: this._applyStyles.DDDisabledMiddleLabel()
                    }, this.context.resources.getString(noRetryReq ? DuplicateDetection.ResourceKeys.DisableLabel : DuplicateDetection.ResourceKeys.RetryDisableLabel));
                    var buttonControl = this.createEnabledButtonContainer(noRetryReq);
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisabledCenterData,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisabledCenterData,
                        style: this._applyStyles.DDDisabledCenterContainer()
                    }, [centerImageContainer, disabledLabel, buttonControl]);
                };
                /**
                 * Rendering the Complete Body with disclaimer when Duplicate Detection is Disabled
                 */
                DuplicateDetectionControl.prototype.createBodyForDisabledDuplicateDetection = function (noRetryReq) {
                    var textContainer = this.createTextBodyForDuplicateDetection();
                    if (noRetryReq) {
                        var centerContainer = this.createDuplicateDetectionDisabledCenterContainer(noRetryReq);
                    }
                    else {
                        var centerContainer = this.createDuplicateDetectionActiveCenterContainer(noRetryReq);
                    }
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        style: this._applyStyles.FRESectionContainer()
                    }, [textContainer, centerContainer]);
                };
                /**
                * Rendering the Center Container For Wait Page
                */
                DuplicateDetectionControl.prototype.createDuplicateDetectionWaitCenterContainer = function () {
                    var centerImageContainer = this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDWaitImageCenterContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDWaitImageCenterContainer,
                        style: this._applyStyles.DDWaitImageContainer()
                    }, []);
                    var disabledLabel = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisabledMiddleLabel,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisabledMiddleLabel,
                        style: this._applyStyles.DDDisabledCenterContainer(),
                        accessibilityLive: "assertive",
                        accessibilityRelevant: "all",
                        accessibilityAtomic: "true",
                        role: "alert"
                    }, this.context.resources.getString(DuplicateDetection.ResourceKeys.WaitLabel));
                    var waitLabelContainer = this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDWaitCenterLabel,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDWaitCenterLabel,
                        style: this._applyStyles.DDDisabledCenterContainer()
                    }, [disabledLabel]);
                    this.context.accessibility.focusElementById(DuplicateDetection.DuplicateDetectionStrings.DDWaitCenterLabel);
                    var waitContainer = this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.DDDisabledCenterData,
                        key: DuplicateDetection.DuplicateDetectionStrings.DDDisabledCenterData,
                        style: this._applyStyles.DDDisabledCenterContainer()
                    }, [centerImageContainer, waitLabelContainer]);
                    return waitContainer;
                };
                /**
                 * Rendering the Complete Body with disclaimer for Wait Page
                 */
                DuplicateDetectionControl.prototype.createBodyForWaitPageDuplicateDetection = function () {
                    var textContainer = this.createTextBodyForDuplicateDetection();
                    var centerContainer = this.createDuplicateDetectionWaitCenterContainer();
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        style: this._applyStyles.FRESectionContainer()
                    }, [textContainer, centerContainer]);
                };
                /**
                * Rendering the Loading Body container
                */
                DuplicateDetectionControl.prototype.createBodyForLoadingPageDuplicateDetection = function () {
                    var loadingtextContainer = this.context.factory.createElement("LABEL", {
                        id: DuplicateDetection.DuplicateDetectionStrings.PageLoadingID,
                        key: DuplicateDetection.DuplicateDetectionStrings.PageLoadingID
                    }, DuplicateDetection.DuplicateDetectionStrings.DDPageLoading);
                    return this.context.factory.createElement("CONTAINER", {
                        id: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        key: DuplicateDetection.DuplicateDetectionStrings.BodyContainer,
                        style: this._applyStyles.FRESectionContainer()
                    }, [loadingtextContainer]);
                };
                return DuplicateDetectionControl;
            }());
            DuplicateDetection.DuplicateDetectionControl = DuplicateDetectionControl;
        })(DuplicateDetection = AppCommon.DuplicateDetection || (AppCommon.DuplicateDetection = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="DuplicateDetection.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DuplicateDetection;
        (function (DuplicateDetection) {
            'use strict';
            var DuplicateDetectionStrings = (function () {
                function DuplicateDetectionStrings() {
                }
                Object.defineProperty(DuplicateDetectionStrings, "DDPageLoading", {
                    get: function () {
                        return "PageLoading";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDPatchRequest", {
                    get: function () {
                        return "PATCH";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDPostRequest", {
                    get: function () {
                        return "POST";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDContentTypeRequest", {
                    get: function () {
                        return "application/json";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "CRMURI", {
                    get: function () {
                        return "/api/data/v8.0";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DuplicateEnabledFlags", {
                    get: function () {
                        return "/organizations?$select=isduplicatedetectionenabled,isduplicatedetectionenabledforimport,isduplicatedetectionenabledforofflinesync,isduplicatedetectionenabledforonlinecreateupdate";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DuplicateDetectionRules", {
                    get: function () {
                        return "/duplicaterules?$select=name,statecode,statuscode &$filter=duplicateruleid eq 0c16fb72-201d-4581-9ed9-1d4ac969af81 or duplicateruleid eq 7b1003be-b33e-4c83-b8ae-f56c63487a2b or duplicateruleid eq d8d2e6cc-3a9b-48f8-a0c6-b9a1f10b9fb4";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDContactsWithSameNameLastName", {
                    get: function () {
                        return "Contacts with the same first name and last name";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDContactsWithSameEmailAddress", {
                    get: function () {
                        return "Contacts with the same e-mail address";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDAccountsWithSameAccountName", {
                    get: function () {
                        return "Accounts with the same Account Name";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "PageContainer", {
                    get: function () {
                        return "FREBodyContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "BodyContainer", {
                    get: function () {
                        return "FRESectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "HeaderContainer", {
                    get: function () {
                        return "FREHeaderContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDActiveImageCenterContainer", {
                    get: function () {
                        return "DD_DDActiveImageContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDDisabledImageCenterContainer", {
                    get: function () {
                        return "DD_DDDisabledImageContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDWaitImageCenterContainer", {
                    get: function () {
                        return "DD_DDWaitImageContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "InnerHeaderRight", {
                    get: function () {
                        return "FREHeaderLeft";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "HeaderTopLabel", {
                    get: function () {
                        return "FREHeaderAreaLabelStyle ";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "HeaderBottomLabel", {
                    get: function () {
                        return "FREHeaderSubareaLabelStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "Label", {
                    get: function () {
                        return "FREFieldLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDDisclaimer_Label", {
                    get: function () {
                        return "DD_DisclaimerLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDDisclaimerMessage_Label", {
                    get: function () {
                        return "DD_DisclaimerMessageLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDContacts_Label", {
                    get: function () {
                        return "DD_ContactsLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDSameName_Label", {
                    get: function () {
                        return "DD_SameNameLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDSameEmail_Label", {
                    get: function () {
                        return "DD_SameEmailLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDAccounts_Label", {
                    get: function () {
                        return "DD_AccountsLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDSameaccountname_Label", {
                    get: function () {
                        return "DD_SameaccountnameLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "BottomMiddleLabel", {
                    get: function () {
                        return "BottomMiddleLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "SectionLabel", {
                    get: function () {
                        return "FRESectionLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDActiveMiddleLabel", {
                    get: function () {
                        return "DD_ActiveMiddleLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDDisabledMiddleLabel", {
                    get: function () {
                        return "DD_DisabledMiddleLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDActiveCenterData", {
                    get: function () {
                        return "DD_ActiveCenterContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDDisabledCenterData", {
                    get: function () {
                        return "DD_DisabledCenterContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DDWaitCenterLabel", {
                    get: function () {
                        return "DD_WaitCenterLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "TextContainer", {
                    get: function () {
                        return "DD_DisclaimerTextContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "EnableButton", {
                    get: function () {
                        return "DD_EnableButton_Container";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "DisableButton", {
                    get: function () {
                        return "DD_DisableButton_Container";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "PrimaryButtonID", {
                    get: function () {
                        return "DD_FREPrimaryButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "SecondaryButtonID", {
                    get: function () {
                        return "DD_FRESecondaryButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "PageLoadingID", {
                    get: function () {
                        return "PageLoading";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/DuplicationDetection.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DuplicateDetectionStrings, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/DuplicationDetection_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return DuplicateDetectionStrings;
            }());
            DuplicateDetection.DuplicateDetectionStrings = DuplicateDetectionStrings;
        })(DuplicateDetection = AppCommon.DuplicateDetection || (AppCommon.DuplicateDetection = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DuplicateDetection;
        (function (DuplicateDetection) {
            var DuplicateDetectionStyles = (function (_super) {
                __extends(DuplicateDetectionStyles, _super);
                function DuplicateDetectionStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._dDGetExchangeServiceIcon = {};
                    _this._dDActiveImageContainer = {};
                    _this._dDDisabledImageContainer = {};
                    _this._dDDisclaimerTextContainer = {};
                    _this._dDDisclaimerLabel = {};
                    _this._dDDisclaimerMessageLabel = {};
                    _this._dDContactsLabel = {};
                    _this._dDSameNameLabel = {};
                    _this._dDSameEmailLabel = {};
                    _this._dDAccountsLabel = {};
                    _this._dDSameAccountNameLabel = {};
                    _this._dDActiveMiddleLabel = {};
                    _this._dDActiveCenterContainer = {};
                    _this._dDDisabledMiddleLabel = {};
                    _this._dDDisabledCenterContainer = {};
                    _this._dDEnableButtonContainer = {};
                    _this._dDDisableButtonContainer = {};
                    _this._dDWaitImageContainer = {};
                    _this._context = context;
                    _this._dDGetExchangeServiceIcon = null;
                    _this._dDActiveImageContainer = null;
                    _this._dDDisabledImageContainer = null;
                    _this._dDDisclaimerTextContainer = null;
                    _this._dDDisclaimerLabel = null;
                    _this._dDDisclaimerMessageLabel = null;
                    _this._dDContactsLabel = null;
                    _this._dDSameNameLabel = null;
                    _this._dDSameEmailLabel = null;
                    _this._dDAccountsLabel = null;
                    _this._dDSameAccountNameLabel = null;
                    _this._dDActiveMiddleLabel = null;
                    _this._dDActiveCenterContainer = null;
                    _this._dDDisabledMiddleLabel = null;
                    _this._dDDisabledCenterContainer = null;
                    _this._dDEnableButtonContainer = null;
                    _this._dDDisableButtonContainer = null;
                    _this._dDWaitImageContainer = null;
                    return _this;
                }
                DuplicateDetectionStyles.prototype.DDGetExchangeServiceIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDGetExchangeServiceIcon)) {
                        this._dDGetExchangeServiceIcon = {};
                        this._dDGetExchangeServiceIcon["height"] = "16px";
                    }
                    return this._dDGetExchangeServiceIcon;
                };
                DuplicateDetectionStyles.prototype.DDActiveImageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDActiveImageContainer)) {
                        //after
                        var _dDActiveImageContainerAfter = {};
                        _dDActiveImageContainerAfter["fontFamily"] = "IconFont";
                        _dDActiveImageContainerAfter["content"] = "\038a03";
                        _dDActiveImageContainerAfter["fontSize"] = "64px";
                        _dDActiveImageContainerAfter["color"] = "#47C21D";
                        this._dDActiveImageContainer = {};
                        this._dDActiveImageContainer["display"] = "flex";
                        this._dDActiveImageContainer["justifyContent"] = "center";
                        this._dDActiveImageContainer[":after"] = _dDActiveImageContainerAfter;
                    }
                    return this._dDActiveImageContainer;
                };
                DuplicateDetectionStyles.prototype.DDDisabledImageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisabledImageContainer)) {
                        //after
                        var _dDDisabledImageContainerAfter = {};
                        _dDDisabledImageContainerAfter["fontFamily"] = "IconFont";
                        _dDDisabledImageContainerAfter["content"] = "\e733";
                        _dDDisabledImageContainerAfter["fontSize"] = "64px";
                        _dDDisabledImageContainerAfter["color"] = "#dddddd";
                        this._dDDisabledImageContainer = {};
                        this._dDDisabledImageContainer["display"] = "flex";
                        this._dDDisabledImageContainer["justifyContent"] = "center";
                        this._dDDisabledImageContainer[":after"] = _dDDisabledImageContainerAfter;
                    }
                    return this._dDDisabledImageContainer;
                };
                DuplicateDetectionStyles.prototype.DDWaitImageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDWaitImageContainer)) {
                        //after
                        var _dDWaitImageContainerAfter = {};
                        _dDWaitImageContainerAfter["fontFamily"] = "IconFont";
                        _dDWaitImageContainerAfter["content"] = "\ea03";
                        _dDWaitImageContainerAfter["fontSize"] = "64px";
                        _dDWaitImageContainerAfter["color"] = "#F2C624";
                        this._dDWaitImageContainer = {};
                        this._dDWaitImageContainer["display"] = "flex";
                        this._dDWaitImageContainer["justifyContent"] = "center";
                        this._dDWaitImageContainer[":after"] = _dDWaitImageContainerAfter;
                    }
                    return this._dDWaitImageContainer;
                };
                DuplicateDetectionStyles.prototype.DDDisclaimerTextContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisclaimerTextContainer)) {
                        this._dDDisclaimerTextContainer = {};
                        this._dDDisclaimerTextContainer["flex"] = "0 0 auto";
                        this._dDDisclaimerTextContainer["border"] = this._context.theming.borders.border02;
                        this._dDDisclaimerTextContainer["background"] = this._context.theming.colors.basecolor.white;
                        this._dDDisclaimerTextContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerTextContainer["marginBottom"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerTextContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerTextContainer["marginTop"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerTextContainer["display"] = "flex";
                        this._dDDisclaimerTextContainer["flexDirection"] = "column";
                    }
                    return this._dDDisclaimerTextContainer;
                };
                DuplicateDetectionStyles.prototype.DDDisclaimerLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisclaimerLabel)) {
                        this._dDDisclaimerLabel = {};
                        this._dDDisclaimerLabel["fontFamily"] = this._context.theming.fontfamilies.bold;
                        this._dDDisclaimerLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDDisclaimerLabel["lineHeight"] = "1.4rem";
                        this._dDDisclaimerLabel["marginTop"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDDisclaimerLabel;
                };
                DuplicateDetectionStyles.prototype.DDDisclaimerMessageLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisclaimerMessageLabel)) {
                        this._dDDisclaimerMessageLabel = {};
                        this._dDDisclaimerMessageLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDDisclaimerMessageLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDDisclaimerMessageLabel["lineHeight"] = "1.4rem";
                        this._dDDisclaimerMessageLabel["marginTop"] = this._context.theming.measures.measure050;
                        this._dDDisclaimerMessageLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerMessageLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDDisclaimerMessageLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDDisclaimerMessageLabel;
                };
                DuplicateDetectionStyles.prototype.DDContactsEntityLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDContactsLabel)) {
                        this._dDContactsLabel = {};
                        this._dDContactsLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDContactsLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDContactsLabel["lineHeight"] = "1.4rem";
                        this._dDContactsLabel["marginTop"] = this._context.theming.measures.measure050;
                        this._dDContactsLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDContactsLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDContactsLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDContactsLabel;
                };
                DuplicateDetectionStyles.prototype.DDSameNameLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDSameNameLabel)) {
                        this._dDSameNameLabel = {};
                        this._dDSameNameLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDSameNameLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDSameNameLabel["lineHeight"] = "1.4rem";
                        this._dDSameNameLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDSameNameLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDSameNameLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDSameNameLabel;
                };
                DuplicateDetectionStyles.prototype.DDSameEmailLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDSameEmailLabel)) {
                        this._dDSameEmailLabel = {};
                        this._dDSameEmailLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDSameEmailLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDSameEmailLabel["lineHeight"] = "1.4rem";
                        this._dDSameEmailLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDSameEmailLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDSameEmailLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDSameEmailLabel;
                };
                DuplicateDetectionStyles.prototype.DDAccountsEntityLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDAccountsLabel)) {
                        this._dDAccountsLabel = {};
                        this._dDAccountsLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDAccountsLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDAccountsLabel["lineHeight"] = "1.4rem";
                        this._dDAccountsLabel["marginTop"] = this._context.theming.measures.measure050;
                        this._dDAccountsLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDAccountsLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDAccountsLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDAccountsLabel;
                };
                DuplicateDetectionStyles.prototype.DDSameAccountNameLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDSameAccountNameLabel)) {
                        this._dDSameAccountNameLabel = {};
                        this._dDSameAccountNameLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDSameAccountNameLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDSameAccountNameLabel["lineHeight"] = "1.4rem";
                        this._dDSameAccountNameLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._dDSameAccountNameLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._dDSameAccountNameLabel["marginBottom"] = this._context.theming.measures.measure075;
                        this._dDSameAccountNameLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._dDSameAccountNameLabel;
                };
                DuplicateDetectionStyles.prototype.DDActiveMiddleLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDActiveMiddleLabel)) {
                        this._dDActiveMiddleLabel = {};
                        this._dDActiveMiddleLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDActiveMiddleLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDActiveMiddleLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._dDActiveMiddleLabel["lineHeight"] = "1.4rem";
                        this._dDActiveMiddleLabel["textAlign"] = "center";
                        this._dDActiveMiddleLabel["marginLeft"] = "20%";
                        this._dDActiveMiddleLabel["marginRight"] = "20%";
                        this._dDActiveMiddleLabel["marginTop"] = this._context.theming.measures.measure150;
                    }
                    return this._dDActiveMiddleLabel;
                };
                DuplicateDetectionStyles.prototype.DDActiveCenterContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDActiveCenterContainer)) {
                        this._dDActiveCenterContainer = {};
                        this._dDActiveCenterContainer["display"] = "flex";
                        this._dDActiveCenterContainer["alignItems"] = "center";
                        this._dDActiveCenterContainer["flexDirection"] = "column";
                        this._dDActiveCenterContainer["justifyContent"] = "center";
                        this._dDActiveCenterContainer["flex"] = "0 0 auto";
                        this._dDActiveCenterContainer["background"] = this._context.theming.colors.basecolor.white;
                    }
                    return this._dDActiveCenterContainer;
                };
                DuplicateDetectionStyles.prototype.DDDisabledMiddleLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisabledMiddleLabel)) {
                        this._dDDisabledMiddleLabel = {};
                        this._dDDisabledMiddleLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._dDDisabledMiddleLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._dDDisabledMiddleLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._dDDisabledMiddleLabel["lineHeight"] = "1.4rem";
                        this._dDDisabledMiddleLabel["textAlign"] = "center";
                        this._dDDisabledMiddleLabel["marginTop"] = this._context.theming.measures.measure150;
                        this._dDDisabledMiddleLabel["marginLeft"] = "20%";
                        this._dDDisabledMiddleLabel["marginRight"] = "20%";
                    }
                    return this._dDDisabledMiddleLabel;
                };
                DuplicateDetectionStyles.prototype.DDDisabledCenterContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisabledCenterContainer)) {
                        this._dDDisabledCenterContainer = {};
                        this._dDDisabledCenterContainer["display"] = "flex";
                        this._dDDisabledCenterContainer["alignItems"] = "center";
                        this._dDDisabledCenterContainer["flexDirection"] = "column";
                        this._dDDisabledCenterContainer["justifyContent"] = "center";
                        this._dDDisabledCenterContainer["flex"] = "0 0 auto";
                        this._dDDisabledCenterContainer["background"] = this._context.theming.colors.basecolor.white;
                    }
                    return this._dDDisabledCenterContainer;
                };
                DuplicateDetectionStyles.prototype.DDEnableButtonContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDEnableButtonContainer)) {
                        this._dDEnableButtonContainer = {};
                        this._dDEnableButtonContainer["display"] = "inlineFlex";
                        this._dDEnableButtonContainer["flexDirection"] = "column";
                        this._dDEnableButtonContainer["alignSelf"] = "center";
                        this._dDEnableButtonContainer["marginTop"] = this._context.theming.measures.measure075;
                    }
                    return this._dDEnableButtonContainer;
                };
                DuplicateDetectionStyles.prototype.DDDisableButtonContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._dDDisableButtonContainer)) {
                        this._dDDisableButtonContainer = {};
                        this._dDDisableButtonContainer["display"] = "inlineFlex";
                        this._dDDisableButtonContainer["flexDirection"] = "column";
                        this._dDDisableButtonContainer["alignSelf"] = "center";
                        this._dDDisableButtonContainer["marginTop"] = this._context.theming.measures.measure075;
                    }
                    return this._dDDisableButtonContainer;
                };
                return DuplicateDetectionStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            DuplicateDetection.DuplicateDetectionStyles = DuplicateDetectionStyles;
        })(DuplicateDetection = AppCommon.DuplicateDetection || (AppCommon.DuplicateDetection = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DuplicateDetection;
        (function (DuplicateDetection) {
            /**
                * Class refers to the strings in the cusotm control.
                */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "DisclaimerLabel", {
                    get: function () {
                        return "DisclaimerLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DisclaimerMessageLabel", {
                    get: function () {
                        return "DisclaimerMessageLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ContactsLabel", {
                    get: function () {
                        return "ContactsLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SameNameLabel", {
                    get: function () {
                        return "SameNameLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SameEmailLabel", {
                    get: function () {
                        return "SameEmailLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AccountsLabel", {
                    get: function () {
                        return "AccountsLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SameAccountnameLabel", {
                    get: function () {
                        return "SameAccountnameLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ActiveLabel", {
                    get: function () {
                        return "ActiveLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DisableLabel", {
                    get: function () {
                        return "DisableLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "WaitLabel", {
                    get: function () {
                        return "WaitLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DisableButton", {
                    get: function () {
                        return "DisableButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "EnableButton", {
                    get: function () {
                        return "EnableButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RetryActiveLabel", {
                    get: function () {
                        return "RetryActiveLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RetryDisableLabel", {
                    get: function () {
                        return "RetryDisableLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RetryDisableButton", {
                    get: function () {
                        return "RetryDisableButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "RetryEnableButton", {
                    get: function () {
                        return "RetryEnableButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "BusinessManagementLabel", {
                    get: function () {
                        return "BusinessManagementLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DuplicateDetectionLabel", {
                    get: function () {
                        return "DuplicateDetectionLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SameNameRuleAvailableLabel", {
                    get: function () {
                        return "SameNameRuleAvailableLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SameEmailRuleAvailableLabel", {
                    get: function () {
                        return "SameEmailRuleAvailableLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SameAccountRuleAvailableLabel", {
                    get: function () {
                        return "SameAccountRuleAvailableLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "OKLabel", {
                    get: function () {
                        return "OKLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AlertLabel", {
                    get: function () {
                        return "AlertLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            DuplicateDetection.ResourceKeys = ResourceKeys;
        })(DuplicateDetection = AppCommon.DuplicateDetection || (AppCommon.DuplicateDetection = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=DuplicateDetection.js.map