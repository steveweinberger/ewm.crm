var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ODataContract;
(function (ODataContract) {
    var ConfigureAndApplyEmailSettingsRequest = (function () {
        function ConfigureAndApplyEmailSettingsRequest(enableCrmAppForOutlook) {
            this.EnableCrmAppForOutlook = enableCrmAppForOutlook;
        }
        ConfigureAndApplyEmailSettingsRequest.prototype.getMetadata = function () {
            {
                var metadata = {
                    boundParameter: null,
                    operationName: "ConfigureAndApplyEmailSettings",
                    operationType: 0,
                    parameterTypes: {
                        "EnableCrmAppForOutlook": {
                            "typeName": "Edm.Boolean",
                            "structuralProperty": 1,
                        },
                    },
                };
                return metadata;
            }
        };
        return ConfigureAndApplyEmailSettingsRequest;
    }());
    ODataContract.ConfigureAndApplyEmailSettingsRequest = ConfigureAndApplyEmailSettingsRequest;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path= "../../Controls/FREShell/DataContracts/ConfigureAndApplyEmailSettingsRequest.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="PrivateReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EmailSetup;
        (function (EmailSetup) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var ConfigureAndApplyEmailSettingsRequest = ODataContract.ConfigureAndApplyEmailSettingsRequest;
            var RetrieveTenantInfoRequest = ODataContract.RetrieveTenantInfoRequest;
            var AdvancedEmailSetup = (function () {
                /**
                 * Empty constructor.
                 */
                function AdvancedEmailSetup() {
                    /**
                    * Flag to check if the rendering is complete.
                    **/
                    this._isRendered = false;
                    /**
                     * The method that returns the image to display when a service is not configured.
                     */
                    this.GetServiceDetailsMissingConfiguredIcon = function () {
                        var missingServiceConfigurationStatusIcon = this._context.factory.createElement("CONTAINER", {
                            key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_ICON_ID_SEED,
                            id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_ICON_ID_SEED,
                            style: this._applyStyles.EmailSetupServiceDetailsMissingConfiguredIcon()
                        }, []);
                        return missingServiceConfigurationStatusIcon;
                    };
                    /**
                     * The method that returns the image to display when a service is not detected.
                     */
                    this.GetServiceDetailsPromptPurchaseIcon = function () {
                        var promptServicePurchaseStatusIcon = this._context.factory.createElement("CONTAINER", {
                            key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_ICON_ID_SEED,
                            id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_ICON_ID_SEED,
                            style: this._applyStyles.EmailSetupPromptServicePurchaseStatusIcon()
                        }, []);
                        return promptServicePurchaseStatusIcon;
                    };
                    this._isExchangeDetected = null;
                    this._isExchangeConfigured = null;
                    this._applyStyles = null;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                AdvancedEmailSetup.prototype.init = function (context, notifyOutputChanged, state, container) {
                    this._context = context;
                    var title = this._context.resources.getString(EmailSetup.ResourceKeys.MicrosoftDynamics365Text);
                    if (this.IsAppshellmodeBasic()) {
                        title = this._context.resources.getString(EmailSetup.ResourceKeys.QuickSetupText) + " - " + this._context.resources.getString(EmailSetup.ResourceKeys.MicrosoftDynamics365Text);
                    }
                    else {
                        title = this._context.resources.getString(EmailSetup.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(EmailSetup.ResourceKeys.Email) + " - " + this._context.resources.getString(EmailSetup.ResourceKeys.MicrosoftDynamics365Text);
                    }
                    this._freShell = new FREShell(context, title);
                    try {
                        this.ValidateExchangeLicenceAvailability();
                        this.ValidateEmailSettingsConfiguration();
                    }
                    catch (ex) {
                        this.openAlertDialog(this._context, ex);
                    }
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * The structure of components in the control:
                 * bodyContainer
                 * |----headerContainer
                 *          |----headerIconContainer
                 *          |----headerTextContainer
                 *                      |----GroupLabel
                 *                      |----HeaderLabel
                 *          |----bodyContainer
                 *                     |----sectionListingContainer
                 *                               |----listingContainer
                 *                                        |----ServiceIcon
                 *                                        |----ServiceLabel
                 *                                        |----ServiceStatusIcon
                 *                     |----sectionBodyContainer
                 *                                |---- EmailGrid
                 *
                 * @params context The "Input Bag" as described above
                 */
                AdvancedEmailSetup.prototype.updateView = function (context) {
                    this._context = context;
                    this._applyStyles = new EmailSetup.EmailSetupStyles(context);
                    return this._freShell.getVirtualComponents(this.getChildControls());
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                AdvancedEmailSetup.prototype.getChildControls = function () {
                    var params = {};
                    params.areaLabel = this._context.resources.getString(EmailSetup.ResourceKeys.CommunicationAndCollaboration);
                    params.subAreaLabel = this._context.resources.getString(EmailSetup.ResourceKeys.Email);
                    //icon content
                    params.normalIconImagePath = EmailSetup.ResourcePath.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = EmailSetup.ResourcePath.HeaderHighContrastIconImagePath;
                    params.contentContainerChild = this._containerBody();
                    this._freShell.stopPerformanceStopWatch(); //This will give very low perf numbers. Need to get call back from Grid when data load is complete to make sense.
                    return params;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                AdvancedEmailSetup.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * Returns the service icon in service listing
                 */
                AdvancedEmailSetup.prototype._containerAttrServiceExchangeIcon = function () {
                    var exchangeIcon = this._context.factory.createElement("IMG", {
                        id: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_ICON_ID_SEED,
                        key: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_ICON_ID_SEED,
                        source: this._getExchangeIconPath(),
                        altText: this._context.resources.getString(EmailSetup.ResourceKeys.Exchange),
                        style: this._applyStyles.EmailSetupAttributeServiceExchangeIcon()
                    }, []);
                    return exchangeIcon;
                };
                /**
                 * Returns the Icon Path for Exchange based on High Contrast Settings
                 */
                AdvancedEmailSetup.prototype._getExchangeIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return EmailSetup.ResourcePath.ExchangeIconHC;
                    }
                    else {
                        return EmailSetup.ResourcePath.ExchangeIcon;
                    }
                };
                /**
                 * Returns the Success Icon Path for Exchange based on High Contrast Settings
                 */
                AdvancedEmailSetup.prototype._getSuccessIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return EmailSetup.ResourcePath.SuccessIconHC;
                    }
                    else {
                        return EmailSetup.ResourcePath.SuccessIcon;
                    }
                };
                /**
                 * Returns the Error Icon Path for Exchange based on High Contrast Settings
                 */
                AdvancedEmailSetup.prototype._getErrorIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return EmailSetup.ResourcePath.ErrorIconHC;
                    }
                    else {
                        return EmailSetup.ResourcePath.ErrorIcon;
                    }
                };
                /**
                 * Returns the Progress Icon Path for Exchange based on High Contrast Settings
                 */
                AdvancedEmailSetup.prototype._getProgressIconPath = function () {
                    if (this._context.accessibility.isHighContrastEnabled) {
                        return EmailSetup.ResourcePath.ProgressIconHC;
                    }
                    else {
                        return EmailSetup.ResourcePath.ProgressIcon;
                    }
                };
                /**
                 * Returns the service name in service listing
                 */
                AdvancedEmailSetup.prototype._containerAttrServiceExchangeName = function () {
                    var service = this._context.factory.createElement("LABEL", {
                        id: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_NAME_ID_SEED,
                        key: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_NAME_ID_SEED,
                        style: this._applyStyles.FRETabContainerNameStyle()
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.Exchange));
                    return service;
                };
                /**
                 * Returns the service status in service listing
                 */
                AdvancedEmailSetup.prototype._containerAttrServiceExchangeStatus = function (iconSourceStr) {
                    var statusIcon = this._context.factory.createElement("IMG", {
                        id: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_STATUS_ID_SEED,
                        key: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_STATUS_ID_SEED,
                        source: iconSourceStr,
                        altText: this._context.resources.getString(EmailSetup.ResourceKeys.SuccessMessageText),
                        style: this._applyStyles.EmailSetupAttributeServiceExchangeStatus()
                    });
                    return statusIcon;
                };
                /**
                 * Returns the service container for exchange in service listing
                 */
                AdvancedEmailSetup.prototype._containerAttrServiceExchange = function () {
                    var iconSourceStr = this.GetExchangeServiceStatusIconResourcePath();
                    var exchangeServiceStatusIcon = iconSourceStr != null ? this._containerAttrServiceExchangeStatus(iconSourceStr) : null;
                    var exchange = this._context.factory.createElement("BUTTON", {
                        id: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_EXCHANGE_ID_SEED,
                        key: AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_EXCHANGE_ID_SEED,
                        style: this._applyStyles.FRETabContainerStyle()
                    }, [this._containerAttrServiceExchangeIcon(), this._containerAttrServiceExchangeName(), exchangeServiceStatusIcon]);
                    return exchange;
                };
                /**
                 * Returns the list of services container. Currently there is only exchange service.
                 */
                AdvancedEmailSetup.prototype._containerAttrServiceList = function () {
                    var servicelist = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedEmailSetup.ATTR_SERVICES_LIST_ID_SEED,
                        key: AdvancedEmailSetup.ATTR_SERVICES_LIST_ID_SEED,
                        style: this._applyStyles.EmailSetupAttributeServiceList()
                    }, [this._containerAttrServiceExchange()]);
                    return servicelist;
                };
                /**
                 * Returns the grid for the mailboxes
                 * The grid displays the result of a saved query with id: 3231f3e9-2ff4-e611-80d3-00155d0c1809
                 * The details of the grid shown are in the path
                 * {xRM Solutions}/solutions/AppCommon/Solution/Entities/Mailbox
                 */
                AdvancedEmailSetup.prototype._containerAttrGrid = function () {
                    var gridProps = {
                        parameters: {
                            Grid: {
                                Type: "Grid",
                                TargetEntityType: "mailbox",
                                ViewId: "3231f3e9-2ff4-e611-80d3-00155d0c1809",
                                DataSetHostProps: {
                                    commandBarEnabled: true,
                                    jumpBarEnabled: true,
                                    quickFindEnabled: true,
                                    viewSelectorEnabled: false
                                }
                            },
                            EnableGroupBy: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            },
                            EnableFiltering: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            },
                            EnableEditing: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            }
                        }
                    };
                    var grid = this._context.factory.createComponent("MscrmControls.Grid.GridControl", "mailboxViewList", gridProps);
                    var gridContainer = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedEmailSetup.ATTR_GRID_CONTAINER_ID_SEED,
                        key: AdvancedEmailSetup.ATTR_GRID_CONTAINER_ID_SEED,
                        style: this._applyStyles.FREGridContainer()
                    }, [grid]);
                    return gridContainer;
                };
                /**
                 * Returns the container which displays the details of the service selected.
                 * This container also shows the nudge on the service selected from the listing.
                 */
                AdvancedEmailSetup.prototype._containerServiceDetailsExchange = function () {
                    var innerBodyContainer = this.GetInnerBodyContainerForExchangeService();
                    var exchangeContainer = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedEmailSetup.ATTR_SERVICE_DETAILS_ID_SEED_NO_NUDGE,
                        key: AdvancedEmailSetup.ATTR_SERVICE_DETAILS_ID_SEED_NO_NUDGE,
                        style: this._applyStyles.EmailSetupServiceDetailsExchange()
                    }, [innerBodyContainer]);
                    return exchangeContainer;
                };
                /**
                 * Returns the body container which contains the service listing and the service details
                 */
                AdvancedEmailSetup.prototype._containerBody = function () {
                    var body = this._context.factory.createElement("CONTAINER", {
                        id: AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_BODY_ID_SEED,
                        key: AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_BODY_ID_SEED,
                        style: this._applyStyles.FRESectionContainer()
                    }, [this._containerAttrServiceList(), this._containerServiceDetailsExchange()]);
                    return body;
                };
                /**
                * The method containing the logic to return the appropriate inner body container to render for exchange service.
                */
                AdvancedEmailSetup.prototype.GetInnerBodyContainerForExchangeService = function () {
                    var innerBodyContainer = null;
                    var exchangeServiceDescriptionLabel = this.GetExchangeServiceDescriptionLabel();
                    if (!this._context.utils.isNullOrUndefined(this._isExchangeDetected)) {
                        if (this._isExchangeDetected == "true") {
                            if (!this._context.utils.isNullOrUndefined(this._isExchangeConfigured)) {
                                if (this._isExchangeConfigured == "true") {
                                    // need to show the grid here
                                    innerBodyContainer = this._containerAttrGrid();
                                }
                                else if (this._isExchangeConfigured == "false") {
                                    // need to show the configure button here
                                    innerBodyContainer = this.GetExchangeConfigurationPromptcontainer();
                                }
                            }
                        }
                        else if (this._isExchangeDetected == "false") {
                            // need to show the Purchase service container here
                            innerBodyContainer = this.GetPurchaseExchangePromptContainer();
                        }
                    }
                    var exchangeBodyContainer = this._context.factory.createElement("CONTAINER", {
                        key: AdvancedEmailSetup.ATTR_EXCHANGE_SERVICE_BODY_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_EXCHANGE_SERVICE_BODY_ID_SEED,
                        style: this._applyStyles.EmailSetupExchangeBodyContainer()
                    }, [exchangeServiceDescriptionLabel, innerBodyContainer]);
                    return exchangeBodyContainer;
                };
                /**
                 * Returns the container consisting of excahnge service description, not configured icon, text and 'Configure' Button for exchange service.
                 */
                AdvancedEmailSetup.prototype.GetExchangeConfigurationPromptcontainer = function () {
                    var missingConfigurationStatusIcon = this.GetServiceDetailsMissingConfiguredIcon();
                    var missingConfigurationStatusLabel = this._context.factory.createElement("LABEL", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_LABEL_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_LABEL_ID_SEED,
                        style: this._applyStyles.EmailSetupMissingConfigurationStatusLabel()
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.PromptConfigurationStatus));
                    var promptConfigurationConsentButton = this._context.factory.createElement("BUTTON", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_BUTTON_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_BUTTON_ID_SEED,
                        onClick: this.PromptExchangeConfigurationConsent.bind(this),
                        tabIndex: 0,
                        style: this._applyStyles.EmailSetupPromptConfigurationConsentButton()
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.PromptConfigurationButtonText));
                    var exchangeConfigurationPromptContainer = this._context.factory.createElement("CONTAINER", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_CONTAINER_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_CONTAINER_ID_SEED,
                        style: this._applyStyles.EmailSetupExchangeConfigurationPromptContainer()
                    }, [missingConfigurationStatusIcon, missingConfigurationStatusLabel, promptConfigurationConsentButton]);
                    // wrap the above container so that it has a new parent div for styling.
                    var exchangeConfigurationPromptContainerWrapper = this._context.factory.createElement("CONTAINER", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_CONTAINER_WRAPPER_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_CONTAINER_WRAPPER_ID_SEED,
                        style: this._applyStyles.EmailSetupExchangeConfigurationPromptWrapperContainer()
                    }, [exchangeConfigurationPromptContainer]);
                    return exchangeConfigurationPromptContainerWrapper;
                };
                /**
                 * Returns the container containing the not detected icon, text with a hyperlink for exchange service.
                 */
                AdvancedEmailSetup.prototype.GetPurchaseExchangePromptContainer = function () {
                    var missingExchangeServiceStatusIcon = this.GetServiceDetailsPromptPurchaseIcon();
                    var missingExchangeServiceStatusLabelPrefix = this._context.factory.createElement("LABEL", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_PREFIX_LABEL_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_PREFIX_LABEL_ID_SEED
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.PurchaseExchangeServiceLabelPrefix));
                    var hyperlinkToPurchaseExchange = this._context.factory.createElement("HYPERLINK", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_HREF_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_HREF_ID_SEED,
                        href: this._context.resources.getString(AdvancedEmailSetup.PurchaseExchangeServiceHyperlinkStr),
                        target: "_blank",
                        tabIndex: 0
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.PurchaseExchangeServiceHyperlinkLabel));
                    var missingExchangeServiceStatusLabelSuffix = this._context.factory.createElement("LABEL", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_SUFFIX_LABEL_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_SUFFIX_LABEL_ID_SEED
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.PurchaseExchangeServiceLabelSuffix));
                    var purchaseExhangeMessageContainer = this._context.factory.createElement("CONTAINER", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_MSG_CONTAINER_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_MSG_CONTAINER_ID_SEED,
                        style: this._applyStyles.EmailSetupPurchaseExhangeMessageContainer()
                    }, [missingExchangeServiceStatusLabelPrefix, hyperlinkToPurchaseExchange, missingExchangeServiceStatusLabelSuffix]);
                    var purchaseExhangePromptContainer = this._context.factory.createElement("CONTAINER", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_CONTAINER_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_CONTAINER_ID_SEED,
                        style: this._applyStyles.EmailSetupExchangePurchasePromptContainer()
                    }, [missingExchangeServiceStatusIcon, purchaseExhangeMessageContainer]);
                    // wrap the above container so that it has a new parent div for styling.
                    var purchaseExhangePromptWrapperContainer = this._context.factory.createElement("CONTAINER", {
                        key: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_WRAPPER_CONTAINER_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_WRAPPER_CONTAINER_ID_SEED,
                        style: this._applyStyles.EmailSetupExchangePurchasePromptWrapperContainer()
                    }, [purchaseExhangePromptContainer]);
                    return purchaseExhangePromptWrapperContainer;
                };
                /**
                 * The method that returns the label container explainig the description of exchange service.
                 */
                AdvancedEmailSetup.prototype.GetExchangeServiceDescriptionLabel = function () {
                    var exchangeServiceDescription = this._context.factory.createElement("LABEL", {
                        key: AdvancedEmailSetup.ATTR_EXCHANGE_SERVICE_DESCRIPTION_LABEL_ID_SEED,
                        id: AdvancedEmailSetup.ATTR_EXCHANGE_SERVICE_DESCRIPTION_LABEL_ID_SEED,
                        style: this._applyStyles.EmailSetupExchangeServiceDescriptionLabel()
                    }, this._context.resources.getString(EmailSetup.ResourceKeys.ExchangeServiceDescription));
                    return exchangeServiceDescription;
                };
                /**
                * The method calls the RetrieveInfo SDK and parses the response for Exhange Assigned Plan as Enabled.
                */
                AdvancedEmailSetup.prototype.ValidateExchangeLicenceAvailability = function () {
                    var thisCopy = this; //copy this to a local var since on async respone this gets nullfied.
                    if (this._isExchangeDetected == null) {
                        var retrieveTenantInfoRequestObj = new RetrieveTenantInfoRequest();
                        thisCopy._context.webAPI.execute(retrieveTenantInfoRequestObj).then(function (response) {
                            if (response) {
                                response.json().then(function (jsonResponse) {
                                    var exchangeAssignedPlan = JSON.parse(jsonResponse.TenantInfo).exchange;
                                    if (!thisCopy._context.utils.isNullOrUndefined(exchangeAssignedPlan) && exchangeAssignedPlan == "True") {
                                        thisCopy._isExchangeDetected = "true";
                                    }
                                    else {
                                        thisCopy._isExchangeDetected = "false";
                                    }
                                    // Re-render the page container. This will internally call UpdateView.
                                    thisCopy._context.utils.requestRender();
                                });
                            }
                        }, function (error) {
                            SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(thisCopy._context, SmbAppsTelemetryUtility.Controls_PageType.EMAILTEMPLATE, error);
                            thisCopy.openAlertDialog(thisCopy._context, error);
                        });
                    }
                };
                /**
                 *The method containing the logic to decide the current state of the Email configuration.
                    * The exchange service is said to be configured if the below is true for any one mailbox:
                    1. testemailconfigurationscheduled is set to true.
                    1. incomingemailstatus, outgoingemailstatus and actstatus is set to success(1)
                    2. incomingemailstatus, outgoingemailstatus and actstatus is set to Failure(2)
                    *
                 */
                AdvancedEmailSetup.prototype.GetEmailSettingsconfigurationStatusQuery = function () {
                    var layoutXml = "?$select=mailboxid&$top=1&";
                    var fetchXml = "$filter=testemailconfigurationscheduled eq true or " +
                        "actstatus eq 1 or outgoingemailstatus eq 1 or incomingemailstatus eq 1 or " +
                        "actstatus eq 2 or outgoingemailstatus eq 2 or incomingemailstatus eq 2";
                    var savedQuery = layoutXml + fetchXml;
                    return savedQuery;
                };
                /**
                   * Validate if the exchange is already configured according to the logic mentioned in GetEmailSettingsconfigurationStatusQuery().
                   * If yes we need to display the grid. thisCopy._context.utils.requestRender() takes care of proper rendering.
                   */
                AdvancedEmailSetup.prototype.ValidateEmailSettingsConfiguration = function () {
                    var thisCopy = this; //copy this to a local var since on async respone this gets nullfied.
                    if (this._isExchangeConfigured == null) {
                        this._context.webAPI.retrieveMultipleRecords("mailbox", this.GetEmailSettingsconfigurationStatusQuery()).then(function (response) {
                            var entities = response.entities;
                            if (entities.length > 0) {
                                thisCopy._isExchangeConfigured = "true";
                            }
                            else {
                                thisCopy._isExchangeConfigured = "false";
                            }
                            // Re-render the page container. This will internally call UpdateView.
                            thisCopy._context.utils.requestRender();
                        }, function (error) {
                            SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(thisCopy._context, SmbAppsTelemetryUtility.Controls_PageType.EMAILTEMPLATE, error);
                            thisCopy.openAlertDialog(thisCopy._context, error);
                        });
                    }
                };
                /**
                * The method opens the MDD asking for consent from the user to configure exchange service.
                */
                AdvancedEmailSetup.prototype.PromptExchangeConfigurationConsent = function () {
                    var dialogOptions = {
                        position: 2 /* side */,
                        width: 100
                    };
                    var dialogParams = {
                        cancel_button_label: this._context.resources.getString(EmailSetup.ResourceKeys.ExchangeConsentDialogCancelLabel),
                        ok_button_label: this._context.resources.getString(EmailSetup.ResourceKeys.ExchangeConsentDialogOkLabel),
                        header_label: this._context.resources.getString(EmailSetup.ResourceKeys.ExchangeConsentDialogTitle),
                        html_page_url: this._context.page.getClientUrl() + "/WebResources/AppCommon/ControlWS/EmailConsentDialog/EmailSetupConsentMessage.htm"
                    };
                    var thisCopy = this;
                    this._context.navigation.openDialog(AdvancedEmailSetup.MDD_DIALOG_UNIQUE_NAME, dialogOptions, dialogParams).then(function (response) {
                        if (response && response.parameters &&
                            response.parameters[AdvancedEmailSetup.MDD_DIALOG_PARAM_LAST_BUTTON_CLICKED] === AdvancedEmailSetup.MDD_DIALOG_OK_BUTTON_ID) {
                            var shouldEnableCrmAppForOutlook = true;
                            var configureEmailSetupRequest = new ConfigureAndApplyEmailSettingsRequest(shouldEnableCrmAppForOutlook);
                            thisCopy._context.webAPI.execute(configureEmailSetupRequest).then(function (response) {
                                if (response && (response.ok == true || response.status == 204)) {
                                    thisCopy._isExchangeConfigured = "true";
                                }
                                else {
                                    thisCopy._isExchangeConfigured = "false";
                                }
                                // Re-render the page container. This will internally call UpdateView.
                                thisCopy._context.utils.requestRender();
                            }, function (error) {
                                SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(thisCopy._context, SmbAppsTelemetryUtility.Controls_PageType.EMAILTEMPLATE, error);
                                thisCopy.openAlertDialog(thisCopy._context, error);
                            });
                        }
                    });
                };
                /**
                * The method returns the resource path of the appropriate icon to be displayed in the header container for the exchange service.
                */
                AdvancedEmailSetup.prototype.GetExchangeServiceStatusIconResourcePath = function () {
                    var iconSourceStr = null;
                    if (!this._context.utils.isNullOrUndefined(this._isExchangeDetected) && this._isExchangeDetected == "true"
                        && !this._context.utils.isNullOrUndefined(this._isExchangeConfigured) && this._isExchangeConfigured == "true") {
                        iconSourceStr = this._getSuccessIconPath();
                    }
                    return iconSourceStr;
                };
                AdvancedEmailSetup.prototype.IsAppshellmodeBasic = function () {
                    return window && window.parent && window.parent.location && window.parent.location.href && window.parent.location.href.toLowerCase().indexOf("appshellmode=basic") !== -1;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                AdvancedEmailSetup.prototype.destroy = function () {
                };
                /**
                 *
                 * @param context : The context of the class as this is lost on async OData response
                 * @param response : Message to show in alert dialog
                 */
                AdvancedEmailSetup.prototype.openAlertDialog = function (context, response) {
                    var alertMessage = {
                        text: response,
                        confirmButtonLabel: context.resources.getString(EmailSetup.ResourceKeys.ConfirmButtonText)
                    };
                    context.navigation.openAlertDialog(alertMessage);
                    context.utils.requestRender();
                };
                return AdvancedEmailSetup;
            }());
            /**
            * Seed string for page.
            **/
            AdvancedEmailSetup.ADVANCE_EMAIL_ID_SEED = "advanced_email";
            /**
            * Seed string for header section.
            **/
            AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_HEADER_ID_SEED = "email.section-header";
            /**
            * Seed string for text sections in headers.
            **/
            AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_HEADER_TEXT_ID_SEED = "email.header-text";
            /**
            * Seed string for group name in header.
            **/
            AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_HEADER_TEXT_GROUP_ID_SEED = "email.header-group";
            /**
            * Seed string for page name in header.
            **/
            AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_HEADER_TEXT_NAME_ID_SEED = "email.header-name";
            /**
            * Seed string for body section.
            **/
            AdvancedEmailSetup.ADVANCED_EMAIL_SECTION_BODY_ID_SEED = "email.section-body";
            /**
            * Seed string for body attribute: List of email service providers.
            **/
            AdvancedEmailSetup.ATTR_SERVICES_LIST_ID_SEED = "email.body-listing";
            /**
            * Seed string for body attribute: Email Provider Service.
            **/
            AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_ID_SEED = "email.body.listing-service";
            /**
            * Seed string for bosy attribute: Icon of Email Provider Service.
            **/
            AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_ICON_ID_SEED = "email.body.listing.service-icon";
            /**
            * Seed string for bosy attribute: Name of Email Provider Service.
            **/
            AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_NAME_ID_SEED = "email.body.listing.service-name";
            /**
            * Seed string for bosy attribute: Name of Email Provider Service.
            **/
            AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_EXCHANGE_ID_SEED = "email.body.listing.service-exchange";
            /**
            * Seed string for bosy attribute: Status of the Email Provider Service.
            **/
            AdvancedEmailSetup.ATTR_SERVICES_LISTING_SERVICE_STATUS_ID_SEED = "email.body.listing.service-status";
            /**
            * Seed string for body-details attribute: Details of the mail box configuration.
            **/
            /*
            Use ATTR_SERVICE_DETAILS_ID_SEED if you want to get the nudge triangle. Else use ATTR_SERVICE_DETAILS_ID_SEED_NO_NUDGE
            */
            AdvancedEmailSetup.ATTR_SERVICE_DETAILS_ID_SEED = "AdvancedEmailSetup-details";
            AdvancedEmailSetup.ATTR_SERVICE_DETAILS_ID_SEED_NO_NUDGE = "AdvancedEmailSetup-details-no-nudge";
            /**
            * Seed string for body-details attribute: Contains Exchange service label + inner body container.
            **/
            AdvancedEmailSetup.ATTR_EXCHANGE_SERVICE_BODY_ID_SEED = "email.body-container";
            /**
            * Seed string for body attribute: Grid Container.
            **/
            AdvancedEmailSetup.ATTR_GRID_CONTAINER_ID_SEED = "email.body.listing.service.details.grid-container";
            /**
            * Seed string for body attribute: Grid.
            **/
            AdvancedEmailSetup.ATTR_GRID_ID_SEED = "email.body.listing.service.details-grid";
            /**
            * Seed string for body attribute: Description of Exchange Service.
            **/
            AdvancedEmailSetup.ATTR_EXCHANGE_SERVICE_DESCRIPTION_LABEL_ID_SEED = "email.body.listing.service.details-exchange-desc-label";
            /**
            * Seed string for body attribute: Prompt Exchange Configuration State Icon.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_ICON_ID_SEED = "exchange-prompt-configure-icon";
            /**
            * Seed string for body attribute: Prompt Exchange Configuration State Icon.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_ICON_ID_SEED = "exchange-prompt-purchase-icon";
            /**
            * Seed string for body attribute: Prompt Exchange Configuration State Label.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_LABEL_ID_SEED = "email.body.listing.service.details-prompt-configure-label";
            /**
            * Seed string for body attribute: Prompt Exchange Configuration State Button.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_BUTTON_ID_SEED = "email.body.listing.service.details-prompt-configure-button";
            /**
            * Seed string for body attribute: Prompt Exchange Purchase State Container.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_CONTAINER_ID_SEED = "email.body.listing.service.details-prompt-configure-container";
            /**
            * Seed string for body attribute: Prompt Exchange Purchase State Container.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_CONFIGURATION_CONTAINER_WRAPPER_ID_SEED = "email.body.listing.service.details-prompt-configure-container-wrapper";
            /**
            * Seed string for body attribute: Prompt Exchange Purchase State Container.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_MSG_CONTAINER_ID_SEED = "email.body.listing.service.details-prompt-purchase-message-container";
            /**
            * Seed string for body attribute: Prompt Exchange Configuration State Container.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_CONTAINER_ID_SEED = "email.body.listing.service.details-prompt-purchase-container";
            /**
            * Seed string for body attribute: Prompt Exchange Configuration State Container.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_WRAPPER_CONTAINER_ID_SEED = "email.body.listing.service.details-prompt-purchase-wrapper-container";
            /**
            * Seed string for body attribute: Prompt Exchange License purchase label.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_PREFIX_LABEL_ID_SEED = "email.body.listing.service.details-prompt-purchase-label-prefix";
            /**
            * Seed string for body attribute: Prompt Exchange License purchase label.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_SUFFIX_LABEL_ID_SEED = "email.body.listing.service.details-prompt-purchase-label-suffix";
            /**
            * Seed string for body attribute: Prompt Exchange License purchase HREF.
            **/
            AdvancedEmailSetup.ATTR_PROMPT_EXCHANGE_PURCHASE_HREF_ID_SEED = "email.body.listing.service.details-prompt-purchase-hyperlinkd";
            /**
            * Email Consent MDD unique name.
            **/
            AdvancedEmailSetup.MDD_DIALOG_UNIQUE_NAME = "EmailConsentDialog";
            /**
            * Email Consent MDD dialog Parameter id.
            **/
            AdvancedEmailSetup.MDD_DIALOG_PARAM_LAST_BUTTON_CLICKED = "last_button_clicked";
            /**
            * Email Consent MDD dialog OK Button id.
            **/
            AdvancedEmailSetup.MDD_DIALOG_OK_BUTTON_ID = "ok_id";
            /**
            * URL for navigating the user to purchase O#65 subscrption.
            **/
            AdvancedEmailSetup.PurchaseExchangeServiceHyperlinkStr = "https://go.microsoft.com/fwlink/p/?linkid=824917";
            EmailSetup.AdvancedEmailSetup = AdvancedEmailSetup;
            var ResourceType;
            (function (ResourceType) {
                ResourceType[ResourceType["HeaderIcon"] = 0] = "HeaderIcon";
                ResourceType[ResourceType["HeaderGroup"] = 1] = "HeaderGroup";
                ResourceType[ResourceType["HeaderName"] = 2] = "HeaderName";
                ResourceType[ResourceType["ServiceName"] = 3] = "ServiceName";
            })(ResourceType = EmailSetup.ResourceType || (EmailSetup.ResourceType = {}));
        })(EmailSetup = AppCommon.EmailSetup || (AppCommon.EmailSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="AdvancedEmailSetup.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="..\..\..\..\TypeDefinitions\mscrm.d.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EmailSetup;
        (function (EmailSetup) {
            var EmailSetupStyles = (function (_super) {
                __extends(EmailSetupStyles, _super);
                function EmailSetupStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._emailSetupIcon = {};
                    _this._emailSetupPage = {};
                    _this._emailSetupAttributeServiceExchangeIcon = {};
                    _this._emailSetupAttributeServiceExchangeStatus = {};
                    _this._emailSetupAttributeServiceExchangeName = {};
                    _this._emailSetupAttributeServiceExchange = {};
                    _this._emailSetupAttributeServiceList = {};
                    _this._emailSetupAttributeGridContainer = {};
                    _this._emailSetupServiceDetailsExchange = {};
                    _this._emailSetupSectionBody = {};
                    _this._emailSetupGetExchangeServiceIcon = {};
                    _this._emailSetupExchangeBodyContainer = {};
                    _this._emailSetupExchangeConfigurationPromptContainer = {};
                    _this._emailSetupExchangeConfigurationPromptWrapperContainer = {};
                    _this._emailSetupExchangeServiceDescriptionLabel = {};
                    _this._emailSetupServiceDetailsMissingConfiguredIcon = {};
                    _this._emailSetupMissingConfigurationStatusLabel = {};
                    _this._emailSetupPromptConfigurationConsentButton = {};
                    _this._emailSetupExchangePurchasePromptContainer = {};
                    _this._emailSetupExchangePurchasePromptWrapperContainer = {};
                    _this._emailSetupPurchaseExhangeMessageContainer = {};
                    _this._emailSetupPromptServicePurchaseStatusIcon = {};
                    _this._context = context;
                    _this._emailSetupIcon = null;
                    _this._emailSetupPage = null;
                    _this._emailSetupAttributeServiceExchangeIcon = null;
                    _this._emailSetupAttributeServiceExchangeStatus = null;
                    _this._emailSetupAttributeServiceExchangeName = null;
                    _this._emailSetupAttributeServiceExchange = null;
                    _this._emailSetupAttributeServiceList = null;
                    _this._emailSetupAttributeGridContainer = null;
                    _this._emailSetupServiceDetailsExchange = null;
                    _this._emailSetupSectionBody = null;
                    _this._emailSetupGetExchangeServiceIcon = null;
                    _this._emailSetupExchangeBodyContainer = null;
                    _this._emailSetupExchangeConfigurationPromptContainer = null;
                    _this._emailSetupExchangeConfigurationPromptWrapperContainer = null;
                    _this._emailSetupExchangeServiceDescriptionLabel = null;
                    _this._emailSetupServiceDetailsMissingConfiguredIcon = null;
                    _this._emailSetupMissingConfigurationStatusLabel = null;
                    _this._emailSetupPromptConfigurationConsentButton = null;
                    _this._emailSetupExchangePurchasePromptContainer = null;
                    _this._emailSetupExchangePurchasePromptWrapperContainer = null;
                    _this._emailSetupPurchaseExhangeMessageContainer = null;
                    _this._emailSetupPromptServicePurchaseStatusIcon = null;
                    return _this;
                }
                EmailSetupStyles.prototype.EmailSetupPage = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupPage)) {
                        this._emailSetupPage = {};
                        this._emailSetupPage["flexDirection"] = "column";
                        this._emailSetupPage["justifyContent"] = "flexStart";
                        this._emailSetupPage["backgroundColor"] = this._context.theming.colors.basecolor.white;
                        this._emailSetupPage["flex"] = "1";
                        this._emailSetupPage["width"] = "100%";
                    }
                    return this._emailSetupPage;
                };
                EmailSetupStyles.prototype.EmailSetupAttributeServiceExchangeIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupAttributeServiceExchangeIcon)) {
                        this._emailSetupAttributeServiceExchangeIcon = {};
                        this._emailSetupAttributeServiceExchangeIcon["marginLeft"] = this._context.theming.measures.measure075;
                        this._emailSetupAttributeServiceExchangeIcon["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._emailSetupAttributeServiceExchangeIcon;
                };
                EmailSetupStyles.prototype.EmailSetupAttributeServiceExchangeStatus = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupAttributeServiceExchangeStatus)) {
                        this._emailSetupAttributeServiceExchangeStatus = {};
                        this._emailSetupAttributeServiceExchangeStatus["height"] = this._context.theming.measures.measure100;
                        this._emailSetupAttributeServiceExchangeStatus["width"] = this._context.theming.measures.measure100;
                        this._emailSetupAttributeServiceExchangeStatus["justifyContent"] = "center";
                        this._emailSetupAttributeServiceExchangeStatus["margin"] = "auto";
                        this._emailSetupAttributeServiceExchangeStatus["marginLeft"] = this._context.theming.measures.measure075;
                        this._emailSetupAttributeServiceExchangeStatus["marginRight"] = this._context.theming.measures.measure075;
                    }
                    return this._emailSetupAttributeServiceExchangeStatus;
                };
                EmailSetupStyles.prototype.EmailSetupAttributeServiceList = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupAttributeServiceList)) {
                        this._emailSetupAttributeServiceList = {};
                        this._emailSetupAttributeServiceList["width"] = "100%";
                        this._emailSetupAttributeServiceList["height"] = this._context.theming.measures.measure550;
                    }
                    return this._emailSetupAttributeServiceList;
                };
                EmailSetupStyles.prototype.EmailSetupAttributeGridContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupAttributeGridContainer)) {
                        this._emailSetupAttributeGridContainer = {};
                        this._emailSetupAttributeGridContainer["marginLeft"] = this._context.theming.measures.measure075;
                        this._emailSetupAttributeGridContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._emailSetupAttributeGridContainer["marginTop"] = this._context.theming.measures.measure150;
                        this._emailSetupAttributeGridContainer["marginBottom"] = this._context.theming.measures.measure075;
                        this._emailSetupAttributeGridContainer["justifyContent"] = "center";
                        this._emailSetupAttributeGridContainer["display"] = "block";
                    }
                    return this._emailSetupAttributeGridContainer;
                };
                EmailSetupStyles.prototype.EmailSetupServiceDetailsExchange = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupServiceDetailsExchange)) {
                        this._emailSetupServiceDetailsExchange = {};
                        this._emailSetupServiceDetailsExchange["marginLeft"] = this._context.theming.measures.measure075;
                        this._emailSetupServiceDetailsExchange["marginRight"] = this._context.theming.measures.measure075;
                        this._emailSetupServiceDetailsExchange["marginTop"] = this._context.theming.measures.measure075;
                        this._emailSetupServiceDetailsExchange["marginBottom"] = this._context.theming.measures.measure075;
                        this._emailSetupServiceDetailsExchange["border"] = this._context.theming.borders.border02;
                        this._emailSetupServiceDetailsExchange["flex"] = "1";
                        this._emailSetupServiceDetailsExchange["position"] = "relative";
                    }
                    return this._emailSetupServiceDetailsExchange;
                };
                EmailSetupStyles.prototype.EmailSetupSectionBody = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupSectionBody)) {
                        this._emailSetupSectionBody = {};
                        this._emailSetupSectionBody["marginBottom"] = "0.6rem";
                        this._emailSetupSectionBody["flexDirection"] = "column";
                        this._emailSetupSectionBody["borderWidth"] = "1px";
                        this._emailSetupSectionBody["borderStyle"] = "solid";
                        this._emailSetupSectionBody["borderColor"] = this._context.theming.colors.basecolor.grey.grey2;
                        this._emailSetupSectionBody["flex"] = "1";
                    }
                    return this._emailSetupSectionBody;
                };
                EmailSetupStyles.prototype.EmailSetupGetExchangeServiceIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupGetExchangeServiceIcon)) {
                        this._emailSetupGetExchangeServiceIcon = {};
                        this._emailSetupGetExchangeServiceIcon["height"] = "16px";
                    }
                    return this._emailSetupGetExchangeServiceIcon;
                };
                EmailSetupStyles.prototype.EmailSetupExchangeBodyContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupExchangeBodyContainer)) {
                        this._emailSetupExchangeBodyContainer = {};
                        this._emailSetupExchangeBodyContainer["display"] = "flex";
                        this._emailSetupExchangeBodyContainer["flexDirection"] = "column";
                        this._emailSetupExchangeBodyContainer["flex"] = "1";
                        this._emailSetupExchangeBodyContainer["width"] = "100%";
                    }
                    return this._emailSetupExchangeBodyContainer;
                };
                EmailSetupStyles.prototype.EmailSetupExchangeConfigurationPromptContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupExchangeConfigurationPromptContainer)) {
                        this._emailSetupExchangeConfigurationPromptContainer = {};
                        this._emailSetupExchangeConfigurationPromptContainer["display"] = "flex";
                        this._emailSetupExchangeConfigurationPromptContainer["flexDirection"] = "column";
                        this._emailSetupExchangeConfigurationPromptContainer["width"] = "100%";
                        this._emailSetupExchangeConfigurationPromptContainer["justifyContent"] = "center";
                        this._emailSetupExchangeConfigurationPromptContainer["alignSelf"] = "center";
                        this._emailSetupExchangeConfigurationPromptContainer["alignItems"] = "center";
                    }
                    return this._emailSetupExchangeConfigurationPromptContainer;
                };
                EmailSetupStyles.prototype.EmailSetupExchangeConfigurationPromptWrapperContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupExchangeConfigurationPromptWrapperContainer)) {
                        this._emailSetupExchangeConfigurationPromptWrapperContainer = {};
                        this._emailSetupExchangeConfigurationPromptWrapperContainer["display"] = "flex";
                        this._emailSetupExchangeConfigurationPromptWrapperContainer["justifyContent"] = "center";
                        this._emailSetupExchangeConfigurationPromptWrapperContainer["alignItems"] = "center";
                        this._emailSetupExchangeConfigurationPromptWrapperContainer["flex"] = "1";
                    }
                    return this._emailSetupExchangeConfigurationPromptWrapperContainer;
                };
                EmailSetupStyles.prototype.EmailSetupExchangeServiceDescriptionLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupExchangeServiceDescriptionLabel)) {
                        this._emailSetupExchangeServiceDescriptionLabel = {};
                        this._emailSetupExchangeServiceDescriptionLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._emailSetupExchangeServiceDescriptionLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._emailSetupExchangeServiceDescriptionLabel["paddingLeft"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["paddingRight"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["paddingTop"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["paddingBottom"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["border"] = this._context.theming.borders.border02;
                        this._emailSetupExchangeServiceDescriptionLabel["opacity"] = "1";
                        this._emailSetupExchangeServiceDescriptionLabel["marginTop"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._emailSetupExchangeServiceDescriptionLabel["flexDirection"] = "column";
                        this._emailSetupExchangeServiceDescriptionLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._emailSetupExchangeServiceDescriptionLabel;
                };
                EmailSetupStyles.prototype.EmailSetupServiceDetailsMissingConfiguredIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupServiceDetailsMissingConfiguredIcon)) {
                        this._emailSetupServiceDetailsMissingConfiguredIcon = {};
                        this._emailSetupServiceDetailsMissingConfiguredIcon["display"] = "flex";
                        this._emailSetupServiceDetailsMissingConfiguredIcon["justifyContent"] = "center";
                        this._emailSetupServiceDetailsMissingConfiguredIcon["height"] = "64px";
                        this._emailSetupServiceDetailsMissingConfiguredIcon["width"] = "64px";
                        this._emailSetupServiceDetailsMissingConfiguredIcon["alignSelf"] = "center";
                    }
                    return this._emailSetupServiceDetailsMissingConfiguredIcon;
                };
                EmailSetupStyles.prototype.EmailSetupMissingConfigurationStatusLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupMissingConfigurationStatusLabel)) {
                        this._emailSetupMissingConfigurationStatusLabel = {};
                        this._emailSetupMissingConfigurationStatusLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._emailSetupMissingConfigurationStatusLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._emailSetupMissingConfigurationStatusLabel["marginTop"] = this._context.theming.measures.measure150;
                        this._emailSetupMissingConfigurationStatusLabel["alignSelf"] = "center";
                        this._emailSetupMissingConfigurationStatusLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._emailSetupMissingConfigurationStatusLabel["marginLeft"] = "20%";
                        this._emailSetupMissingConfigurationStatusLabel["marginRight"] = "20%";
                    }
                    return this._emailSetupMissingConfigurationStatusLabel;
                };
                EmailSetupStyles.prototype.EmailSetupPromptConfigurationConsentButton = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupPromptConfigurationConsentButton)) {
                        this._emailSetupPromptConfigurationConsentButton = {};
                        this._emailSetupPromptConfigurationConsentButton = this.FREPrimaryButton();
                        this._emailSetupPromptConfigurationConsentButton["marginTop"] = this._context.theming.measures.measure100;
                        this._emailSetupPromptConfigurationConsentButton["alignSelf"] = "center";
                    }
                    return this._emailSetupPromptConfigurationConsentButton;
                };
                EmailSetupStyles.prototype.EmailSetupExchangePurchasePromptContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupExchangePurchasePromptContainer)) {
                        this._emailSetupExchangePurchasePromptContainer = {};
                        this._emailSetupExchangePurchasePromptContainer["display"] = "flex";
                        this._emailSetupExchangePurchasePromptContainer["flexDirection"] = "column";
                        this._emailSetupExchangePurchasePromptContainer["width"] = "100%";
                        this._emailSetupExchangePurchasePromptContainer["justifyContent"] = "center";
                        this._emailSetupExchangePurchasePromptContainer["alignSelf"] = "center";
                        this._emailSetupExchangePurchasePromptContainer["alignItems"] = "center";
                    }
                    return this._emailSetupExchangePurchasePromptContainer;
                };
                EmailSetupStyles.prototype.EmailSetupExchangePurchasePromptWrapperContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupExchangePurchasePromptWrapperContainer)) {
                        this._emailSetupExchangePurchasePromptWrapperContainer = {};
                        this._emailSetupExchangePurchasePromptWrapperContainer["display"] = "flex";
                        this._emailSetupExchangePurchasePromptWrapperContainer["justifyContent"] = "center";
                        this._emailSetupExchangePurchasePromptWrapperContainer["alignItems"] = "center";
                        this._emailSetupExchangePurchasePromptWrapperContainer["flex"] = "1";
                    }
                    return this._emailSetupExchangePurchasePromptWrapperContainer;
                };
                EmailSetupStyles.prototype.EmailSetupPurchaseExhangeMessageContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupPurchaseExhangeMessageContainer)) {
                        this._emailSetupPurchaseExhangeMessageContainer = {};
                        this._emailSetupPurchaseExhangeMessageContainer["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._emailSetupPurchaseExhangeMessageContainer["fontSize"] = this._context.theming.fontsizes.font100;
                        this._emailSetupPurchaseExhangeMessageContainer["marginTop"] = this._context.theming.measures.measure150;
                        this._emailSetupPurchaseExhangeMessageContainer["alignSelf"] = "center";
                        this._emailSetupPurchaseExhangeMessageContainer["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._emailSetupPurchaseExhangeMessageContainer["display"] = "inline";
                        this._emailSetupPurchaseExhangeMessageContainer["marginLeft"] = "20%";
                        this._emailSetupPurchaseExhangeMessageContainer["marginRight"] = "20%";
                    }
                    return this._emailSetupPurchaseExhangeMessageContainer;
                };
                EmailSetupStyles.prototype.EmailSetupPromptServicePurchaseStatusIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._emailSetupPromptServicePurchaseStatusIcon)) {
                        this._emailSetupPromptServicePurchaseStatusIcon = {};
                        this._emailSetupPromptServicePurchaseStatusIcon["display"] = "flex";
                        this._emailSetupPromptServicePurchaseStatusIcon["justifyContent"] = "center";
                        this._emailSetupPromptServicePurchaseStatusIcon["height"] = "64px";
                        this._emailSetupPromptServicePurchaseStatusIcon["width"] = "64px";
                        this._emailSetupPromptServicePurchaseStatusIcon["alignSelf"] = "center";
                    }
                    return this._emailSetupPromptServicePurchaseStatusIcon;
                };
                return EmailSetupStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            EmailSetup.EmailSetupStyles = EmailSetupStyles;
        })(EmailSetup = AppCommon.EmailSetup || (AppCommon.EmailSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EmailSetup;
        (function (EmailSetup) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "CommunicationAndCollaboration", {
                    get: function () {
                        return "CommunicationAndCollaboration";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Email", {
                    get: function () {
                        return "Email";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Exchange", {
                    get: function () {
                        return "Exchange";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PromptConfigurationStatus", {
                    get: function () {
                        return "PromptConfigurationStatus";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PromptConfigurationButtonText", {
                    get: function () {
                        return "PromptConfigurationButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ExchangeServiceDescription", {
                    get: function () {
                        return "ExchangeServiceDescription";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PurchaseExchangeServiceLabelPrefix", {
                    get: function () {
                        return "PurchaseExchangeServiceLabelPrefix";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PurchaseExchangeServiceHyperlinkLabel", {
                    get: function () {
                        return "PurchaseExchangeServiceHyperlinkLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "PurchaseExchangeServiceLabelSuffix", {
                    get: function () {
                        return "PurchaseExchangeServiceLabelSuffix";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ExchangeConsentDialogTitle", {
                    get: function () {
                        return "ExchangeConsentDialogTitle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ExchangeConsentDialogOkLabel", {
                    get: function () {
                        return "ExchangeConsentDialogOkLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ExchangeConsentDialogCancelLabel", {
                    get: function () {
                        return "ExchangeConsentDialogCancelLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SuccessMessageText", {
                    get: function () {
                        return "SuccessMessageText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "QuickSetupText", {
                    get: function () {
                        return "QuickSetupText";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            EmailSetup.ResourceKeys = ResourceKeys;
        })(EmailSetup = AppCommon.EmailSetup || (AppCommon.EmailSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var EmailSetup;
        (function (EmailSetup) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourcePath = (function () {
                function ResourcePath() {
                }
                Object.defineProperty(ResourcePath, "ExchangeIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/Exchange.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "ExchangeIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/Exchange_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SuccessIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/SuccessX16.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "SuccessIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/SuccessX16_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "ErrorIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/ErrorX16.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "ErrorIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/ErrorX16_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "ProgressIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/ProgressX16.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/Email.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/Email_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "ProgressIconHC", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/EmailSetup/ProgressX16_HighContrast.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourcePath;
            }());
            EmailSetup.ResourcePath = ResourcePath;
        })(EmailSetup = AppCommon.EmailSetup || (AppCommon.EmailSetup = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=AdvancedEmailSetup.js.map