var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AppManagement;
        (function (AppManagement) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            var RetrieveCurrentOrganizationRequest = ODataContract.RetrieveCurrentOrganizationRequest;
            var EndpointAccessType = ODataContract.EndpointAccessType;
            var CommonUtils = Mscrm.AppCommon.Common.Utility;
            var WEBAPPLICATION = "WebApplication";
            var ApplicationManagementControl = (function () {
                /**
                * Constructor
                */
                function ApplicationManagementControl() {
                    this._context = null;
                    this._serviceUrl = null;
                    this._applyStyles = null;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 */
                ApplicationManagementControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    var title = this._context.resources.getString(AppManagement.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(AppManagement.ResourceKeys.SubAreaText) + " - " + this._context.resources.getString(AppManagement.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(this._context, title);
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.APPLICATIONMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "ApplicationManagementPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                ApplicationManagementControl.prototype.updateView = function (context) {
                    return this._freShell.getVirtualComponents(this.getChildControls(context));
                };
                ApplicationManagementControl.prototype.getChildControls = function (context) {
                    //icon content
                    var params = {};
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new AppManagement.AppManagementControlStyles(context);
                    }
                    params.normalIconImagePath = AppManagement.Constants.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = AppManagement.Constants.HeaderHighContrastIconImagePath;
                    params.areaLabel = this._context.resources.getString(AppManagement.ResourceKeys.AreaText);
                    params.subAreaLabel = this._context.resources.getString(AppManagement.ResourceKeys.SubAreaText);
                    params.headerRightContainerChild = this._createHeaderRightContainer();
                    params.contentContainerChild = this._createSectionContainer();
                    this._freShell.stopPerformanceStopWatch();
                    return params;
                };
                /**
                 * creates section container for application management control
                 */
                ApplicationManagementControl.prototype._createSectionContainer = function () {
                    /*
                    Structure of controls:
                    |----sectionContainer
                        |----boxContainer
                            |----adminPortalDescriptionLabel
                            |----adminPortalLinkDescriptionLabel
                    */
                    //-----Section container-----
                    var adminPortalDescriptionString = this._context.resources.getString(AppManagement.ResourceKeys.AdminPortalDescription);
                    var adminPortalDescriptionLabel = this._context.factory.createElement("LABEL", {
                        key: AppManagement.Constants.AdminPortalDescriptionKey, id: AppManagement.Constants.AdminPortalDescriptionKey,
                        style: this._applyStyles.AppMgmtControlAdminPortalDescriptionFREFieldLabel()
                    }, adminPortalDescriptionString);
                    var adminPortalLinkDescriptionString = this._context.resources.getString(AppManagement.ResourceKeys.AdminPortalLinkDescription);
                    var adminPortalLinkDescriptionLabel = this._context.factory.createElement("LABEL", {
                        key: AppManagement.Constants.AdminPortalLinkDescriptionKey, id: AppManagement.Constants.AdminPortalLinkDescriptionKey,
                        style: this._applyStyles.AppMgmtControlAdminPortalLinkDescriptionFREFieldLabel()
                    }, adminPortalLinkDescriptionString);
                    var boxContainer = this._context.factory.createElement("CONTAINER", {
                        key: AppManagement.Constants.BoxContainerKey, id: AppManagement.Constants.BoxContainerKey,
                        style: this._applyStyles.AppMgmtControlBoxContainer()
                    }, [adminPortalDescriptionLabel, adminPortalLinkDescriptionLabel]);
                    var sectionContainer = this._context.factory.createElement("CONTAINER", {
                        key: AppManagement.Constants.SectionContainerKey, id: AppManagement.Constants.SectionContainerKey,
                        style: this._applyStyles.FRESectionContainer()
                    }, [boxContainer]);
                    return sectionContainer;
                };
                /**
                 * Creates RightContainer for header
                 */
                ApplicationManagementControl.prototype._createHeaderRightContainer = function () {
                    var dynamicsButtonIconContainer = this._context.factory.createElement("CONTAINER", {
                        key: AppManagement.Constants.DynamicsButtonIconContainerKey, id: AppManagement.Constants.DynamicsButtonIconContainerKey,
                        style: this._applyStyles.AppMgmtControlFREHeaderRightButtonIconContainer()
                    }, []);
                    var dynamicsButton = this._context.factory.createElement("BUTTON", {
                        key: AppManagement.Constants.DynamicsButtonKey, id: AppManagement.Constants.DynamicsButtonKey,
                        onClick: this.onDynamicsButtonClicked.bind(this),
                        title: this._context.resources.getString(AppManagement.ResourceKeys.DynamicsButtonTooltip), tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [dynamicsButtonIconContainer, this._context.resources.getString(AppManagement.ResourceKeys.DynamicsButtonText)]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: AppManagement.Constants.HeaderSeparatorContainerKey, id: AppManagement.Constants.HeaderSeparatorContainerKey,
                        style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: AppManagement.Constants.HeaderRightContainerKey, id: AppManagement.Constants.HeaderRightContainerKey, style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, dynamicsButton]);
                    return headerRightContainer;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                ApplicationManagementControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                ApplicationManagementControl.prototype.destroy = function () {
                };
                /**
                 * dynamicsButton onClick handler function
                 */
                ApplicationManagementControl.prototype.onDynamicsButtonClicked = function () {
                    if (this._serviceUrl != null) {
                        //open URL in new tab
                        this._context.utils.openInBrowser(this._serviceUrl);
                        SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.APPLICATIONMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "DynamicsButton", AppManagement.Constants.DynamicsButtonKey, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Dynamics Button Clicked", false);
                    }
                    else {
                        var that = this;
                        var retrieveCurrentOrganizationRequest = new RetrieveCurrentOrganizationRequest(EndpointAccessType.Default);
                        this._context.webAPI.execute(retrieveCurrentOrganizationRequest).then(function (response) {
                            if (response) {
                                response.json().then(function (jsonResponse) {
                                    /*
                                    Sample format of JSON retrived by the OData call
                                    {
                                        "Detail": {
                                            "Endpoints": {
                                                "Count": 3,
                                                "IsReadOnly": false,
                                                "Keys": [
                                                    "WebApplication",
                                                    "OrganizationService",
                                                    "OrganizationDataService"
                                                ],
                                                "Values": [
                                                    "https://someorg.crmx.something.com/",
                                                    "https://someorg.crmx.something.com/XRMServices/2011/Organization.svc",
                                                    "https://someorg.crmx.something.com/XRMServices/2011/OrganizationData.svc"
                                                ]
                                            }
                                        }
                                    }
                                    */
                                    var index = jsonResponse.Detail.Endpoints.Keys.indexOf(WEBAPPLICATION);
                                    if (index != -1) {
                                        var webApplicationEndpoint = jsonResponse.Detail.Endpoints.Values[index];
                                        var crmUrl = CommonUtils.GetCrmHostName(webApplicationEndpoint);
                                        that._serviceUrl = "https://port." + crmUrl + "/G/Instances/InstancePicker.aspx?redirect=False";
                                        //open URL in new tab
                                        that._context.utils.openInBrowser(that._serviceUrl);
                                        SmbAppsTelemetryUtility.TelemetryData.ReportEventData(that._context, 1, SmbAppsTelemetryUtility.Controls_PageType.APPLICATIONMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "DynamicsButton", AppManagement.Constants.DynamicsButtonKey, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "Dynamics Button Clicked", false);
                                    }
                                    else {
                                        var alertMessage = {
                                            text: that._context.resources.getString(AppManagement.ResourceKeys.WebApplicationEnpointNotFound),
                                            confirmButtonLabel: that._context.resources.getString(AppManagement.ResourceKeys.ConfirmButtonText)
                                        };
                                        that._context.navigation.openAlertDialog(alertMessage);
                                    }
                                    that._context.utils.requestRender();
                                });
                            }
                        }, function (error) {
                            SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.APPLICATIONMANAGEMENT, error);
                            console.error(error);
                            var alertMessage = {
                                text: that._context.resources.getString(AppManagement.ResourceKeys.WebApiRequestFailed),
                                confirmButtonLabel: that._context.resources.getString(AppManagement.ResourceKeys.ConfirmButtonText)
                            };
                            that._context.navigation.openAlertDialog(alertMessage);
                            that._context.utils.requestRender();
                        });
                    }
                };
                return ApplicationManagementControl;
            }());
            AppManagement.ApplicationManagementControl = ApplicationManagementControl;
        })(AppManagement = AppCommon.AppManagement || (AppCommon.AppManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="ApplicationManagementControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AppManagement;
        (function (AppManagement) {
            'use strict';
            var AppManagementControlStyles = (function (_super) {
                __extends(AppManagementControlStyles, _super);
                function AppManagementControlStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._adminPortalDescriptionFREFieldLabel = {};
                    _this._adminPortalLinkDescriptionFREFieldLabel = {};
                    _this._adminCenterLabel = {};
                    _this._dynamicsButtonIconContainer = {};
                    _this._boxContainer = {};
                    _this._appMgmtFREheaderIconContainer = {};
                    _this._context = context;
                    _this._adminPortalDescriptionFREFieldLabel = null;
                    _this._adminPortalLinkDescriptionFREFieldLabel = null;
                    _this._adminCenterLabel = null;
                    _this._dynamicsButtonIconContainer = null;
                    _this._boxContainer = null;
                    _this._appMgmtFREheaderIconContainer = null;
                    return _this;
                }
                AppManagementControlStyles.prototype.AppMgmtControlAdminPortalDescriptionFREFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._adminPortalDescriptionFREFieldLabel)) {
                        this._adminPortalDescriptionFREFieldLabel = {};
                        this._adminPortalDescriptionFREFieldLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._adminPortalDescriptionFREFieldLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._adminPortalDescriptionFREFieldLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._adminPortalDescriptionFREFieldLabel["marginTop"] = this._context.theming.measures.measure075;
                        this._adminPortalDescriptionFREFieldLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._adminPortalDescriptionFREFieldLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._adminPortalDescriptionFREFieldLabel["marginBottom"] = this._context.theming.measures.measure025;
                    }
                    return this._adminPortalDescriptionFREFieldLabel;
                };
                AppManagementControlStyles.prototype.AppMgmtControlAdminPortalLinkDescriptionFREFieldLabel = function () {
                    if (this._context.utils.isNullOrUndefined(this._adminPortalLinkDescriptionFREFieldLabel)) {
                        this._adminPortalLinkDescriptionFREFieldLabel = {};
                        this._adminPortalLinkDescriptionFREFieldLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                        this._adminPortalLinkDescriptionFREFieldLabel["fontSize"] = this._context.theming.fontsizes.font100;
                        this._adminPortalLinkDescriptionFREFieldLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                        this._adminPortalLinkDescriptionFREFieldLabel["marginLeft"] = this._context.theming.measures.measure075;
                        this._adminPortalLinkDescriptionFREFieldLabel["marginRight"] = this._context.theming.measures.measure075;
                        this._adminPortalLinkDescriptionFREFieldLabel["marginBottom"] = this._context.theming.measures.measure075;
                    }
                    return this._adminPortalLinkDescriptionFREFieldLabel;
                };
                AppManagementControlStyles.prototype.AppMgmtControlBoxContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._boxContainer)) {
                        this._boxContainer = {};
                        this._boxContainer["display"] = "flex";
                        this._boxContainer["flexDirection"] = "column";
                        this._boxContainer["flex"] = "0 0 auto";
                        this._boxContainer["justifyContent"] = "center";
                        this._boxContainer["border"] = this._context.theming.borders.border02;
                        this._boxContainer["marginTop"] = this._context.theming.measures.measure075;
                        this._boxContainer["marginRight"] = this._context.theming.measures.measure075;
                        this._boxContainer["marginLeft"] = this._context.theming.measures.measure075;
                    }
                    return this._boxContainer;
                };
                AppManagementControlStyles.prototype.AppMgmtControlFREHeaderRightButtonIconContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._appMgmtFREheaderIconContainer)) {
                        this._appMgmtFREheaderIconContainer = {};
                        this._appMgmtFREheaderIconContainer["display"] = "flex";
                        this._appMgmtFREheaderIconContainer["justifyContent"] = "center";
                        this._appMgmtFREheaderIconContainer["alignItems"] = "center";
                        this._appMgmtFREheaderIconContainer["backgroundColor"] = "transparent";
                        this._appMgmtFREheaderIconContainer["margin"] = this._context.theming.measures.measure025;
                        this._appMgmtFREheaderIconContainer["color"] = this._context.theming.colors.basecolor.grey.grey7;
                    }
                    return this._appMgmtFREheaderIconContainer;
                };
                return AppManagementControlStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            AppManagement.AppManagementControlStyles = AppManagementControlStyles;
        })(AppManagement = AppCommon.AppManagement || (AppCommon.AppManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: Constants class contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AppManagement;
        (function (AppManagement) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                Object.defineProperty(Constants, "AdminPortalDescriptionKey", {
                    get: function () {
                        return "appManagement_AdminPortalDescriptionFREFieldLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AdminPortalLinkDescriptionKey", {
                    get: function () {
                        return "appManagement_AdminPortalLinkDescriptionFREFieldLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "DynamicsButtonLabelKey", {
                    get: function () {
                        return "appManagement_DynamicsButtonLabel";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "DynamicsButtonIconContainerKey", {
                    get: function () {
                        return "appManagement_DynamicsButtonIconContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "DynamicsButtonKey", {
                    get: function () {
                        return "appManagement_DynamicsButton";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderSeparatorContainerKey", {
                    get: function () {
                        return "appManagement_FREHeaderSeparatorContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderRightContainerKey", {
                    get: function () {
                        return "appManagement_FREHeaderRightContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "BoxContainerKey", {
                    get: function () {
                        return "appManagement_BoxContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "SectionContainerKey", {
                    get: function () {
                        return "appManagement_FRESectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ApplicationManagement.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ApplicationManagement_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Constants;
            }());
            AppManagement.Constants = Constants;
        })(AppManagement = AppCommon.AppManagement || (AppCommon.AppManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: LocalizeString is a wraper to the core API for getting the resource string. In case the core API fails the class will return the default string provided by the caller as the resurce string
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AppManagement;
        (function (AppManagement) {
            'use strict';
            // This code is for localization and will be finally part of common utility
            var LocalizeString = (function () {
                function LocalizeString(context, webresource) {
                    this.context = context;
                    this.webresource = webresource;
                }
                /**
                * The function returns the key if resource is not found
                * @param key
                * @param value
                */
                LocalizeString.prototype.getResourceString = function (key, value) {
                    try {
                        if (this.webresource === null)
                            throw new Error("WebResource should be initialized, for fetching value corresponding to key");
                        if (this.context === null)
                            throw new Error("Context should not be NULL");
                        var _value = undefined;
                        //value=LocalizeString.context.utils.getResourceString(key, LocalizeString.webresource);
                        if (_value === undefined)
                            return value;
                    }
                    catch (e) {
                        if (e instanceof Error) {
                            console.log(e.message);
                        }
                    }
                };
                return LocalizeString;
            }());
            AppManagement.LocalizeString = LocalizeString;
        })(AppManagement = AppCommon.AppManagement || (AppCommon.AppManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var AppManagement;
        (function (AppManagement) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "AreaText", {
                    get: function () {
                        return "AreaText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SubAreaText", {
                    get: function () {
                        return "SubAreaText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdminPortalDescription", {
                    get: function () {
                        return "AdminPortalDescription";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdminPortalLinkDescription", {
                    get: function () {
                        return "AdminPortalLinkDescription";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdminCenter", {
                    get: function () {
                        return "AdminCenter";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DynamicsButtonText", {
                    get: function () {
                        return "DynamicsButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "DynamicsButtonTooltip", {
                    get: function () {
                        return "DynamicsButtonTooltip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "WebApplicationEnpointNotFound", {
                    get: function () {
                        return "WebApplicationEnpointNotFound";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "WebApiRequestFailed", {
                    get: function () {
                        return "WebApiRequestFailed";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            AppManagement.ResourceKeys = ResourceKeys;
        })(AppManagement = AppCommon.AppManagement || (AppCommon.AppManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=ApplicationManagementControl.js.map