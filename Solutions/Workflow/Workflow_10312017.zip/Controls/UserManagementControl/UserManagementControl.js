var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/external/TypeDefinitions/jquery.d.ts" />
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/libs/FREShell.d.ts" />
/// <reference path="../FREShell/libs/frecommon-lib.d.ts" /> 
/**
* User and Team management control main class.
* contains lifecycle methods for control.
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var UserManagement;
        (function (UserManagement) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var RetrieveTenantAdminPermissionsRequest = ODataContract.RetrieveTenantAdminPermissionsRequest;
            var RetrieveTenantInfoRequest = ODataContract.RetrieveTenantInfoRequest;
            var HeaderRightButtonType;
            (function (HeaderRightButtonType) {
                HeaderRightButtonType[HeaderRightButtonType["AddUser"] = 0] = "AddUser";
                HeaderRightButtonType[HeaderRightButtonType["InviteUser"] = 1] = "InviteUser";
            })(HeaderRightButtonType || (HeaderRightButtonType = {}));
            var UserManagementControl = (function () {
                /**
                * Constructor
                */
                function UserManagementControl() {
                    this._context = null;
                    this._freShell = null;
                    this._applyStyles = null;
                    this._isCurrentUserTenantAdmin = false;
                    this._isTenantManaged = false;
                    this._isRetrieveTenantAdminPermissionsAPIResponseReceived = false;
                    this._refreshCounter = 0;
                    this._isEmailTrialOrg = false;
                    this._isRetrieveTenantInfoAPIResponseReceived = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                UserManagementControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    var title = this._context.resources.getString(UserManagement.ResourceKeys.AdvancedSettingsText) + " " + this._context.resources.getString(UserManagement.ResourceKeys.SubAreaText) + " - " + this._context.resources.getString(UserManagement.ResourceKeys.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(context, title);
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.PAGEVISITED, "UserManagementPage", null, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "PageVisited", false);
                    this.callTenantInformationAPIs();
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                UserManagementControl.prototype.updateView = function (context) {
                    this._context = context;
                    return this._freShell.getVirtualComponents(this.getChildControls(context));
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                UserManagementControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                UserManagementControl.prototype.destroy = function () {
                };
                /**
                 * Generates parameters for FREShell
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 */
                UserManagementControl.prototype.getChildControls = function (context) {
                    var params = {};
                    // For applying styles
                    if (context.utils.isNullOrUndefined(this._applyStyles)) {
                        this._applyStyles = new UserManagement.UserManagementStyles(context);
                    }
                    params["normalIconImagePath"] = UserManagement.Constants.HeaderNormalIconImagePath;
                    params["highContrastIconImagePath"] = UserManagement.Constants.HeaderHighContrastIconImagePath;
                    params["areaLabel"] = this._context.resources.getString(UserManagement.ResourceKeys.AreaText);
                    params["subAreaLabel"] = this._context.resources.getString(UserManagement.ResourceKeys.SubAreaText);
                    if (this._isRetrieveTenantInfoAPIResponseReceived && this._isRetrieveTenantAdminPermissionsAPIResponseReceived) {
                        if (this._isEmailTrialOrg) {
                            params["headerRightContainerChild"] = this.createHeaderRightContainer(HeaderRightButtonType.InviteUser);
                        }
                        else {
                            if (this._isCurrentUserTenantAdmin && this._isTenantManaged) {
                                params["headerRightContainerChild"] = this.createHeaderRightContainer(HeaderRightButtonType.AddUser);
                            }
                        }
                    }
                    /*
                    Structure of controls:
                    bodyContainer
                    |----headerContainer
                        |----headerIconContainer
                        |----headerLeftContainer
                            |----areaLabel
                            |----subAreaLabel
                        |----headerCenterContainer
                        |----headerSeparatorContainer
                        |----headerRightContainer
                            |----addUserButton
                                |----addUserButtonLabel
                                |----addUserIconContainer
                    |----sectionContainer
                        |----userSectionContainer
                            |----userGrid
                    */
                    //-----Section container-----
                    var userSectionContainer = this.createUserSectionContainer();
                    params["contentContainerChild"] = userSectionContainer;
                    if (this._isRetrieveTenantAdminPermissionsAPIResponseReceived && this._isRetrieveTenantInfoAPIResponseReceived) {
                        this._freShell.stopPerformanceStopWatch();
                    }
                    return params;
                };
                /**
                 * Creates RightContainer for header
                 */
                UserManagementControl.prototype.createHeaderRightContainer = function (headerRightButtonType) {
                    var rightButtonIconContainer = null;
                    var rightButton = null;
                    if (headerRightButtonType == HeaderRightButtonType.AddUser) {
                        rightButtonIconContainer = this._context.factory.createElement("CONTAINER", {
                            key: UserManagement.Constants.AddUserIconContainerKey, id: UserManagement.Constants.AddUserIconContainerKey, style: this._applyStyles.FRERightButtonIconContainer()
                        }, []);
                        rightButton = this._context.factory.createElement("BUTTON", {
                            key: UserManagement.Constants.AddUserButtonKey, id: UserManagement.Constants.AddUserButtonKey,
                            onClick: this.onAddUserButtonClicked.bind(this),
                            title: this._context.resources.getString(UserManagement.ResourceKeys.AddUserButtonToolTip), tabindex: "0",
                            style: this._applyStyles.FREHeaderRightButtonStyle()
                        }, [rightButtonIconContainer, this._context.resources.getString(UserManagement.ResourceKeys.AddUserButtonText)]);
                    }
                    else {
                        //else case create "InviteUser" button
                        rightButtonIconContainer = this._context.factory.createElement("CONTAINER", {
                            key: UserManagement.Constants.InviteUserIconContainerKey, id: UserManagement.Constants.InviteUserIconContainerKey, style: this._applyStyles.FRERightButtonIconContainer()
                        }, []);
                        rightButton = this._context.factory.createElement("BUTTON", {
                            key: UserManagement.Constants.InviteUserButtonKey, id: UserManagement.Constants.InviteUserButtonKey,
                            onClick: this.onInviteUserButtonClicked.bind(this),
                            title: this._context.resources.getString(UserManagement.ResourceKeys.InviteUserButtonToolTip), tabindex: "0",
                            style: this._applyStyles.FREHeaderRightButtonStyle()
                        }, [rightButtonIconContainer, this._context.resources.getString(UserManagement.ResourceKeys.InviteUserButtonText)]);
                    }
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: UserManagement.Constants.HeaderSeparatorContainerKey, id: UserManagement.Constants.HeaderSeparatorContainerKey, style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: UserManagement.Constants.HeaderRightContainerKey, id: UserManagement.Constants.HeaderRightContainerKey, style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, rightButton]);
                    return headerRightContainer;
                };
                /**
                 * Creates section container for User Management page
                 */
                UserManagementControl.prototype.createUserSectionContainer = function () {
                    var gridProps = {
                        parameters: {
                            Grid: {
                                Type: "Grid",
                                TargetEntityType: "systemuser",
                                ViewId: "5AECEF10-D691-4CEE-A86F-7BD0FD161F79",
                                DataSetHostProps: {
                                    commandBarEnabled: true,
                                    jumpBarEnabled: true,
                                    quickFindEnabled: true,
                                    viewSelectorEnabled: false
                                }, RefreshInput: {
                                    Static: true,
                                    Value: this._refreshCounter
                                },
                            },
                            EnableGroupBy: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            },
                            EnableFiltering: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            },
                            EnableEditing: {
                                Usage: 1,
                                Static: true,
                                Type: "Enum",
                                Value: "No",
                                Primary: false
                            }
                        }
                    };
                    var userGrid = this._context.factory.createComponent("MscrmControls.Grid.GridControl", "userGrid", gridProps);
                    var userGridContainer = this._context.factory.createElement("CONTAINER", {
                        key: UserManagement.Constants.UserGridContainerKey, id: UserManagement.Constants.UserGridContainerKey,
                        style: this._applyStyles.FREGridContainer()
                    }, [userGrid]);
                    var userSectionContainer = this._context.factory.createElement("CONTAINER", {
                        key: UserManagement.Constants.SectionContainerKey, id: UserManagement.Constants.SectionContainerKey,
                        style: this._applyStyles.FRESectionContainer()
                    }, [userGridContainer]);
                    return userSectionContainer;
                };
                /**
                 * onClick handler for AddUser button
                 */
                UserManagementControl.prototype.onAddUserButtonClicked = function () {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "AddUserButton", UserManagement.Constants.AddUserButtonKey, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "AddUser Button Clicked", false);
                    var dialogParams = {};
                    var dialogOpt = {};
                    dialogOpt.position = UserManagement.Constants.MDD_Dialog_Position_Right;
                    var that = this;
                    this._context.navigation.openDialog(UserManagement.Constants.MDD_AddNewUser_UniqueName, dialogOpt, dialogParams).then(function (response) {
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.utils.requestRender();
                        that._context.accessibility.focusElementById(UserManagement.Constants.AddUserButtonKey);
                    }, function (error) {
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, error);
                        console.error(error);
                        that.showGenericError(that._context);
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.accessibility.focusElementById(UserManagement.Constants.AddUserButtonKey);
                    });
                };
                /**
                 * onClick handler for InviteUser button
                 */
                UserManagementControl.prototype.onInviteUserButtonClicked = function () {
                    SmbAppsTelemetryUtility.TelemetryData.ReportEventData(this._context, 1, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, SmbAppsTelemetryUtility.Controls_EventName.CLICKEDBUTTON, "InviteUserButton", UserManagement.Constants.InviteUserButtonKey, SmbAppsTelemetryUtility.Controls_ShellMode.ADVANCEDSHELLMODE, "InviteUser Button Clicked", false);
                    var dialogParams = {};
                    var dialogOpt = {};
                    dialogOpt.position = UserManagement.Constants.MDD_Dialog_Position_Right;
                    var that = this;
                    this._context.navigation.openDialog(UserManagement.Constants.MDD_InviteUser_UniqueName, dialogOpt, dialogParams).then(function (response) {
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.utils.requestRender();
                        that._context.accessibility.focusElementById(UserManagement.Constants.InviteUserButtonKey);
                    }, function (error) {
                        console.error(error);
                        that.showGenericError(that._context);
                        that._refreshCounter = that._refreshCounter + 1;
                        that._context.accessibility.focusElementById(UserManagement.Constants.InviteUserButtonKey);
                    });
                };
                /**
                 * Checks if object is undefined or null using context utils
                 * @param object : any object
                 */
                UserManagementControl.prototype.isNullOrUndefined = function (object) {
                    return this._context.utils.isNullOrUndefined(object);
                };
                /**
                 * Shows generic error message to user
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 */
                UserManagementControl.prototype.showGenericError = function (context) {
                    var alertMessage = {
                        text: context.resources.getString(UserManagement.ResourceKeys.Error_GenericErrorOccurred),
                        confirmButtonLabel: context.resources.getString(UserManagement.ResourceKeys.ConfirmButtonText)
                    };
                    context.navigation.openAlertDialog(alertMessage);
                };
                /**
                 * Calls Tenant API and checks for permissions and based on which AddUser button will be displayed or not displayed
                 */
                UserManagementControl.prototype.callTenantInformationAPIs = function () {
                    //2 API calls are made here.
                    //1. RetrieveTenantAdminPermissionsRequest
                    //2. RetrieveTenantInfoRequest
                    var that = this;
                    var retrieveTenantAdminPermissionsRequest = new RetrieveTenantAdminPermissionsRequest();
                    this._context.webAPI.execute(retrieveTenantAdminPermissionsRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                /*
                                Sample format of JSON retrived by the OData call
                                {
                                    {
                                        "@odata.context": "http://<machine>/<org>/api/data/v9.0/$metadata#Microsoft.Dynamics.CRM.RetrieveTenantAdminPermissionsResponse",
                                        "AdminPermissions": "{\"isCurrentUserTenantAdmin\":\"true\",\"isTenantManaged\":\"true\"}"
                                    }
                                }
                                */
                                try {
                                    var parsedResponse = JSON.parse(jsonResponse["AdminPermissions"]);
                                    if (parsedResponse["isCurrentUserTenantAdmin"].toLowerCase() == "true") {
                                        that._isCurrentUserTenantAdmin = true;
                                    }
                                    if (parsedResponse["isTenantManaged"].toLowerCase() == "true") {
                                        that._isTenantManaged = true;
                                    }
                                }
                                catch (e) {
                                    SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, e);
                                    console.error(e);
                                    that.showGenericError(that._context);
                                }
                                finally {
                                    that._isRetrieveTenantAdminPermissionsAPIResponseReceived = true;
                                    that._context.utils.requestRender();
                                }
                            });
                        }
                    }, function (error) {
                        that._isRetrieveTenantAdminPermissionsAPIResponseReceived = true;
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, error);
                        console.error(error);
                        that.showGenericError(that._context);
                        that._context.utils.requestRender();
                    });
                    var retrieveTenantInfoRequest = new RetrieveTenantInfoRequest();
                    this._context.webAPI.execute(retrieveTenantInfoRequest).then(function (response) {
                        if (response) {
                            response.json().then(function (jsonResponse) {
                                /*
                                Sample format of JSON retrived by the OData call
                                {
                                "@odata.context": "http://<machine>/<org>/api/data/v9.0/$metadata#Microsoft.Dynamics.CRM.RetrieveTenantInfoResponse",
                                "TenantInfo": "{\"S2STenantId\":\"00000000-0000-0000-0000-000000000000\",\"IsMnc\":\"False\",\"IsPaid\":\"1\",\"OrgType\":\"0\",\"TenantName\":\"\",\"SharePoint\":\"\",\"exchange\":\"\",\"UserLicensesUsed\":\"1\",\"CompanySize\":\"0\"}"
                                }
                                */
                                try {
                                    var parsedResponse = JSON.parse(jsonResponse["TenantInfo"]);
                                    if (parsedResponse.OrgType == "11") {
                                        that._isEmailTrialOrg = true;
                                    }
                                }
                                catch (e) {
                                    console.error(e);
                                    that.showGenericError(that._context);
                                }
                                finally {
                                    that._isRetrieveTenantInfoAPIResponseReceived = true;
                                    that._context.utils.requestRender();
                                }
                            });
                        }
                    }, function (error) {
                        that._isRetrieveTenantInfoAPIResponseReceived = true;
                        SmbAppsTelemetryUtility.TelemetryData.ReportAppComponentFailureTelemetry(that._context, SmbAppsTelemetryUtility.Controls_PageType.USERMANAGEMENT, error);
                        console.error(error);
                        that.showGenericError(that._context);
                        that._context.utils.requestRender();
                    });
                };
                return UserManagementControl;
            }());
            UserManagement.UserManagementControl = UserManagementControl;
        })(UserManagement = AppCommon.UserManagement || (AppCommon.UserManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="UserManagementControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
* Description: Constants contains the string IDs and the default english text for each string.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var UserManagement;
        (function (UserManagement) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                Object.defineProperty(Constants, "AreaKey", {
                    get: function () {
                        return "userManagement_FREHeaderAreaLabelStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "SubAreaKey", {
                    get: function () {
                        return "userManagement_FREHeaderSubareaLabelStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderLeftContainerKey", {
                    get: function () {
                        return "userManagement_FREHeaderLeft";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderCenterContainerKey", {
                    get: function () {
                        return "userManagement_FREHeaderCenterContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderRightContainerKey", {
                    get: function () {
                        return "userManagement_FREHeaderRightContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AddUserIconContainerKey", {
                    get: function () {
                        return "userManagement_AddUserIconContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "AddUserButtonKey", {
                    get: function () {
                        return "userManagement_AddUserButtonHeader_FREHeaderRightButtonStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "InviteUserIconContainerKey", {
                    get: function () {
                        return "userManagement_InviteUserIconContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "InviteUserButtonKey", {
                    get: function () {
                        return "userManagement_InviteUserButtonHeader_FREHeaderRightButtonStyle";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderSeparatorContainerKey", {
                    get: function () {
                        return "userManagement_FREHeaderSeparatorContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderContainerKey", {
                    get: function () {
                        return "userManagement_FREHeaderContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "SectionContainerKey", {
                    get: function () {
                        return "userManagement_FRESectionContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "BodyContainerKey", {
                    get: function () {
                        return "userManagement_FREBodyContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "UserGridContainerKey", {
                    get: function () {
                        return "userManagement_UserGridContainer";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderNormalIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/UserManagement.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "HeaderHighContrastIconImagePath", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/HeaderIconImages/UserManagement_HC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "ODataAPIURI", {
                    //Constants related to OData
                    get: function () {
                        return "/api/data/v8.0";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "ODataCallWhoAmI", {
                    get: function () {
                        return "/WhoAmI";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "MDD_Dialog_Position_Right", {
                    //Constants related to MDD
                    get: function () {
                        return 2;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "MDD_AddNewUser_UniqueName", {
                    get: function () {
                        return "SMBAddNewUserCustomControlMDD";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Constants, "MDD_InviteUser_UniqueName", {
                    get: function () {
                        return "SMBInviteUserCustomControlMDD";
                    },
                    enumerable: true,
                    configurable: true
                });
                return Constants;
            }());
            UserManagement.Constants = Constants;
        })(UserManagement = AppCommon.UserManagement || (AppCommon.UserManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var UserManagement;
        (function (UserManagement) {
            /**
             * Class refers to the path of all the keys for localization
             */
            var ResourceKeys = (function () {
                function ResourceKeys() {
                }
                Object.defineProperty(ResourceKeys, "AreaText", {
                    get: function () {
                        return "AreaText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "SubAreaText", {
                    get: function () {
                        return "SubAreaText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AddUserButtonText", {
                    get: function () {
                        return "AddUserButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AddUserButtonToolTip", {
                    get: function () {
                        return "AddUserButtonToolTip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "InviteUserButtonText", {
                    get: function () {
                        return "InviteUserButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "InviteUserButtonToolTip", {
                    get: function () {
                        return "InviteUserButtonToolTip";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "ConfirmButtonText", {
                    get: function () {
                        return "ConfirmButtonText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "Error_GenericErrorOccurred", {
                    get: function () {
                        return "Error_GenericErrorOccurred";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "AdvancedSettingsText", {
                    get: function () {
                        return "AdvancedSettingsText";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceKeys, "MicrosoftDynamics365Text", {
                    get: function () {
                        return "MicrosoftDynamics365Text";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourceKeys;
            }());
            UserManagement.ResourceKeys = ResourceKeys;
        })(UserManagement = AppCommon.UserManagement || (AppCommon.UserManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var UserManagement;
        (function (UserManagement) {
            'use strict';
            var UserManagementStyles = (function (_super) {
                __extends(UserManagementStyles, _super);
                function UserManagementStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._userSectionContainer = {};
                    _this._context = context;
                    _this._userSectionContainer = null;
                    return _this;
                }
                UserManagementStyles.prototype.UserSectionContainer = function () {
                    if (this._context.utils.isNullOrUndefined(this._userSectionContainer)) {
                        this._userSectionContainer = {};
                        this._userSectionContainer["display"] = "flex";
                        this._userSectionContainer["flex"] = "1 1 auto";
                        this._userSectionContainer["overflow"] = "hidden";
                        this._userSectionContainer["margin"] = this._context.theming.measures.measure075;
                    }
                    return this._userSectionContainer;
                };
                return UserManagementStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            UserManagement.UserManagementStyles = UserManagementStyles;
        })(UserManagement = AppCommon.UserManagement || (AppCommon.UserManagement = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=UserManagementControl.js.map